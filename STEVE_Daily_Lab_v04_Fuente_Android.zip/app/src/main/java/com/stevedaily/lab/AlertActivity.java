package com.stevedaily.lab;

import android.app.Activity;
import android.app.NotificationManager;
import android.media.AudioAttributes;
import android.os.Bundle;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;
import org.json.JSONObject;

public class AlertActivity extends Activity {
    private int alarmId;
    private int slot;
    private TextToSpeech voice;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        alarmId = getIntent().getIntExtra("id", -1);
        slot = getIntent().getIntExtra("slot", 0);
        JSONObject item = AlarmStore.get(this, alarmId);
        final String name = item == null ? "Actividad" : item.optString("name", "Actividad");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(32), dp(20), dp(32));
        root.setBackgroundColor(Color.WHITE);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = new TextView(this);
        heading.setText("STEVE Daily Lab 0.4\nAGENDA");
        heading.setTextSize(27);
        heading.setTextColor(Color.BLACK);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        TextView title = new TextView(this);
        title.setText(name);
        title.setTextSize(29);
        title.setTextColor(Color.BLACK);
        title.setPadding(0, 50, 0, 35);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        for (int minutes : new int[]{5, 30, 60}) {
            Button btn = button("POSPONER " + minutes + " MINUTOS", Color.rgb(17, 91, 178));
            root.addView(btn);
            btn.setOnClickListener(v -> {
                AlarmStore.schedule(this, AlarmStore.get(this, alarmId), slot, true, minutes * 60_000L);
                closeAlert();
            });
        }
        Button done = button("REALIZADO", Color.rgb(31, 111, 57));
        root.addView(done);
        done.setOnClickListener(v -> { AlarmStore.markDone(this, alarmId, slot); closeAlert(); });
        voice = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && voice != null && !isFinishing()) {
                voice.setLanguage(new Locale("es", "CR"));
                voice.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                voice.speak("Agenda. " + name, TextToSpeech.QUEUE_FLUSH, null, "lab-" + alarmId);
            }
        });
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(18);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setMinHeight(dp(64));
        b.setAllCaps(false);
        GradientDrawable background = new GradientDrawable();
        background.setColor(color);
        background.setCornerRadius(dp(14));
        b.setBackground(background);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(64));
        p.setMargins(0, dp(11), 0, dp(11));
        b.setLayoutParams(p);
        return b;
    }

    private void closeAlert() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(AlarmStore.notificationId(alarmId, slot));
        finish();
    }
    @Override protected void onDestroy() {
        if (voice != null) { voice.stop(); voice.shutdown(); }
        super.onDestroy();
    }
}
