package com.stevedaily.lab;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Almacena actividades y programa una alarma independiente por cada horario. */
public final class AlarmStore {
    private static final String PREF = "steve_daily_lab_tasks_v1";
    private static final String KEY = "alarms";
    private static final String BACKUP_FORMAT = "steve-daily-lab-activities";
    private static final int BACKUP_VERSION = 1; // compatible con respaldos 0.2/0.3
    public static final int MAX_TIMES = 8;
    private AlarmStore() {}

    private static String dayKey(long ms) {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date(ms));
    }
    private static String today() { return dayKey(System.currentTimeMillis()); }

    public static String repeat(JSONObject item) {
        String r = item.optString("repeat", "");
        if (r.equals("once") || r.equals("daily") || r.equals("weekly") || r.equals("monthly") || r.equals("yearly")) return r;
        return item.optBoolean("daily", false) ? "daily" : "once";
    }

    public static int weekdays(JSONObject item) {
        int mask = item.optInt("weekdays", 0) & 127;
        if (mask != 0) return mask;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(item.optLong("when", System.currentTimeMillis()));
        return 1 << (c.get(Calendar.DAY_OF_WEEK) - 1);
    }

    public static JSONArray times(JSONObject item) {
        JSONArray values = item.optJSONArray("times");
        if (values != null && values.length() > 0) return values;
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(item.optLong("when", System.currentTimeMillis()));
        return new JSONArray().put(cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE));
    }

    private static String completionKey(JSONObject item, int slot, long date) {
        return repeat(item).equals("once") ? "once" : dayKey(date);
    }
    public static boolean isCompleted(JSONObject item, int slot) {
        if (item == null) return false;
        JSONObject flags = item.optJSONObject("doneSlots");
        if (flags != null && completionKey(item, slot, System.currentTimeMillis()).equals(flags.optString("s" + slot))) return true;
        if (slot == 0 && flags == null) {
            String r = repeat(item);
            if (r.equals("once")) return item.optBoolean("done", false);
            if (r.equals("daily")) return today().equals(item.optString("lastDoneDay", ""));
        }
        return false;
    }
    public static boolean isCompleted(JSONObject item) {
        if (item == null) return false;
        JSONArray hours = times(item);
        for (int i = 0; i < hours.length(); i++) if (!isCompleted(item, i)) return false;
        return true;
    }

    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private static boolean save(Context c, JSONArray a) {
        return c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).commit();
    }

    public static synchronized JSONObject makeBackup(Context c) throws JSONException {
        JSONObject out = new JSONObject();
        out.put("format", BACKUP_FORMAT);
        out.put("version", BACKUP_VERSION);
        out.put("createdAt", System.currentTimeMillis());
        out.put("activities", all(c));
        return out;
    }

    public static int validateBackup(JSONObject backup) throws JSONException {
        if (!BACKUP_FORMAT.equals(backup.optString("format")) || backup.optInt("version", -1) != BACKUP_VERSION)
            throw new JSONException("No es un respaldo compatible de STEVE Daily Lab.");
        JSONArray items = backup.optJSONArray("activities");
        if (items == null || items.length() > 5000) throw new JSONException("Lista inválida o demasiado grande.");
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) throw new JSONException("Actividad inválida: " + (i + 1));
            String name = item.optString("name", "").trim();
            long when = item.optLong("when", 0);
            if (name.isEmpty() || name.length() > 200 || !(item.opt("when") instanceof Number) ||
                    when < 946684800000L || when > 4102444800000L ||
                    !(item.opt("daily") instanceof Boolean) || !(item.opt("done") instanceof Boolean))
                throw new JSONException("Datos inválidos en actividad " + (i + 1));
            String r = item.optString("repeat", "");
            if (!r.isEmpty() && !(r.equals("once") || r.equals("daily") || r.equals("weekly") ||
                    r.equals("monthly") || r.equals("yearly")))
                throw new JSONException("Repetición desconocida en actividad " + (i + 1));
            if (r.equals("weekly") && (item.optInt("weekdays", 0) & 127) == 0)
                throw new JSONException("Selecciona al menos un día de la semana.");
            JSONArray hours = times(item);
            if (hours.length() < 1 || hours.length() > MAX_TIMES) throw new JSONException("Cantidad de horarios inválida.");
            Set<Integer> unique = new HashSet<>();
            for (int j = 0; j < hours.length(); j++) {
                int minute = hours.optInt(j, -1);
                if (minute < 0 || minute >= 1440 || !unique.add(minute))
                    throw new JSONException("Horario inválido o repetido en actividad " + (i + 1));
            }
            if (item.has("doneSlots") && !(item.opt("doneSlots") instanceof JSONObject))
                throw new JSONException("Estado de realizado inválido.");
        }
        return items.length();
    }

    private static JSONObject cleanCopy(JSONObject source, int id) throws JSONException {
        JSONObject out = new JSONObject();
        out.put("id", id);
        out.put("name", source.optString("name").trim());
        out.put("when", source.optLong("when"));
        out.put("repeat", repeat(source));
        out.put("weekdays", weekdays(source));
        out.put("times", new JSONArray(times(source).toString()));
        out.put("daily", repeat(source).equals("daily"));
        out.put("done", source.optBoolean("done", false));
        out.put("lastDoneDay", source.optString("lastDoneDay", ""));
        JSONObject flags = source.optJSONObject("doneSlots");
        if (flags == null) flags = new JSONObject();
        else flags = new JSONObject(flags.toString());
        // Preserva el estado de realizado de las versiones antiguas.
        if (!source.has("doneSlots") && repeat(source).equals("daily") &&
                (source.optBoolean("done", false) || today().equals(source.optString("lastDoneDay", ""))))
            flags.put("s0", today());
        if (!source.has("doneSlots") && repeat(source).equals("once") && source.optBoolean("done", false))
            flags.put("s0", "once");
        out.put("doneSlots", flags);
        return out;
    }

    private static String identity(JSONObject item) {
        return item.optString("name", "").trim().toLowerCase(Locale.ROOT) + "|" +
            item.optLong("when") + "|" + repeat(item) + "|" + weekdays(item) + "|" + times(item).toString();
    }
    public static synchronized int importBackup(Context c, JSONObject backup) throws JSONException {
        validateBackup(backup);
        JSONArray incoming = backup.getJSONArray("activities");
        JSONArray existing = all(c);
        Set<String> keys = new HashSet<>();
        SharedPreferences prefs = c.getSharedPreferences(PREF, 0);
        int next = prefs.getInt("nextId", 1000);
        for (int i = 0; i < existing.length(); i++) {
            JSONObject item = existing.optJSONObject(i);
            if (item == null) continue;
            keys.add(identity(item));
            next = Math.max(next, item.optInt("id", 1000));
        }
        JSONArray merged = new JSONArray();
        for (int i = 0; i < existing.length(); i++) merged.put(existing.optJSONObject(i));
        JSONArray added = new JSONArray();
        for (int i = 0; i < incoming.length(); i++) {
            JSONObject src = incoming.getJSONObject(i);
            if (!keys.add(identity(src))) continue;
            if (next >= 10000000) throw new JSONException("Demasiadas actividades");
            JSONObject item = cleanCopy(src, ++next);
            merged.put(item);
            added.put(item);
        }
        if (added.length() == 0) return 0;
        if (!prefs.edit().putString(KEY, merged.toString()).putInt("nextId", next).commit())
            throw new JSONException("Android no pudo guardar la importación.");
        for (int i = 0; i < added.length(); i++) scheduleAll(c, added.optJSONObject(i));
        return added.length();
    }

    public static synchronized int add(Context c, String name, long when, String recurrence, int weekMask, JSONArray hours) {
        SharedPreferences prefs = c.getSharedPreferences(PREF, 0);
        int id = prefs.getInt("nextId", 1000) + 1;
        try {
            JSONObject item = makeItem(id, name, when, recurrence, weekMask, hours);
            JSONArray list = all(c);
            list.put(item);
            if (!prefs.edit().putString(KEY, list.toString()).putInt("nextId", id).commit()) return -1;
            scheduleAll(c, item);
            return id;
        } catch (JSONException e) { return -1; }
    }

    private static JSONObject makeItem(int id, String name, long when, String recurrence, int weekMask, JSONArray hours) throws JSONException {
        JSONObject item = new JSONObject();
        item.put("id", id);
        item.put("name", name);
        item.put("when", when);
        item.put("repeat", recurrence);
        item.put("weekdays", weekMask);
        item.put("times", new JSONArray(hours.toString()));
        item.put("daily", recurrence.equals("daily"));
        item.put("done", false);
        item.put("lastDoneDay", "");
        item.put("doneSlots", new JSONObject());
        return item;
    }

    public static synchronized boolean update(Context c, int id, String name, long when, String recurrence, int weekMask, JSONArray hours) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject old = list.optJSONObject(i);
            if (old != null && old.optInt("id") == id) {
                try {
                    JSONObject replacement = makeItem(id, name, when, recurrence, weekMask, hours);
                    // Persistir primero y luego mover las alarmas.
                    list.put(i, replacement);
                    if (!save(c, list)) return false;
                    cancelAll(c, id);
                    scheduleAll(c, replacement);
                    return true;
                } catch (JSONException ignored) { return false; }
            }
        }
        return false;
    }

    public static synchronized boolean delete(Context c, int id) {
        JSONArray list = all(c);
        JSONArray kept = new JSONArray();
        boolean found = false;
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item == null) continue;
            if (item.optInt("id") == id) found = true;
            else kept.put(item);
        }
        if (!found || !save(c, kept)) return false;
        cancelAll(c, id);
        return true;
    }

    public static synchronized void markDone(Context c, int id, int slot) { setDone(c,id,slot,true); }
    public static synchronized void markPending(Context c, int id, int slot) { setDone(c,id,slot,false); }
    private static void setDone(Context c, int id, int slot, boolean completed) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item == null || item.optInt("id") != id || slot >= times(item).length() || slot < 0) continue;
            try {
                JSONObject flags = item.optJSONObject("doneSlots");
                if (flags == null) flags = new JSONObject();
                flags.put("s" + slot, completed ? completionKey(item,slot,System.currentTimeMillis()) : "");
                item.put("doneSlots", flags);
                item.put("done", false);
                item.put("lastDoneDay", "");
                if (!save(c, list)) return;
                cancel(c,id,slot,false);
                cancel(c,id,slot,true);
                dismiss(c,id,slot);
                if (!completed || !repeat(item).equals("once")) schedule(c,item,slot,false,0L);
            } catch (JSONException ignored) { }
            return;
        }
    }

    public static JSONObject get(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null && item.optInt("id") == id) return item;
        }
        return null;
    }

    public static int notificationId(int id, int slot) { return id * 16 + slot; }
    private static PendingIntent alarmIntent(Context c,int id,int slot,boolean snooze) {
        Intent intent = new Intent(c,AlarmReceiver.class)
                .putExtra("id",id).putExtra("slot",slot).putExtra("snooze",snooze);
        return PendingIntent.getBroadcast(c, id * 32 + slot * 2 + (snooze ? 1 : 0),intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private static void dismiss(Context c, int id, int slot) {
        NotificationManager m = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (m != null) m.cancel(notificationId(id,slot));
    }
    public static void cancel(Context c,int id,int slot,boolean snooze) {
        AlarmManager a = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (a != null) a.cancel(alarmIntent(c,id,slot,snooze));
    }
    public static void cancelAll(Context c,int id) {
        for (int j = 0; j < MAX_TIMES; j++) {
            cancel(c,id,j,false); cancel(c,id,j,true); dismiss(c,id,j);
        }
    }
    public static boolean canExact(Context c) {
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        return mgr!=null && (Build.VERSION.SDK_INT<31 || mgr.canScheduleExactAlarms());
    }

    private static long candidate(int year,int month,int day,int minutes) {
        Calendar c=Calendar.getInstance(); c.setLenient(false);
        c.clear();c.set(year,month,day,minutes/60,minutes%60,0);
        try {return c.getTimeInMillis();}catch(IllegalArgumentException e){return -1;}
    }
    private static boolean validCandidate(JSONObject item, int slot, long instant) {
        if (instant <= System.currentTimeMillis()+1000) return false;
        // Si se marcó realizada una ocurrencia de hoy, no programarla otra vez hoy.
        return !isCompleted(item,slot) || !dayKey(instant).equals(today());
    }
    public static long nextTime(JSONObject item,int slot) {
        if (item == null) return -1;
        JSONArray hours=times(item);
        if(slot<0 || slot>=hours.length() || isCompleted(item,slot) && repeat(item).equals("once")) return -1;
        int minute=hours.optInt(slot,-1); if(minute<0 || minute>=1440)return -1;
        String r=repeat(item);
        Calendar base=Calendar.getInstance();base.setTimeInMillis(item.optLong("when"));
        int anchorDay=base.get(Calendar.DAY_OF_MONTH),anchorMonth=base.get(Calendar.MONTH);
        if(r.equals("once")) {
            long t=candidate(base.get(Calendar.YEAR),anchorMonth,anchorDay,minute);
            return validCandidate(item,slot,t)?t:-1;
        }
        Calendar now=Calendar.getInstance();
        if(r.equals("daily") || r.equals("weekly")) {
            for(int delta=0;delta<9;delta++) {
                Calendar d=(Calendar)now.clone();d.add(Calendar.DAY_OF_YEAR,delta);
                if(r.equals("weekly") && (weekdays(item)&(1<<(d.get(Calendar.DAY_OF_WEEK)-1)))==0)continue;
                long t=candidate(d.get(Calendar.YEAR),d.get(Calendar.MONTH),d.get(Calendar.DAY_OF_MONTH),minute);
                if(validCandidate(item,slot,t))return t;
            }
        } else if(r.equals("monthly")) {
            for(int delta=0;delta<26;delta++) {
                Calendar d=(Calendar)now.clone();d.set(Calendar.DAY_OF_MONTH,1);d.add(Calendar.MONTH,delta);
                if(anchorDay>d.getActualMaximum(Calendar.DAY_OF_MONTH))continue;
                long t=candidate(d.get(Calendar.YEAR),d.get(Calendar.MONTH),anchorDay,minute);
                if(validCandidate(item,slot,t))return t;
            }
        } else if(r.equals("yearly")) {
            for(int delta=0;delta<9;delta++) {
                int y=now.get(Calendar.YEAR)+delta;
                long t=candidate(y,anchorMonth,anchorDay,minute);
                if(t>0 && validCandidate(item,slot,t))return t;
            }
        }
        return -1;
    }

    public static void schedule(Context c,JSONObject item,int slot,boolean snooze,long delayMillis) {
        if(item==null || slot<0 || slot>=times(item).length())return;
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(mgr==null)return;
        long trigger;
        if(snooze){if(isCompleted(item,slot))return; trigger=System.currentTimeMillis()+delayMillis;}
        else trigger=nextTime(item,slot);
        if(trigger<=0)return;
        int id=item.optInt("id");
        PendingIntent pi=alarmIntent(c,id,slot,snooze);
        if(canExact(c)) {
            PendingIntent show=PendingIntent.getActivity(c,notificationId(id,slot),new Intent(c,MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            mgr.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger,show),pi);
        } else mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi);
    }
    public static void scheduleAll(Context c,JSONObject item) {
        if(item==null)return;
        JSONArray hours=times(item);
        for(int slot=0;slot<hours.length();slot++)schedule(c,item,slot,false,0);
    }
    public static void reprogram(Context c) {
        JSONArray list=all(c);
        for(int i=0;i<list.length();i++)scheduleAll(c,list.optJSONObject(i));
    }
}
