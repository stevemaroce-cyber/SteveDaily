package com.stevedaily.lab;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import org.json.JSONObject;

public class AlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "steve_lab_alarms_v1";
    public static void makeChannel(Context c) {
        NotificationManager mgr = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (mgr == null) return;
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Alarmas STEVE Daily Lab", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Avisos de actividades STEVE Daily Lab");
        channel.enableVibration(true);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        mgr.createNotificationChannel(channel);
    }

    private PendingIntent action(Context c, int id, int slot, String taskAction, int number) {
        Intent intent = new Intent(c, AlarmReceiver.class).setAction(taskAction)
                .putExtra("id", id).putExtra("slot", slot);
        return PendingIntent.getBroadcast(c, id * 128 + slot * 8 + number, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    @Override public void onReceive(Context c, Intent intent) {
        if (intent == null) return;
        int id = intent.getIntExtra("id", -1);
        int slot = intent.getIntExtra("slot", 0);
        if (id < 0 || slot < 0) return;
        JSONObject item = AlarmStore.get(c, id);
        if (item == null || slot >= AlarmStore.times(item).length() || AlarmStore.isCompleted(item,slot)) return;
        String taskAction = intent.getAction();
        NotificationManager mgr = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        int notifyId = AlarmStore.notificationId(id,slot);
        if ("DONE".equals(taskAction)) {
            AlarmStore.markDone(c,id,slot);
            if (mgr != null) mgr.cancel(notifyId);
            return;
        }
        if (taskAction != null && taskAction.startsWith("SNOOZE_")) {
            try {
                int minutes = Integer.parseInt(taskAction.substring(7));
                AlarmStore.schedule(c,item,slot,true,minutes*60_000L);
                if (mgr != null) mgr.cancel(notifyId);
            } catch (NumberFormatException ignored) { }
            return;
        }
        if (!intent.getBooleanExtra("snooze",false) && !AlarmStore.repeat(item).equals("once")) {
            AlarmStore.schedule(c,item,slot,false,0L);
        }
        makeChannel(c);
        Intent open = new Intent(c, AlertActivity.class).putExtra("id",id).putExtra("slot",slot)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent fullscreen = PendingIntent.getActivity(c,notifyId,open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("STEVE Daily Lab: Agenda")
                .setContentText(item.optString("name","Actividad programada"))
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_MAX)
                .setOngoing(false)
                .setAutoCancel(false)
                .setContentIntent(fullscreen)
                .setFullScreenIntent(fullscreen,true)
                .addAction(new Notification.Action.Builder(0,"5 min",action(c,id,slot,"SNOOZE_5",1)).build())
                .addAction(new Notification.Action.Builder(0,"30 min",action(c,id,slot,"SNOOZE_30",2)).build())
                .addAction(new Notification.Action.Builder(0,"60 min",action(c,id,slot,"SNOOZE_60",3)).build())
                .addAction(new Notification.Action.Builder(0,"Realizado",action(c,id,slot,"DONE",4)).build());
        if (mgr != null && (Build.VERSION.SDK_INT < 33 ||
                c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED))
            mgr.notify(notifyId,b.build());
    }
}
