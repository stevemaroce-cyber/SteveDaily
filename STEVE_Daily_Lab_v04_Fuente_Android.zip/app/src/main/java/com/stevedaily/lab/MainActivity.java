package com.stevedaily.lab;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 401;
    private static final int RESTORE_BACKUP = 402;
    private static final int MAX_BACKUP_BYTES = 1024 * 1024;
    private static final int BLUE = Color.rgb(17, 91, 178);
    private static final int GREEN = Color.rgb(31, 111, 57);
    private static final int RED = Color.rgb(174, 29, 39);
    private static final int DARK = Color.rgb(26, 33, 43);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AlarmReceiver.makeChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
    }

    @Override protected void onResume() { super.onResume(); display(); }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable rounded(int background, int border) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(background);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), border);
        return bg;
    }

    private TextView text(String content, int size, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(content);
        label.setTextSize(size);
        label.setTextColor(color);
        if (bold) label.setTypeface(null, Typeface.BOLD);
        return label;
    }

    private Button button(String label, int background) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(16);
        b.setTypeface(null, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(background, background));
        b.setMinHeight(dp(58));
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        return b;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addFullButton(LinearLayout parent, Button button, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(top), 0, dp(bottom));
        parent.addView(button, p);
    }

    private void section(LinearLayout root, String title) {
        TextView heading = text(title, 23, DARK, true);
        heading.setPadding(0, dp(18), 0, dp(8));
        root.addView(heading);
    }

    private void display() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(16), dp(18), dp(34));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        setContentView(scroll);

        TextView heading = text("STEVE Daily Lab 0.4", 28, DARK, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        TextView description = text("Pruebas de agenda · sin modificar tus otras aplicaciones", 15, DARK, false);
        description.setGravity(Gravity.CENTER);
        description.setPadding(0, dp(8), 0, dp(17));
        root.addView(description);

        if (!AlarmStore.canExact(this)) {
            root.addView(text("Autoriza 'Alarmas y recordatorios' para horarios exactos.", 16, RED, true));
            Button permission = button("ACTIVAR ALARMAS EXACTAS", BLUE);
            addFullButton(root, permission, 12, 12);
            permission.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 31)
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
            });
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                root.addView(text("Activa pantalla completa para ver las alarmas con el teléfono bloqueado.", 15, RED, true));
                Button full = button("PERMITIR PANTALLA COMPLETA", BLUE);
                addFullButton(root, full, 10, 10);
                full.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()))));
            }
        }

        Button create = button("+ NUEVA ACTIVIDAD", BLUE);
        addFullButton(root, create, 4, 14);
        create.setOnClickListener(v -> showEditor(null));
        section(root, "Actividades guardadas");

        JSONArray list = AlarmStore.all(this);
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null) items.add(item);
        }
        items.sort((a,b) -> {
            boolean ac = AlarmStore.isCompleted(a), bc = AlarmStore.isCompleted(b);
            if (ac != bc) return ac ? 1 : -1;
            return Long.compare(a.optLong("when"), b.optLong("when"));
        });
        if (items.isEmpty()) {
            TextView empty = text("Todavía no hay actividades. Presiona + NUEVA ACTIVIDAD para crear una.", 17, DARK, false);
            empty.setPadding(dp(6), dp(18), dp(6), dp(20));
            root.addView(empty);
        }
        for (JSONObject item : items) addActivity(root, item);

        section(root, "Copias de seguridad");
        TextView info = text("Guarda tus actividades en un archivo y recupéralas si cambias de versión o de teléfono.", 16, DARK, false);
        info.setPadding(0, dp(2), 0, dp(8));
        root.addView(info);
        Button export = button("GUARDAR RESPALDO", BLUE);
        addFullButton(root, export, 9, 8);
        export.setOnClickListener(v -> chooseExport());
        Button restore = button("RECUPERAR RESPALDO", GREEN);
        addFullButton(root, restore, 8, 12);
        restore.setOnClickListener(v -> chooseImport());
        TextView note = text("Los respaldos son archivos JSON privados. Puedes trasladar actividades desde Lab 0.2 o Lab 0.3: guarda el respaldo allí y recupéralo aquí.", 14, DARK, false);
        note.setPadding(0, dp(6), 0, dp(10));
        root.addView(note);
        root.addView(text("Activa notificaciones y permite funcionar en segundo plano. Prueba las alarmas con la pantalla apagada antes de depender de ellas.", 14, DARK, false));
    }

    private static final String[] REPEATS = {"Una vez", "Todos los días", "Semanal", "Mensual", "Anual"};
    private static final String[] REPEAT_CODES = {"once", "daily", "weekly", "monthly", "yearly"};
    private static final String[] DAYS = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
    private static final int[] CAL_DAYS = {Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
            Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY};

    private String repeatDescription(JSONObject item) {
        String repeat = AlarmStore.repeat(item);
        if (repeat.equals("daily")) return "Todos los días";
        if (repeat.equals("weekly")) {
            StringBuilder result = new StringBuilder("Cada semana: ");
            int mask = AlarmStore.weekdays(item);
            for (int i = 0; i < CAL_DAYS.length; i++) {
                if ((mask & (1 << (CAL_DAYS[i] - 1))) != 0) {
                    if (result.length() > 13) result.append(", ");
                    result.append(DAYS[i]);
                }
            }
            return result.toString();
        }
        Calendar when = Calendar.getInstance();
        when.setTimeInMillis(item.optLong("when"));
        if (repeat.equals("monthly")) return "Cada mes · día " + when.get(Calendar.DAY_OF_MONTH);
        if (repeat.equals("yearly")) return "Cada año · " +
                new SimpleDateFormat("d 'de' MMMM", new Locale("es", "CR")).format(when.getTime());
        return "Una vez · " + new SimpleDateFormat("d MMM yyyy", new Locale("es", "CR")).format(when.getTime());
    }
    private String formatMinutes(int minutes) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, minutes / 60);
        c.set(Calendar.MINUTE, minutes % 60);
        return new SimpleDateFormat("h:mm a", new Locale("es", "CR")).format(c.getTime());
    }
    private void addActivity(LinearLayout root, JSONObject item) {
        final int id = item.optInt("id", -1);
        final String name = item.optString("name", "Actividad");
        LinearLayout card = column();
        card.setPadding(dp(15), dp(16), dp(15), dp(16));
        card.setBackground(rounded(Color.rgb(245, 249, 253), Color.rgb(192, 209, 226)));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, dp(10), 0, dp(14));
        root.addView(card, cardParams);
        TextView title = text(name, 21, DARK, true);
        title.setPadding(0, 0, 0, dp(7));
        card.addView(title);
        TextView frequency = text(repeatDescription(item), 16, BLUE, true);
        frequency.setPadding(0, 0, 0, dp(10));
        card.addView(frequency);

        JSONArray hours = AlarmStore.times(item);
        for (int slot = 0; slot < hours.length(); slot++) {
            final int selectedSlot = slot;
            boolean completed = AlarmStore.isCompleted(item, slot);
            LinearLayout occurrence = column();
            occurrence.setPadding(dp(10), dp(10), dp(10), dp(12));
            occurrence.setBackground(rounded(completed ? Color.rgb(235, 250, 239) : Color.WHITE,
                    completed ? Color.rgb(151, 196, 161) : Color.rgb(215, 224, 235)));
            LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, -2);
            op.setMargins(0, dp(5), 0, dp(10));
            card.addView(occurrence, op);
            TextView slotTitle = text(formatMinutes(hours.optInt(slot)) + (hours.length() > 1 ? " · Horario " + (slot + 1) : ""), 19, DARK, true);
            occurrence.addView(slotTitle);
            String status = completed ? (AlarmStore.repeat(item).equals("once") ? "REALIZADO" : "REALIZADO HOY") : "PENDIENTE";
            TextView state = text(status, 15, completed ? GREEN : RED, true);
            state.setPadding(0, dp(4), 0, dp(7));
            occurrence.addView(state);
            Button done = button(completed ? "DESMARCAR" : "REALIZADO", GREEN);
            addFullButton(occurrence, done, 3, 0);
            done.setOnClickListener(v -> {
                if (completed) AlarmStore.markPending(this, id, selectedSlot);
                else AlarmStore.markDone(this, id, selectedSlot);
                display();
            });
        }

        Button edit = button("EDITAR ACTIVIDAD", BLUE);
        addFullButton(card, edit, 9, 7);
        edit.setOnClickListener(v -> showEditor(AlarmStore.get(this, id)));
        Button delete = button("BORRAR ACTIVIDAD", RED);
        addFullButton(card, delete, 7, 0);
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Confirmar borrado")
                .setMessage("¿Borrar '" + name + "' y TODOS sus horarios? Esta acción no se puede deshacer. Puedes guardar un respaldo antes.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("BORRAR", (dialog, which) -> {
                    if (!AlarmStore.delete(this, id)) {
                        Toast.makeText(this, "No se pudo borrar", Toast.LENGTH_LONG).show();
                    } else Toast.makeText(this, "Actividad borrada", Toast.LENGTH_SHORT).show();
                    display();
                }).show());
    }

    private void showEditor(JSONObject existing) {
        final boolean editing = existing != null;
        final int id = editing ? existing.optInt("id") : -1;
        final Calendar selection = Calendar.getInstance();
        if (editing) selection.setTimeInMillis(existing.optLong("when", System.currentTimeMillis()));
        else selection.add(Calendar.MINUTE, 10);
        selection.set(Calendar.SECOND, 0);
        selection.set(Calendar.MILLISECOND, 0);
        JSONArray originalHours = editing ? AlarmStore.times(existing) : new JSONArray()
                .put(selection.get(Calendar.HOUR_OF_DAY) * 60 + selection.get(Calendar.MINUTE));
        final ArrayList<Integer> selectedTimes = new ArrayList<>();
        for (int i = 0; i < originalHours.length(); i++) selectedTimes.add(originalHours.optInt(i));
        java.util.Collections.sort(selectedTimes);

        ScrollView scroller = new ScrollView(this);
        LinearLayout form = column();
        form.setPadding(dp(18), dp(10), dp(18), dp(10));
        scroller.addView(form);
        form.addView(text("Nombre de la actividad", 17, DARK, true));
        EditText nameField = new EditText(this);
        nameField.setText(editing ? existing.optString("name") : "");
        nameField.setTextSize(18);
        nameField.setMaxLines(2);
        nameField.setHint("Ejemplo: dar comida a las mascotas");
        form.addView(nameField);

        TextView modeLabel = text("¿Con qué frecuencia?", 17, DARK, true);
        modeLabel.setPadding(0, dp(15), 0, dp(7));
        form.addView(modeLabel);
        android.widget.Spinner repeat = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, REPEATS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        repeat.setAdapter(adapter);
        repeat.setMinimumHeight(dp(55));
        form.addView(repeat);
        if (editing) {
            for (int i = 0; i < REPEAT_CODES.length; i++) {
                if (REPEAT_CODES[i].equals(AlarmStore.repeat(existing))) repeat.setSelection(i);
            }
        }
        TextView picked = text("", 17, DARK, true);
        picked.setPadding(0, dp(12), 0, dp(9));
        form.addView(picked);
        Button date = button("ELEGIR FECHA", BLUE);
        addFullButton(form, date, 4, 10);

        LinearLayout weekly = column();
        weekly.setPadding(dp(8), dp(5), dp(8), dp(5));
        form.addView(weekly);
        weekly.addView(text("Días de la semana (puedes marcar varios):", 16, DARK, true));
        CheckBox[] days = new CheckBox[7];
        int mask = editing ? AlarmStore.weekdays(existing) :
                1 << (selection.get(Calendar.DAY_OF_WEEK) - 1);
        for (int i = 0; i < DAYS.length; i++) {
            final int day = CAL_DAYS[i];
            CheckBox option = new CheckBox(this);
            option.setText(DAYS[i]);
            option.setTextSize(18);
            option.setTextColor(DARK);
            option.setMinHeight(dp(49));
            option.setChecked((mask & (1 << (day - 1))) != 0);
            weekly.addView(option);
            days[i] = option;
        }

        Runnable refreshMode = () -> {
            int mode = repeat.getSelectedItemPosition();
            date.setVisibility((mode == 0 || mode == 3 || mode == 4) ? View.VISIBLE : View.GONE);
            weekly.setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
            if (mode == 0) picked.setText("Fecha: " + new SimpleDateFormat("d MMM yyyy", new Locale("es", "CR")).format(selection.getTime()));
            else if (mode == 3) picked.setText("Día de cada mes: " + selection.get(Calendar.DAY_OF_MONTH));
            else if (mode == 4) picked.setText("Cada año: " + new SimpleDateFormat("d 'de' MMMM", new Locale("es", "CR")).format(selection.getTime()));
            else picked.setText(mode == 1 ? "Todos los días" : "Repetir cada semana");
        };
        repeat.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long itemId) {
                refreshMode.run();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        refreshMode.run();
        date.setOnClickListener(v -> new DatePickerDialog(this, (picker, year, month, day) -> {
            selection.set(Calendar.DAY_OF_MONTH, 1);
            selection.set(Calendar.YEAR, year);
            selection.set(Calendar.MONTH, month);
            selection.set(Calendar.DAY_OF_MONTH, day);
            refreshMode.run();
        }, selection.get(Calendar.YEAR), selection.get(Calendar.MONTH), selection.get(Calendar.DAY_OF_MONTH)).show());

        TextView hoursTitle = text("Horarios (puedes agregar varios)", 17, DARK, true);
        hoursTitle.setPadding(0, dp(12), 0, dp(6));
        form.addView(hoursTitle);
        LinearLayout hourList = column();
        form.addView(hourList);
        showHours(hourList, selectedTimes);
        Button addTime = button("+ AGREGAR OTRA HORA", BLUE);
        addFullButton(form, addTime, 10, 9);
        addTime.setOnClickListener(v -> {
            if (selectedTimes.size() >= AlarmStore.MAX_TIMES) {
                Toast.makeText(this, "Máximo " + AlarmStore.MAX_TIMES + " horarios por actividad", Toast.LENGTH_LONG).show(); return;
            }
            Calendar c = Calendar.getInstance();
            new TimePickerDialog(this, (picker, hour, minute) -> {
                int value = hour * 60 + minute;
                if (selectedTimes.contains(value)) {
                    Toast.makeText(this, "Esa hora ya existe", Toast.LENGTH_SHORT).show(); return;
                }
                selectedTimes.add(value);
                java.util.Collections.sort(selectedTimes);
                showHours(hourList, selectedTimes);
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show();
        });
        TextView helper = text("Los horarios se guardan dentro de una sola actividad. Puedes marcar como realizado cada horario por separado.",
                14, DARK, false);
        helper.setPadding(0, dp(8), 0, dp(9));
        form.addView(helper);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(editing ? "Editar actividad" : "Nueva actividad")
                .setView(scroller)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("GUARDAR", null).create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = nameField.getText().toString().trim();
            if (name.isEmpty() || name.length() > 200) {nameField.setError("Escribe un nombre de hasta 200 caracteres");return;}
            int weekMask = 0;
            for (int i = 0; i < DAYS.length; i++) {
                if (days[i].isChecked()) weekMask |= 1 << (CAL_DAYS[i] - 1);
            }
            String recurrence = REPEAT_CODES[repeat.getSelectedItemPosition()];
            if (recurrence.equals("weekly") && weekMask == 0) {
                Toast.makeText(this, "Marca al menos un día", Toast.LENGTH_LONG).show(); return;
            }
            if (selectedTimes.isEmpty()) {Toast.makeText(this, "Agrega una hora", Toast.LENGTH_LONG).show();return;}
            JSONArray hours = new JSONArray();
            for (int t : selectedTimes) hours.put(t);
            if (recurrence.equals("once")) {
                Calendar day = (Calendar)selection.clone();
                day.set(Calendar.HOUR_OF_DAY, selectedTimes.get(0)/60);
                day.set(Calendar.MINUTE, selectedTimes.get(0)%60);
                if (day.getTimeInMillis() < System.currentTimeMillis()+5000) {
                    Toast.makeText(this, "Elige una fecha y hora futuras", Toast.LENGTH_LONG).show(); return;
                }
            }
            boolean saved = editing ? AlarmStore.update(this, id, name, selection.getTimeInMillis(), recurrence, weekMask, hours)
                    : AlarmStore.add(this, name, selection.getTimeInMillis(), recurrence, weekMask, hours) > 0;
            if (!saved) {Toast.makeText(this, "No se pudo guardar. Prueba nuevamente", Toast.LENGTH_LONG).show();return;}
            dialog.dismiss();
            Toast.makeText(this, editing ? "Actividad actualizada" : "Actividad guardada", Toast.LENGTH_SHORT).show();
            display();
        }));
        dialog.show();
    }

    private void showHours(LinearLayout container, ArrayList<Integer> hours) {
        container.removeAllViews();
        for (int value : new ArrayList<>(hours)) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView show = text(formatMinutes(value), 19, DARK, true);
            row.addView(show, new LinearLayout.LayoutParams(0, dp(55), 1));
            Button remove = button("QUITAR", RED);
            row.addView(remove, new LinearLayout.LayoutParams(dp(108), dp(54)));
            remove.setOnClickListener(v -> {
                if (hours.size() <= 1) {
                    Toast.makeText(this, "Debe quedar al menos una hora", Toast.LENGTH_SHORT).show();
                } else {
                    hours.remove(Integer.valueOf(value));
                    showHours(container, hours);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
            lp.setMargins(0,dp(4),0,dp(4));
            container.addView(row,lp);
        }
    }
    private void chooseExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "STEVE_Daily_Respaldo_" + stamp + ".json");
        try { startActivityForResult(intent, CREATE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para guardar el archivo."); }
    }

    private void chooseImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try { startActivityForResult(intent, RESTORE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para abrir archivos."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == CREATE_BACKUP) {
            try {
                JSONObject backup = AlarmStore.makeBackup(this);
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                    if (stream == null) throw new Exception("No se pudo abrir el archivo de destino");
                    byte[] bytes = backup.toString(2).getBytes(StandardCharsets.UTF_8);
                    stream.write(bytes);
                    stream.flush();
                }
                message("Respaldo guardado: " + AlarmStore.all(this).length() + " actividades");
            } catch (Exception e) {
                showError("No se pudo guardar el respaldo: " + e.getMessage());
            }
        } else if (requestCode == RESTORE_BACKUP) {
            try {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    if (stream == null) throw new Exception("No se pudo leer el archivo");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = stream.read(buffer)) != -1) {
                        if (bytes.size() + count > MAX_BACKUP_BYTES)
                            throw new Exception("El archivo es demasiado grande (máximo 1 MB)");
                        bytes.write(buffer, 0, count);
                    }
                }
                JSONObject backup = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                int total = AlarmStore.validateBackup(backup);
                new AlertDialog.Builder(this)
                        .setTitle("Confirmar importación")
                        .setMessage("El archivo contiene " + total + " actividades. Se agregarán solo las que no existan; ninguna actividad actual se borrará. ¿Importar ahora?")
                        .setPositiveButton("IMPORTAR", (dialog, which) -> {
                            try {
                                int imported = AlarmStore.importBackup(this, backup);
                                new AlertDialog.Builder(this)
                                        .setTitle("Respaldo recuperado")
                                        .setMessage("Actividades nuevas: " + imported + "\nDuplicadas omitidas: " + (total - imported))
                                        .setPositiveButton("ENTENDIDO", null)
                                        .show();
                                display();
                            } catch (Exception e) { showError("No se pudo importar: " + e.getMessage()); }
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
            } catch (Exception e) {
                showError("El archivo no es un respaldo válido: " + e.getMessage());
            }
        }
    }

    private void showError(String description) {
        new AlertDialog.Builder(this).setTitle("Aviso del respaldo")
                .setMessage(description).setPositiveButton("ENTENDIDO", null).show();
    }
    private void message(String description) {
        Toast.makeText(this, description, Toast.LENGTH_LONG).show();
    }
}
