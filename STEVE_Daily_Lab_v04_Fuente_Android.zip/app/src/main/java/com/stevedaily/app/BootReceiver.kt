package com.stevedaily.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (!AlarmPause.isDisabled(context)) {
                TaskStore.load(context).forEach { AlarmHelper.schedule(context, it) }
                AlarmHelper.restoreSnoozes(context)
            }
        }
    }
}
