package com.stevedaily.app

import android.content.Context
import android.content.SharedPreferences

object AlarmPause {
    private const val PREFS = "steve_pause"
    private const val KEY_DISABLED = "disabled"

    private fun normalPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun bootPrefs(context: Context): SharedPreferences =
        context.createDeviceProtectedStorageContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isDisabled(context: Context): Boolean {
        val boot = bootPrefs(context)
        if (boot.contains(KEY_DISABLED)) return boot.getBoolean(KEY_DISABLED, false)

        // Compatibilidad con v1.16.2: si existía el valor anterior, lo migra
        // al almacenamiento protegido y lo guarda de forma síncrona.
        val normal = normalPrefs(context)
        val value = normal.getBoolean(KEY_DISABLED, false)
        if (normal.contains(KEY_DISABLED)) {
            boot.edit().putBoolean(KEY_DISABLED, value).commit()
        }
        return value
    }

    fun setDisabled(context: Context, disabled: Boolean) {
        // Estado crítico: commit() fuerza la escritura a disco antes de continuar.
        // Se guarda además en device-protected storage para sobrevivir reinicios.
        bootPrefs(context).edit()
            .putBoolean(KEY_DISABLED, disabled)
            .remove("date")
            .commit()

        normalPrefs(context).edit()
            .putBoolean(KEY_DISABLED, disabled)
            .remove("date")
            .commit()
    }
}
