package com.stevedaily.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId

object AlarmHelper {
    private const val BACKUP_DELAY_MS = 3_000L
    private const val BACKUP_REQUEST_XOR = 0x51A7
    private const val SNOOZE_REQUEST_XOR = 0x5A32
    private const val SNOOZE_PREFS = "steve_snooze"
    const val ACTION_SNOOZE = "com.stevedaily.app.SNOOZE"
    const val ACTION_TEST = "com.stevedaily.app.TEST"

    /** Alarma de prueba (no es una actividad): sirve para comprobar que suena con la pantalla apagada. */
    fun scheduleTest(context: Context, minutes: Int = 1): Boolean {
        if (!hasExactAlarmPermission(context)) {
            requestExactAlarmPermission(context)
            return false
        }
        return runCatching {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val fireAt = System.currentTimeMillis() + minutes * 60_000L
            val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
                action = ACTION_TEST
                putExtra("taskId", -1L)
                putExtra("text", "Prueba de alarma de STEVE Daily")
            }
            val pendingIntent = PendingIntent.getBroadcast(context, 0x7E57, alarmIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val showIntent = PendingIntent.getActivity(context, 0x7E58,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(fireAt, showIntent), pendingIntent)
            true
        }.getOrDefault(false)
    }

    fun hasExactAlarmPermission(context: Context): Boolean {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()
    }

    fun requestExactAlarmPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val permissionIntent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(permissionIntent)
        }
    }

    fun schedule(context: Context, task: Task): Boolean {
        if (AlarmPause.isDisabled(context)) return false
        if (task.repeat == "Nunca" && TaskStore.isOnceDone(context, task.id)) {
            cancel(context, task.id)
            return false
        }
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // También se llama desde BootReceiver: no abrir ajustes desde segundo plano.
        if (!hasExactAlarmPermission(context)) return false

        val baseDate = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return false
        val time = runCatching { LocalTime.parse(task.time) }.getOrNull() ?: return false
        val now = LocalDateTime.now()
        val dateTime = nextOccurrence(task, baseDate, time, now) ?: return false
        val triggerAtMillis = dateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

        // v1.16.1 HONOR FIX:
        // Volvemos a la arquitectura que ya funcionaba en el Honor 400:
        // setAlarmClock -> BroadcastReceiver -> ForegroundService -> AlarmActivity.
        // No intentamos abrir una Activity directamente como operación principal del AlarmManager.
        val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.stevedaily.app.ALARM"
            putExtra("taskId", task.id)
            putExtra("text", task.title)
        }
        val alarmPendingIntent = PendingIntent.getBroadcast(
            context,
            task.id.hashCode(),
            alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = PendingIntent.getActivity(
            context,
            task.id.hashCode() xor 0x1357,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return runCatching {
            alarmManager.setAlarmClock(
                AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent), alarmPendingIntent)
            true
        }.getOrDefault(false)
    }

    /** Programa una segunda alarma real del sistema, no un temporizador de pantalla. */
    fun snooze(context: Context, taskId: Long, title: String, minutes: Int): Boolean {
        if (taskId < 0 || minutes !in listOf(5, 30, 60)) return false
        if (AlarmPause.isDisabled(context) || !hasExactAlarmPermission(context)) return false
        val fireAt = System.currentTimeMillis() + minutes * 60_000L
        if (!scheduleSnoozeAt(context, taskId, title, fireAt)) return false
        // commit persiste la fecha antes de cerrar la pantalla para reprogramar tras reinicio.
        context.getSharedPreferences(SNOOZE_PREFS, Context.MODE_PRIVATE).edit()
            .putLong("time_$taskId", fireAt)
            .putString("text_$taskId", title)
            .commit()
        return true
    }

    private fun scheduleSnoozeAt(context: Context, taskId: Long, title: String, fireAt: Long): Boolean {
        if (!hasExactAlarmPermission(context) || fireAt <= System.currentTimeMillis()) return false
        return runCatching {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val alarmIntent = Intent(context, AlarmReceiver::class.java).apply {
                action = ACTION_SNOOZE
                putExtra("taskId", taskId)
                putExtra("text", title)
            }
            val pendingIntent = PendingIntent.getBroadcast(context, snoozeRequestCode(taskId),
                alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val showIntent = PendingIntent.getActivity(context,
                snoozeRequestCode(taskId) xor 0x1357,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(fireAt, showIntent), pendingIntent)
            true
        }.getOrDefault(false)
    }

    fun clearSnooze(context: Context, taskId: Long) {
        context.getSharedPreferences(SNOOZE_PREFS, Context.MODE_PRIVATE).edit()
            .remove("time_$taskId").remove("text_$taskId").commit()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, AlarmReceiver::class.java).apply { action = ACTION_SNOOZE }
        PendingIntent.getBroadcast(context, snoozeRequestCode(taskId), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)?.let {
                alarmManager.cancel(it)
                it.cancel()
            }
    }

    fun restoreSnoozes(context: Context) {
        if (AlarmPause.isDisabled(context) || !hasExactAlarmPermission(context)) return
        val prefs = context.getSharedPreferences(SNOOZE_PREFS, Context.MODE_PRIVATE)
        val times = prefs.all.filterKeys { it.startsWith("time_") }
        for ((key, value) in times) {
            val id = key.removePrefix("time_").toLongOrNull() ?: continue
            val fireAt = value as? Long ?: continue
            if (fireAt <= System.currentTimeMillis() || TaskStore.find(context, id) == null) {
                clearSnooze(context, id)
            } else {
                scheduleSnoozeAt(context, id, prefs.getString("text_$id", "Actividad") ?: "Actividad", fireAt)
            }
        }
    }

    private fun snoozeRequestCode(taskId: Long): Int = taskId.hashCode() xor SNOOZE_REQUEST_XOR

    fun upcoming(task: Task, after: LocalDateTime): LocalDateTime? {
        val date = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return null
        val time = runCatching { LocalTime.parse(task.time) }.getOrNull() ?: return null
        return nextOccurrence(task, date, time, after)
    }

    private fun nextOccurrence(task: Task, baseDate: LocalDate, time: LocalTime, now: LocalDateTime): LocalDateTime? {
        return when (task.repeat) {
            "Nunca" -> LocalDateTime.of(baseDate, time).takeIf { it.isAfter(now) }
            "Diaria" -> {
                var d = LocalDateTime.of(baseDate, time)
                while (!d.isAfter(now)) d = d.plusDays(1)
                d
            }
            "Semanal" -> {
                val days = task.repeatDays.split(',').mapNotNull {
                    runCatching { DayOfWeek.valueOf(it) }.getOrNull()
                }.toSet().ifEmpty { setOf(baseDate.dayOfWeek) }
                var date = if (baseDate.isAfter(now.toLocalDate())) baseDate else now.toLocalDate()
                repeat(15) {
                    val candidate = LocalDateTime.of(date, time)
                    if (date.dayOfWeek in days && !date.isBefore(baseDate) && candidate.isAfter(now)) return candidate
                    date = date.plusDays(1)
                }
                null
            }
            "Anual" -> {
                val startYear = maxOf(baseDate.year, now.year)
                (startYear..startYear + 5).asSequence().map { year ->
                    val month = baseDate.monthValue
                    val day = baseDate.dayOfMonth.coerceAtMost(YearMonth.of(year, month).lengthOfMonth())
                    LocalDateTime.of(year, month, day, time.hour, time.minute)
                }.firstOrNull { !it.toLocalDate().isBefore(baseDate) && it.isAfter(now) }
            }
            "Mensual" -> {
                val wanted = if (task.monthlyDay in 1..31) task.monthlyDay else baseDate.dayOfMonth
                var ym = YearMonth.from(if (baseDate.isAfter(now.toLocalDate())) baseDate else now.toLocalDate())
                repeat(15) {
                    val day = wanted.coerceAtMost(ym.lengthOfMonth())
                    val date = ym.atDay(day)
                    val candidate = LocalDateTime.of(date, time)
                    if (!date.isBefore(baseDate) && candidate.isAfter(now)) return candidate
                    ym = ym.plusMonths(1)
                }
                null
            }
            else -> null
        }
    }

    fun rescheduleAll(context: Context) {
        if (AlarmPause.isDisabled(context) || !hasExactAlarmPermission(context)) return
        TaskStore.load(context).forEach { schedule(context, it) }
    }

    fun cancelBackup(context: Context, taskId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val backupIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.stevedaily.app.BACKUP_ALARM"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            backupRequestCode(taskId),
            backupIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun cancel(context: Context, taskId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        // Operación principal actual: BroadcastReceiver (ruta probada en Honor 400).
        val receiverIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.stevedaily.app.ALARM"
        }
        val receiverPendingIntent = PendingIntent.getBroadcast(
            context,
            taskId.hashCode(),
            receiverIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (receiverPendingIntent != null) {
            alarmManager.cancel(receiverPendingIntent)
            receiverPendingIntent.cancel()
        }

        // Compatibilidad: limpia también la operación Activity usada por v1.16.
        val alarmActivityIntent = Intent(context, AlarmActivity::class.java)
        val activityPendingIntent = PendingIntent.getActivity(
            context,
            taskId.hashCode(),
            alarmActivityIntent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (activityPendingIntent != null) {
            alarmManager.cancel(activityPendingIntent)
            activityPendingIntent.cancel()
        }

        cancelBackup(context, taskId)
        clearSnooze(context, taskId)
    }

    private fun backupRequestCode(taskId: Long): Int = taskId.hashCode() xor BACKUP_REQUEST_XOR
}
