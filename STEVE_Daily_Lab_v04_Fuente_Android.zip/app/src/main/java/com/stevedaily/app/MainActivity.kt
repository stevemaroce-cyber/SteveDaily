package com.stevedaily.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.*
import java.math.BigDecimal
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private var tasks = mutableListOf<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        if (!AlarmHelper.hasExactAlarmPermission(this)) {
            Toast.makeText(this, "Activa el permiso de Alarmas y recordatorios para STEVE Daily.", Toast.LENGTH_LONG).show()
            AlarmHelper.requestExactAlarmPermission(this)
        }
        draw()
    }

    override fun onResume() {
        super.onResume()
        if (AlarmHelper.hasExactAlarmPermission(this) && !AlarmPause.isDisabled(this)) AlarmHelper.rescheduleAll(this)
    }

    private fun draw() {
        tasks = TaskStore.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 20)
            setBackgroundColor(Color.WHITE)
        }

        val hour = LocalTime.now().hour
        val greeting = when {
            hour < 12 -> "Buenos días"
            hour < 18 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        val dateText = LocalDate.now().format(
            DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", Locale("es", "CR"))
        ).replaceFirstChar { it.uppercase() }

        root.addView(TextView(this).apply {
            text = "S"
            textSize = 30f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(20, 82, 160))
        })
        root.addView(TextView(this).apply {
            text = "STEVE DAILY • v1.16.5 PRUEBA"
            textSize = 22f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "$greeting${userGreeting()}  •  $dateText\nTu día, bajo control"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 2, 0, 9)
        })

        val next = nextTaskText()
        root.addView(TextView(this).apply {
            text = next
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(235, 243, 255))
            setPadding(14, 10, 14, 10)
        })
        root.addView(Space(this).apply { minimumHeight = 7 })

        val paused = AlarmPause.isDisabled(this)
        if (paused) root.addView(TextView(this).apply {
            text = "🔴 ALARMAS DESHABILITADAS • toca MÁS para habilitar"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(150, 70, 0))
            setBackgroundColor(Color.rgb(255, 245, 224))
            setPadding(10, 8, 10, 8)
        })

        // Menú principal compacto: deja visibles las dos listas de uso frecuente
        // y mueve opciones menos frecuentes a una lista bajo MÁS.
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val compactButtonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        quick.addView(Button(this).apply {
            text = "✓ TO DO"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showTodo() }
        }, compactButtonParams)
        quick.addView(Button(this).apply {
            text = "🛒 TO BUY"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showToBuy() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        quick.addView(Button(this).apply {
            text = "☰ MÁS"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showMoreMenu() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(quick)

        root.addView(Button(this).apply {
            text = "+ NUEVA ACTIVIDAD"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 50
            setOnClickListener { showEditor(null) }
        })

        root.addView(TextView(this).apply {
            text = "AGENDA"
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setPadding(4, 12, 0, 6)
        })

        root.addView(todayStatusSummary())
        root.addView(statusLegend())

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderList()
    }

    private fun nextTaskText(): String {
        val today = LocalDate.now()
        val now = LocalTime.now()
        val next = tasks
            .filter { taskOccursOn(it, today) }
            .filter { !isCompletedToday(it.id) && !isSkippedToday(it.id) }
            .mapNotNull { t -> runCatching { LocalTime.parse(t.time) }.getOrNull()?.let { tm -> t to tm } }
            .filter { (_, tm) -> tm.isAfter(now) }
            .minByOrNull { it.second }
        return if (next == null) "✓ No hay otra actividad pendiente hoy"
        else "PRÓXIMA  •  ${next.second}\n${next.first.title}"
    }

    private fun priorityColor(priority: String): Int = when (priority) {
        "Rojo" -> Color.rgb(255, 225, 225)
        "Amarillo" -> Color.rgb(255, 247, 204)
        else -> Color.rgb(224, 245, 228)
    }

    private fun priorityIcon(priority: String): String = when (priority) {
        "Rojo" -> "🔴"
        "Amarillo" -> "🟡"
        else -> "🟢"
    }

    private fun taskOccursOn(task: Task, date: LocalDate = LocalDate.now()): Boolean {
        val baseDate = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return false
        if (date.isBefore(baseDate)) return false
        return when (task.repeat) {
            "Nunca" -> date == baseDate
            "Diaria" -> true
            "Semanal" -> {
                val selected = task.repeatDays.split(',').mapNotNull {
                    runCatching { DayOfWeek.valueOf(it) }.getOrNull()
                }.toSet().ifEmpty { setOf(baseDate.dayOfWeek) }
                date.dayOfWeek in selected
            }
            "Anual" -> date.monthValue == baseDate.monthValue &&
                date.dayOfMonth == baseDate.dayOfMonth.coerceAtMost(YearMonth.from(date).lengthOfMonth())
            "Mensual" -> {
                val wanted = if (task.monthlyDay in 1..31) task.monthlyDay else baseDate.dayOfMonth
                date.dayOfMonth == wanted.coerceAtMost(YearMonth.from(date).lengthOfMonth())
            }
            else -> false
        }
    }

    private fun statusFor(task: Task): String {
        if (isSkippedToday(task.id)) return "OMITIDA"
        if (isCompletedToday(task.id)) return "REALIZADA"
        if (!taskOccursOn(task)) return "PROGRAMADA"
        val time = runCatching { LocalTime.parse(task.time) }.getOrNull() ?: return "PENDIENTE"
        return if (time.isBefore(LocalTime.now())) "ATRASADA" else "PENDIENTE"
    }

    private fun statusColor(status: String): Int = when (status) {
        "REALIZADA" -> Color.rgb(220, 246, 226)
        "ATRASADA" -> Color.rgb(255, 229, 224)
        "PENDIENTE" -> Color.rgb(226, 239, 255)
        "OMITIDA" -> Color.rgb(238, 238, 238)
        else -> Color.rgb(245, 245, 245)
    }

    private fun statusTextColor(status: String): Int = when (status) {
        "REALIZADA" -> Color.rgb(20, 105, 50)
        "ATRASADA" -> Color.rgb(165, 35, 25)
        "PENDIENTE" -> Color.rgb(20, 72, 140)
        "OMITIDA" -> Color.rgb(90, 90, 90)
        else -> Color.DKGRAY
    }

    private fun statusLabel(status: String): String = when (status) {
        "REALIZADA" -> "✓ REALIZADA"
        "ATRASADA" -> "⚠ ATRASADA"
        "PENDIENTE" -> "• PENDIENTE"
        "OMITIDA" -> "⏭ OMITIDA HOY"
        else -> "○ PROGRAMADA"
    }

    private fun todayStatusSummary(): TextView {
        val todays = tasks.filter { taskOccursOn(it) }
        val done = todays.count { isCompletedToday(it.id) && !isSkippedToday(it.id) }
        val skipped = todays.count { isSkippedToday(it.id) }
        val overdue = todays.count { !isCompletedToday(it.id) && !isSkippedToday(it.id) && statusFor(it) == "ATRASADA" }
        val pending = (todays.size - done - skipped - overdue).coerceAtLeast(0)
        return TextView(this).apply {
            text = if (todays.isEmpty()) {
                "HOY  •  Sin actividades programadas"
            } else {
                "HOY  •  $done realizadas  •  $pending pendientes  •  $overdue atrasadas" +
                        if (skipped > 0) "  •  $skipped omitidas" else ""
            }
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(238, 242, 247))
            setPadding(12, 9, 12, 9)
        }
    }

    private fun statusLegend(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, 6, 0, 12)
        val items = listOf(
            "✓ Hecho" to "REALIZADA",
            "• Falta" to "PENDIENTE",
            "⚠ Pasó" to "ATRASADA"
        )
        items.forEach { (label, status) ->
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(statusTextColor(status))
                setBackgroundColor(statusColor(status))
                setPadding(6, 8, 6, 8)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(2, 0, 2, 0)
            })
        }
    }

    private fun completionPrefs() = getSharedPreferences("daily_completion", MODE_PRIVATE)
    private fun skipPrefs() = getSharedPreferences("steve_skipped", MODE_PRIVATE)

    private fun completionKey(taskId: Long): String = "${LocalDate.now()}_$taskId"
    private fun skipKey(taskId: Long): String = "${LocalDate.now()}_$taskId"

    private fun isSkippedToday(taskId: Long): Boolean =
        skipPrefs().getBoolean(skipKey(taskId), false)

    private fun setSkippedToday(taskId: Long, skipped: Boolean) {
        skipPrefs().edit().putBoolean(skipKey(taskId), skipped).apply()
    }

    private fun isCompletedToday(taskId: Long): Boolean =
        completionPrefs().getBoolean(completionKey(taskId), false)

    private fun setCompletedToday(taskId: Long, completed: Boolean) {
        completionPrefs().edit().putBoolean(completionKey(taskId), completed).apply()
    }

    private fun renderList() {
        list.removeAllViews()
        if (tasks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Todavía no hay actividades.\nPulse NUEVA ACTIVIDAD para comenzar."
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
                setPadding(4, 34, 4, 0)
            })
            return
        }

        val grouped = tasks
            .groupBy { it.groupId }
            .values
            .sortedWith(compareBy<List<Task>> { group -> group.minOf { it.date } }
                .thenBy { group -> group.minOf { it.time } })

        grouped.forEach { rawGroup ->
            val group = rawGroup.sortedBy { it.time }
            val first = group.first()
            val detail = when (first.repeat) {
                "Semanal" -> "Semanal: ${prettyDays(first.repeatDays, first.date)}"
                "Mensual" -> "Mensual: día ${if (first.monthlyDay > 0) first.monthlyDay else runCatching { LocalDate.parse(first.date).dayOfMonth }.getOrDefault(1)}"
                "Anual" -> "Anual: cumpleaños / aniversario"
                else -> first.repeat
            }
            val completedCount = group.count { isCompletedToday(it.id) && !isSkippedToday(it.id) }
            val skippedCount = group.count { isSkippedToday(it.id) }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(priorityColor(first.priority))
            }

            val header = TextView(this).apply {
                text = "${priorityIcon(first.priority)}  ${first.title}   •   $completedCount/${group.size} ✓" +
                        (if (skippedCount > 0) "   •   $skippedCount omitida(s)" else "") +
                        "\n${first.date}  •  $detail" +
                        (if (first.note.isNotBlank()) "\n${first.note}" else "")
                textSize = 19f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.BLACK)
                setPadding(8, 10, 8, 12)
                setOnClickListener { showEditor(first) }
            }
            card.addView(header)

            group.forEach { task ->
                val status = statusFor(task)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(4, 4, 4, 4)
                    setBackgroundColor(statusColor(status))
                }
                val done = CheckBox(this).apply {
                    isChecked = isCompletedToday(task.id)
                    isEnabled = !isSkippedToday(task.id)
                    text = if (isSkippedToday(task.id)) "–" else if (isChecked) "✓" else ""
                    textSize = 22f
                    setTextColor(if (isSkippedToday(task.id)) Color.GRAY else Color.rgb(0, 110, 55))
                    minWidth = 68
                    minHeight = 58
                    setPadding(6, 0, 8, 0)
                }
                val timeText = TextView(this).apply {
                    text = "${task.time}   ${statusLabel(status)}"
                    textSize = 19f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(statusTextColor(status))
                    setPadding(10, 12, 10, 12)
                    setOnClickListener { done.isChecked = !done.isChecked }
                }
                done.setOnCheckedChangeListener { _, checked ->
                    setCompletedToday(task.id, checked)
                    draw()
                }
                row.addView(done, LinearLayout.LayoutParams(72, LinearLayout.LayoutParams.WRAP_CONTENT))
                row.addView(timeText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                card.addView(row)
                card.addView(Space(this).apply { minimumHeight = 5 })
            }

            list.addView(card)
            list.addView(Space(this).apply { minimumHeight = 14 })
        }
    }

    private fun prettyDays(raw: String, date: String): String {
        val map = linkedMapOf(
            DayOfWeek.MONDAY to "Lun", DayOfWeek.TUESDAY to "Mar", DayOfWeek.WEDNESDAY to "Mié",
            DayOfWeek.THURSDAY to "Jue", DayOfWeek.FRIDAY to "Vie", DayOfWeek.SATURDAY to "Sáb",
            DayOfWeek.SUNDAY to "Dom"
        )
        val selected = raw.split(',').mapNotNull { runCatching { DayOfWeek.valueOf(it) }.getOrNull() }.toSet()
        val actual = if (selected.isEmpty()) setOf(runCatching { LocalDate.parse(date).dayOfWeek }.getOrDefault(DayOfWeek.MONDAY)) else selected
        return map.filterKeys { it in actual }.values.joinToString(", ")
    }

    private fun editText(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.BLACK)
        setHintTextColor(Color.DKGRAY)
        setBackgroundColor(Color.WHITE)
        textSize = 19f
        setPadding(12, 18, 12, 18)
    }

    private fun showMoreMenu() {
        val disabled = AlarmPause.isDisabled(this)
        val options = arrayOf(
            if (disabled) "▶ Habilitar alarmas" else "⏸ Deshabilitar alarmas",
            "💰 Finanzas",
            "👤 Mi nombre / alias"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("☰ Más opciones")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        if (disabled) {
                            AlarmPause.setDisabled(this, false)
                            AlarmHelper.rescheduleAll(this)
                            AlarmHelper.restoreSnoozes(this)
                            Toast.makeText(
                                this,
                                "Alarmas habilitadas. Se programaron solo los próximos avisos.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            AlarmPause.setDisabled(this, true)
                            TaskStore.load(this).forEach { AlarmHelper.cancel(this, it.id) }
                            Toast.makeText(
                                this,
                                "Alarmas deshabilitadas hasta que vuelvas a pulsar HABILITAR.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        draw()
                    }
                    1 -> showFinances()
                    2 -> showProfile()
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun listPrefs() = getSharedPreferences("steve_lists", MODE_PRIVATE)
    private fun loadArray(key: String): JSONArray = runCatching { JSONArray(listPrefs().getString(key, "[]")) }.getOrDefault(JSONArray())
    private fun saveArray(key: String, arr: JSONArray) = listPrefs().edit().putString(key, arr.toString()).apply()


    private fun profilePrefs() = getSharedPreferences("steve_profile", MODE_PRIVATE)

    private fun userName(): String = profilePrefs().getString("user_name", "")?.trim().orEmpty()

    private fun userGreeting(): String {
        val name = userName()
        return if (name.isBlank()) "" else ", $name"
    }

    private fun showProfile() {
        val input = editText("Tu nombre o alias", userName())
        android.app.AlertDialog.Builder(this)
            .setTitle("👤 Personalizar STEVE Daily")
            .setMessage("Este nombre se mostrará únicamente en tu dispositivo.")
            .setView(input)
            .setPositiveButton("GUARDAR") { _, _ ->
                profilePrefs().edit().putString("user_name", input.text.toString().trim()).apply()
                draw()
            }
            .setNeutralButton("BORRAR") { _, _ ->
                profilePrefs().edit().remove("user_name").apply()
                draw()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun financePrefs() = getSharedPreferences("steve_finances", MODE_PRIVATE)
    private fun loadFinanceArray(): JSONArray = runCatching {
        JSONArray(financePrefs().getString("movements", "[]"))
    }.getOrDefault(JSONArray())
    private fun saveFinanceArray(arr: JSONArray) = financePrefs().edit().putString("movements", arr.toString()).apply()

    private fun showFinances() {
        val arr = loadFinanceArray()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,12,20,12) }
        val concept = editText("Concepto", "")
        val amount = editText("Monto", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Entrada", "Salida"))
        }
        val note = editText("Nota opcional", "")
        box.addView(concept); box.addView(amount); box.addView(type); box.addView(note)
        val add = Button(this).apply { text = "＋ REGISTRAR MOVIMIENTO" }
        box.addView(add)
        val totals = TextView(this).apply { textSize = 18f; setTextColor(Color.BLACK); setPadding(4,14,4,12); setTypeface(typeface, Typeface.BOLD) }
        box.addView(totals)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)

        fun render() {
            items.removeAllViews()
            var income = 0.0
            var expense = 0.0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val value = o.optDouble("amount", 0.0)
                val movementType = o.optString("type", "Entrada")
                if (movementType == "Salida") expense += value else income += value
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8) }
                val info = TextView(this).apply {
                    val sign = if (movementType == "Salida") "−" else "+"
                    val extra = o.optString("note", "").takeIf { it.isNotBlank() }?.let { "\n$it" } ?: ""
                    text = "${o.optString("date")}  •  $movementType\n${o.optString("concept")}   $sign ₡${"%.0f".format(value)}$extra"
                    textSize = 17f
                    setTextColor(Color.BLACK)
                }
                val del = Button(this).apply {
                    text = "ELIMINAR"
                    setOnClickListener { arr.remove(i); saveFinanceArray(arr); render() }
                }
                row.addView(info); row.addView(del); items.addView(row)
            }
            totals.text = "Entradas: ₡${"%.0f".format(income)}   •   Salidas: ₡${"%.0f".format(expense)}\nSaldo: ₡${"%.0f".format(income - expense)}"
        }

        add.setOnClickListener {
            val c = concept.text.toString().trim()
            val a = amount.text.toString().toDoubleOrNull()
            if (c.isBlank() || a == null || a <= 0.0) {
                Toast.makeText(this, "Escribe un concepto y un monto válido.", Toast.LENGTH_LONG).show()
            } else {
                arr.put(JSONObject()
                    .put("date", LocalDate.now().toString())
                    .put("type", type.selectedItem.toString())
                    .put("concept", c)
                    .put("amount", a)
                    .put("note", note.text.toString().trim()))
                saveFinanceArray(arr)
                concept.setText(""); amount.setText(""); note.setText("")
                render()
            }
        }
        render()
        android.app.AlertDialog.Builder(this)
            .setTitle("💰 Finanzas")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("CERRAR", null)
            .show()
    }

    private fun showTodo() {
        val arr = loadArray("todo")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,12,20,12) }
        val input = editText("Nueva tarea", "")
        box.addView(input)
        val add = Button(this).apply { text = "＋ AGREGAR" }
        box.addView(add)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)
        fun render() {
            items.removeAllViews()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val cb = CheckBox(this).apply { text = o.optString("text"); textSize = 18f; isChecked = o.optBoolean("done") }
                cb.setOnCheckedChangeListener { _, v -> o.put("done",v); saveArray("todo",arr) }
                val del = Button(this).apply { text = "✕"; setOnClickListener { arr.remove(i); saveArray("todo",arr); render() } }
                row.addView(cb, LinearLayout.LayoutParams(0,-2,1f)); row.addView(del)
                items.addView(row)
            }
        }
        add.setOnClickListener { val t=input.text.toString().trim(); if(t.isNotEmpty()){ arr.put(JSONObject().put("text",t).put("done",false)); saveArray("todo",arr); input.setText(""); render() } }
        render()
        android.app.AlertDialog.Builder(this).setTitle("✓ TO DO").setView(ScrollView(this).apply{addView(box)}).setPositiveButton("CERRAR",null).show()
    }

    private fun showToBuy() {
        val arr = loadArray("tobuy")

        // Migra silenciosamente compras antiguas para poder editarlas y reordenarlas sin perder datos.
        var migrated = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.has("id")) {
                o.put("id", System.currentTimeMillis() + i)
                migrated = true
            }
            if (!o.has("place")) {
                o.put("place", "")
                migrated = true
            }
        }
        if (migrated) saveArray("tobuy", arr)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 12, 20, 12)
        }
        val name = editText("Producto", "")
        val qty = editText("Cantidad", "1").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val ref = editText("Precio referencia", "").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val real = editText("Precio real (puedes completarlo después)", "").apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        val place = editText("Dónde comprar / lugar de compra", "")
        box.addView(name); box.addView(qty); box.addView(ref); box.addView(real); box.addView(place)

        val add = Button(this).apply { text = "＋ AGREGAR COMPRA" }
        box.addView(add)
        box.addView(TextView(this).apply {
            text = "Al marcar ✓ comprado, el artículo pasa a COMPRADOS. Allí sigue editable para completar el precio real al revisar la factura."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(4, 8, 4, 10)
        })

        val totals = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.BLACK)
            setPadding(4, 10, 4, 10)
            setTypeface(typeface, Typeface.BOLD)
        }
        box.addView(totals)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)

        fun placeOf(o: JSONObject): String = o.optString("place", "").trim().ifBlank { "Sin lugar definido" }
        fun money(v: Double): String = "₡${"%.0f".format(v)}"
        fun numberText(v: Double): String = BigDecimal.valueOf(v).stripTrailingZeros().toPlainString()
        fun indexFor(id: Long): Int {
            for (i in 0 until arr.length()) if (arr.getJSONObject(i).optLong("id") == id) return i
            return -1
        }

        lateinit var render: () -> Unit

        fun editPurchase(o: JSONObject) {
            // El estado comprado/pendiente NO debe cambiar por editar precio, cantidad o tienda.
            val wasBought = o.optBoolean("bought")
            val boughtAtBeforeEdit = o.optString("boughtAt", "")
            val editBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 14, 24, 8)
            }
            val eName = editText("Producto", o.optString("name"))
            val eQty = editText("Cantidad", numberText(o.optDouble("qty", 1.0))).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val eRef = editText("Precio referencia", o.optDouble("ref", 0.0).takeIf { it != 0.0 }?.let { numberText(it) } ?: "").apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val eReal = editText("Precio real", o.optDouble("real", 0.0).takeIf { it != 0.0 }?.let { numberText(it) } ?: "").apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val ePlace = editText("Dónde comprar / lugar de compra", o.optString("place", ""))
            editBox.addView(eName); editBox.addView(eQty); editBox.addView(eRef); editBox.addView(eReal); editBox.addView(ePlace)

            android.app.AlertDialog.Builder(this)
                .setTitle(if (wasBought) "Editar compra realizada" else "Editar compra pendiente")
                .setView(editBox)
                .setPositiveButton("GUARDAR") { _, _ ->
                    val cleanName = eName.text.toString().trim()
                    if (cleanName.isBlank()) {
                        Toast.makeText(this, "El producto necesita un nombre.", Toast.LENGTH_LONG).show()
                    } else {
                        o.put("name", cleanName)
                        o.put("qty", eQty.text.toString().toDoubleOrNull() ?: 1.0)
                        o.put("ref", eRef.text.toString().toDoubleOrNull() ?: 0.0)
                        o.put("real", eReal.text.toString().toDoubleOrNull() ?: 0.0)
                        o.put("place", ePlace.text.toString().trim())
                        // Blindaje: editar datos nunca mueve el artículo entre Pendientes y Comprados.
                        o.put("bought", wasBought)
                        if (wasBought) {
                            o.put("boughtAt", boughtAtBeforeEdit.ifBlank { LocalDate.now().toString() })
                        } else {
                            o.remove("boughtAt")
                        }
                        saveArray("tobuy", arr)
                        render.invoke()
                    }
                }
                .setNegativeButton("CANCELAR", null)
                .show()
        }

        fun addProductRow(o: JSONObject) {
            val q = o.optDouble("qty", 1.0)
            val r = o.optDouble("ref", 0.0)
            val a = o.optDouble("real", 0.0)
            val bought = o.optBoolean("bought")
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(10, 8, 10, 10)
                setBackgroundColor(if (bought) Color.rgb(229, 246, 232) else Color.rgb(241, 246, 255))
            }
            val cb = CheckBox(this).apply {
                isChecked = bought
                text = "${o.optString("name")}  × ${numberText(q)}\nRef: ${money(r)}   •   Real: ${money(a)}" +
                        o.optString("boughtAt", "").takeIf { bought && it.isNotBlank() }?.let { "\nComprado: $it" }.orEmpty()
                textSize = 17f
                setTextColor(Color.BLACK)
                setPadding(4, 6, 4, 6)
            }
            cb.setOnCheckedChangeListener { _, checked ->
                o.put("bought", checked)
                if (checked) o.put("boughtAt", LocalDate.now().toString()) else o.remove("boughtAt")
                saveArray("tobuy", arr)
                render.invoke()
            }
            row.addView(cb)

            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply {
                text = "EDITAR"
                setOnClickListener { editPurchase(o) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            actions.addView(Button(this).apply {
                text = "ELIMINAR"
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Eliminar producto")
                        .setMessage("¿Eliminar ${o.optString("name")} del registro de compras?")
                        .setPositiveButton("ELIMINAR") { _, _ ->
                            val index = indexFor(o.optLong("id"))
                            if (index >= 0) arr.remove(index)
                            saveArray("tobuy", arr)
                            render.invoke()
                        }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(actions)
            items.addView(row)
            items.addView(Space(this).apply { minimumHeight = 8 })
        }

        fun addGroupedSection(title: String, entries: List<JSONObject>) {
            items.addView(TextView(this).apply {
                text = "$title (${entries.size})"
                textSize = 20f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.BLACK)
                setPadding(4, 18, 4, 8)
            })
            if (entries.isEmpty()) {
                items.addView(TextView(this).apply {
                    text = if (title.startsWith("PENDIENTES")) "No hay compras pendientes." else "Todavía no hay compras registradas como realizadas."
                    textSize = 16f
                    setTextColor(Color.DKGRAY)
                    setPadding(8, 8, 8, 10)
                })
                return
            }
            val grouped = entries.groupBy { placeOf(it) }
                .toSortedMap(String.CASE_INSENSITIVE_ORDER)
            grouped.forEach { (store, storeItems) ->
                items.addView(TextView(this).apply {
                    text = "📍 $store"
                    textSize = 18f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.rgb(30, 70, 125))
                    setPadding(8, 12, 8, 6)
                })
                storeItems.sortedBy { it.optString("name").lowercase(Locale.getDefault()) }.forEach { addProductRow(it) }
            }
        }

        render = {
            items.removeAllViews()
            val all = (0 until arr.length()).map { arr.getJSONObject(it) }
            val pending = all.filter { !it.optBoolean("bought") }
            val bought = all.filter { it.optBoolean("bought") }
            val pendingEstimate = pending.sumOf { it.optDouble("qty", 1.0) * it.optDouble("ref", 0.0) }
            val boughtReal = bought.sumOf { it.optDouble("qty", 1.0) * it.optDouble("real", 0.0) }
            totals.text = "Pendiente estimado: ${money(pendingEstimate)}   •   Real comprado: ${money(boughtReal)}"
            addGroupedSection("PENDIENTES", pending)
            addGroupedSection("COMPRADOS", bought)
        }

        add.setOnClickListener {
            val n = name.text.toString().trim()
            if (n.isBlank()) {
                Toast.makeText(this, "Escribe el producto.", Toast.LENGTH_LONG).show()
            } else {
                val q = qty.text.toString().toDoubleOrNull() ?: 1.0
                val r = ref.text.toString().toDoubleOrNull() ?: 0.0
                val a = real.text.toString().toDoubleOrNull() ?: 0.0
                arr.put(
                    JSONObject()
                        .put("id", System.currentTimeMillis())
                        .put("name", n)
                        .put("qty", q)
                        .put("ref", r)
                        .put("real", a)
                        .put("place", place.text.toString().trim())
                        .put("bought", false)
                )
                saveArray("tobuy", arr)
                name.setText(""); qty.setText("1"); ref.setText(""); real.setText("")
                render.invoke()
            }
        }

        render.invoke()
        android.app.AlertDialog.Builder(this)
            .setTitle("🛒 TO BUY")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("CERRAR", null)
            .show()
    }

    private fun showEditor(existing: Task?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 10)
            setBackgroundColor(Color.WHITE)
        }
        val title = editText("¿Qué debo recordar?", existing?.title ?: "")
        var selectedDate = if (existing == null) LocalDate.now() else
            runCatching { LocalDate.parse(existing.date) }.getOrDefault(LocalDate.now())
        val dateButton = Button(this).apply {
            text = "📅 Fecha: $selectedDate"
            textSize = 18f
            setTextColor(Color.BLACK)
        }
        dateButton.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                selectedDate = LocalDate.of(y, m + 1, d)
                dateButton.text = "📅 Fecha: $selectedDate"
            }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show()
        }

        val defaultTime = existing?.time ?: LocalTime.now().plusMinutes(2).withSecond(0).withNano(0).toString().substring(0, 5)
        val existingGroup = if (existing == null) emptyList() else tasks.filter { it.groupId == existing.groupId }.sortedBy { it.time }
        val selectedTimes = if (existingGroup.isNotEmpty()) existingGroup.map { it.time }.distinct().sorted().toMutableList() else mutableListOf(defaultTime)
        val timesLabel = TextView(this).apply {
            text = "Horarios de esta actividad"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setPadding(4, 18, 4, 6)
        }
        val timesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun chooseTime(initial: String, onChosen: (String) -> Unit) {
            val parsed = runCatching { LocalTime.parse(initial) }.getOrDefault(LocalTime.now())
            TimePickerDialog(this, { _, hourOfDay, minute ->
                onChosen(String.format(Locale.US, "%02d:%02d", hourOfDay, minute))
            }, parsed.hour, parsed.minute, true).show()
        }

        fun renderTimes() {
            timesBox.removeAllViews()
            selectedTimes.forEachIndexed { index, value ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 4, 0, 4)
                }
                val timeButton = Button(this).apply {
                    text = "⏰  $value"
                    textSize = 19f
                    setTextColor(Color.BLACK)
                    minHeight = 60
                    setOnClickListener {
                        chooseTime(selectedTimes[index]) { chosen ->
                            selectedTimes[index] = chosen
                            renderTimes()
                        }
                    }
                }
                row.addView(timeButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                if (selectedTimes.size > 1) {
                    row.addView(Button(this).apply {
                        text = "✕"
                        textSize = 20f
                        contentDescription = "Eliminar horario $value"
                        minWidth = 64
                        minHeight = 60
                        setOnClickListener {
                            selectedTimes.removeAt(index)
                            renderTimes()
                        }
                    })
                }
                timesBox.addView(row)
            }
        }
        renderTimes()

        val addTimeButton = Button(this).apply {
            text = "＋ AGREGAR OTRO HORARIO"
            textSize = 18f
            setTextColor(Color.BLACK)
            minHeight = 60
            setOnClickListener {
                val initial = selectedTimes.lastOrNull() ?: defaultTime
                chooseTime(initial) { chosen ->
                    if (chosen !in selectedTimes) {
                        selectedTimes.add(chosen)
                        selectedTimes.sort()
                        renderTimes()
                    } else {
                        Toast.makeText(this@MainActivity, "Ese horario ya está agregado.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        val timeHint = TextView(this).apply {
            text = "Cada horario tendrá su propia alarma y su propio ✓ diario."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 10)
        }

        val options = arrayOf("Nunca", "Diaria", "Semanal", "Mensual", "Anual")
        val repeat = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            existing?.let { setSelection(options.indexOf(it.repeat).coerceAtLeast(0)) }
        }

        val priorityLabel = TextView(this).apply {
            text = "Prioridad"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(4, 16, 4, 4)
        }
        val priorities = arrayOf("Verde", "Amarillo", "Rojo")
        val priority = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, priorities)
            setSelection(priorities.indexOf(existing?.priority ?: "Verde").coerceAtLeast(0))
        }

        val weeklyLabel = TextView(this).apply {
            text = "Días de la semana"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(4, 18, 4, 4)
        }
        val daysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dayInfo = listOf(
            DayOfWeek.MONDAY to "Lunes", DayOfWeek.TUESDAY to "Martes", DayOfWeek.WEDNESDAY to "Miércoles",
            DayOfWeek.THURSDAY to "Jueves", DayOfWeek.FRIDAY to "Viernes", DayOfWeek.SATURDAY to "Sábado",
            DayOfWeek.SUNDAY to "Domingo"
        )
        val existingDays = existing?.repeatDays?.split(',')?.toSet() ?: emptySet()
        val checks = dayInfo.map { (day, label) ->
            CheckBox(this).apply {
                text = label
                textSize = 18f
                setTextColor(Color.BLACK)
                isChecked = day.name in existingDays || (existingDays.isEmpty() && existing?.repeat == "Semanal" &&
                        runCatching { LocalDate.parse(existing.date).dayOfWeek }.getOrNull() == day)
                tag = day.name
                daysBox.addView(this)
            }
        }
        val dayShortcuts = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dayShortcuts.addView(Button(this).apply {
            text = "LUN–VIE"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener {
                checks.forEachIndexed { index, check -> check.isChecked = index < 5 }
            }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dayShortcuts.addView(Button(this).apply {
            text = "TODOS"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener { checks.forEach { it.isChecked = true } }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dayShortcuts.addView(Button(this).apply {
            text = "LIMPIAR"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener { checks.forEach { it.isChecked = false } }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        daysBox.addView(dayShortcuts)
        val monthlyHint = TextView(this).apply {
            text = "📅 En Mensual, el día elegido en el calendario será el día de repetición."
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(4, 14, 4, 10)
        }

        val annualHint = TextView(this).apply {
            text = "🎂 En Anual, se repetirá cada año en el mes y día que elijas en el calendario."
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(4, 12, 4, 10)
        }

        fun updateRepeatUi(position: Int) {
            val weekly = options[position] == "Semanal"
            val monthly = options[position] == "Mensual"
            weeklyLabel.visibility = if (weekly) View.VISIBLE else View.GONE
            daysBox.visibility = if (weekly) View.VISIBLE else View.GONE
            monthlyHint.visibility = if (monthly) View.VISIBLE else View.GONE
            annualHint.visibility = if (options[position] == "Anual") View.VISIBLE else View.GONE
        }
        repeat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = updateRepeatUi(position)
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val note = editText("Notas opcionales", existing?.note ?: "")
        box.addView(title); box.addView(dateButton); box.addView(timesLabel); box.addView(timesBox); box.addView(addTimeButton); box.addView(timeHint)
        box.addView(repeat); box.addView(priorityLabel); box.addView(priority)
        box.addView(weeklyLabel); box.addView(daysBox); box.addView(monthlyHint); box.addView(annualHint); box.addView(note)
        updateRepeatUi(repeat.selectedItemPosition)

        val builder = android.app.AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Nueva actividad" else "Editar actividad")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("GUARDAR Y ACTIVAR") { _, _ ->
                val repeatType = repeat.selectedItem.toString()
                val selectedDays = checks.filter { it.isChecked }.joinToString(",") { it.tag.toString() }
                val cleanTitle = title.text.toString().trim()
                if (cleanTitle.isBlank()) {
                    Toast.makeText(this, "Escribe el mensaje de la alarma.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (repeatType == "Semanal" && selectedDays.isBlank()) {
                    Toast.makeText(this, "Marca al menos un día para la repetición semanal.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                val validTimes = selectedTimes.distinct().sorted().filter { runCatching { LocalTime.parse(it) }.isSuccess }
                if (validTimes.isEmpty()) {
                    Toast.makeText(this, "Escribe una hora válida, por ejemplo 06:30.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                // Para actividades de una sola vez, impedir guardar una fecha/hora ya pasada.
                if (repeatType == "Nunca") {
                    val now = java.time.LocalDateTime.now()
                    val hasFutureTime = validTimes.any { alarmTime ->
                        runCatching { java.time.LocalDateTime.of(selectedDate, LocalTime.parse(alarmTime)).isAfter(now) }.getOrDefault(false)
                    }
                    if (!hasFutureTime) {
                        Toast.makeText(this, "La fecha y hora ya pasaron. Elige hoy con una hora futura u otra fecha.", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                }

                if (existing != null) {
                    val oldGroup = tasks.filter { it.groupId == existing.groupId }
                    oldGroup.forEach { AlarmHelper.cancel(this, it.id) }
                    tasks.removeAll { it.groupId == existing.groupId }

                    val oldIds = oldGroup.sortedBy { it.time }.map { it.id }
                    val groupId = existing.groupId
                    validTimes.forEachIndexed { index, alarmTime ->
                        val taskId = oldIds.getOrNull(index) ?: (System.currentTimeMillis() + index)
                        val updated = Task(
                            taskId, cleanTitle, selectedDate.toString(), alarmTime, repeatType,
                            note.text.toString().trim(),
                            if (repeatType == "Semanal") selectedDays else "",
                            if (repeatType == "Mensual") selectedDate.dayOfMonth else 0,
                            priority.selectedItem.toString(),
                            groupId
                        )
                        tasks.add(updated)
                        AlarmHelper.schedule(this, updated)
                    }
                    TaskStore.save(this, tasks)
                } else {
                    val baseId = System.currentTimeMillis()
                    validTimes.forEachIndexed { index, alarmTime ->
                        val task = Task(
                            baseId + index, cleanTitle, selectedDate.toString(), alarmTime, repeatType,
                            note.text.toString().trim(),
                            if (repeatType == "Semanal") selectedDays else "",
                            if (repeatType == "Mensual") selectedDate.dayOfMonth else 0,
                            priority.selectedItem.toString(),
                            baseId
                        )
                        tasks.add(task)
                        AlarmHelper.schedule(this, task)
                    }
                    TaskStore.save(this, tasks)
                }
                Toast.makeText(
                    this,
                    if (AlarmPause.isDisabled(this))
                        "${validTimes.size} actividad(es) guardada(s). Las alarmas siguen deshabilitadas."
                    else "${validTimes.size} alarma(s) activada(s)",
                    Toast.LENGTH_LONG
                ).show()
                draw()
            }
            .setNegativeButton("CANCELAR", null)

        if (existing != null) builder.setNeutralButton("🗑 ELIMINAR") { _, _ ->
            showDeleteOptions(existing)
        }
        builder.show()
    }

    private fun showDeleteOptions(existing: Task) {
        val group = tasks.filter { it.groupId == existing.groupId }
        val recurring = group.any { it.repeat != "Nunca" }

        fun deleteForever() {
            group.forEach { task ->
                AlarmHelper.cancel(this, task.id)
                setSkippedToday(task.id, false)
                setCompletedToday(task.id, false)
            }
            tasks.removeAll { it.groupId == existing.groupId }
            TaskStore.save(this, tasks)
            Toast.makeText(this, "Actividad eliminada.", Toast.LENGTH_LONG).show()
            draw()
        }

        if (recurring) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar actividad recurrente")
                .setMessage("Puedes omitir solamente las ocurrencias de hoy o eliminar toda la actividad y sus horarios futuros.")
                .setPositiveButton("ELIMINAR TODA") { _, _ ->
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Confirmar eliminación")
                        .setMessage("¿Eliminar definitivamente ${existing.title} y toda su serie futura?")
                        .setPositiveButton("SÍ, ELIMINAR") { _, _ -> deleteForever() }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                }
                .setNeutralButton("OMITIR SOLO HOY") { _, _ ->
                    group.forEach { setSkippedToday(it.id, true) }
                    Toast.makeText(this, "Actividad omitida solo por hoy. Mañana seguirá programada.", Toast.LENGTH_LONG).show()
                    draw()
                }
                .setNegativeButton("CANCELAR", null)
                .show()
        } else {
            android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar actividad")
                .setMessage("¿Eliminar definitivamente ${existing.title}?")
                .setPositiveButton("ELIMINAR") { _, _ -> deleteForever() }
                .setNegativeButton("CANCELAR", null)
                .show()
        }
    }
}
