package com.stevedaily.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object TaskStore {
    private const val KEY = "tasks_json"

    fun load(context: Context): MutableList<Task> {
        val sp = context.getSharedPreferences("steve_daily", Context.MODE_PRIVATE)
        val raw = sp.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val out = mutableListOf<Task>()
        val legacyGroups = mutableMapOf<String, Long>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getLong("id")
            val legacyKey = listOf(
                o.optString("title", ""), o.optString("date", ""), o.optString("repeat", "Nunca"),
                o.optString("note", ""), o.optString("repeatDays", ""),
                o.optInt("monthlyDay", 0).toString(), o.optString("priority", "Verde")
            ).joinToString("|")
            val resolvedGroupId = if (o.has("groupId")) o.optLong("groupId", id)
            else legacyGroups.getOrPut(legacyKey) { id }
            out.add(
                Task(
                    id,
                    o.getString("title"),
                    o.getString("date"),
                    o.getString("time"),
                    o.optString("repeat", "Nunca"),
                    o.optString("note", ""),
                    o.optString("repeatDays", ""),
                    o.optInt("monthlyDay", 0),
                    o.optString("priority", "Verde"),
                    resolvedGroupId
                )
            )
        }
        return out
    }

    fun save(context: Context, tasks: List<Task>) {
        val arr = JSONArray()
        tasks.forEach { t ->
            arr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                put("date", t.date)
                put("time", t.time)
                put("repeat", t.repeat)
                put("note", t.note)
                put("repeatDays", t.repeatDays)
                put("monthlyDay", t.monthlyDay)
                put("priority", t.priority)
                put("groupId", t.groupId)
            })
        }
        context.getSharedPreferences("steve_daily", Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun find(context: Context, id: Long): Task? = load(context).find { it.id == id }
}
