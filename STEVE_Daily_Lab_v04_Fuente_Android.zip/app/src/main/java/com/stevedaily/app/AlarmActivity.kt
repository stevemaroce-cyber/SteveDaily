package com.stevedaily.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AlarmActivity : Activity(), TextToSpeech.OnInitListener {
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var text = "Recordatorio de STEVE Daily"
    private var taskId: Long = -1L
    private var alarmStarted = false
    private var stopped = false
    private var audioManager: AudioManager? = null
    private var previousAlarmVolume: Int? = null
    private var alarmVolumeForced = false
    private val handler = Handler(Looper.getMainLooper())

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // v1.16: despertar pantalla/CPU tan pronto como Android entrega la alarma.
        runCatching {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                "STEVE_Daily:AlarmScreenWake"
            ).apply { acquire(120_000L) }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        taskId = intent.getLongExtra("taskId", -1L)
        val task = TaskStore.find(this, taskId)
        text = task?.title ?: intent.getStringExtra("text") ?: text

        // La siguiente repetición se programa en AlarmReceiver, igual que en la ruta
        // estable que se había probado en el Honor 400.

        // Mantiene una notificación de alarma activa mientras esta pantalla está abierta.
        val serviceIntent = Intent(this, AlarmForegroundService::class.java).apply {
            putExtra("taskId", taskId)
            putExtra("text", text)
            putExtra("activityAlreadyVisible", true)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 90, 42, 42)
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "🔔 STEVE Daily"
            textSize = 30f
            setTextColor(android.graphics.Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = this@AlarmActivity.text
            textSize = 26f
            setTextColor(android.graphics.Color.BLACK)
            setPadding(0, 55, 0, 55)
        })
        root.addView(TextView(this).apply {
            text = "Si ahora no puedes atenderla, pospón este aviso:"
            textSize = 18f
            setTextColor(android.graphics.Color.DKGRAY)
            setPadding(0, 0, 0, 14)
        })
        for (minutes in listOf(5, 30, 60)) {
            root.addView(Button(this).apply {
                text = "⏱ POSPONER $minutes MIN"
                textSize = 20f
                minHeight = 64
                setTextColor(android.graphics.Color.BLACK)
                setOnClickListener { postponeAndClose(minutes) }
            })
        }
        root.addView(Button(this).apply {
            text = "DETENER"
            textSize = 22f
            minHeight = 64
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(180, 0, 0))
            setOnClickListener { stopAndClose() }
        })
        setContentView(android.widget.ScrollView(this).apply { addView(root) })

        // v1.16.4 ALARMA FUERTE:
        // Sube temporalmente SOLO el canal de ALARMA al máximo. Al detener,
        // restaura el volumen que tenía el teléfono antes del aviso.
        forceAlarmVolume()

        // El sonido ya no espera a que TTS termine de inicializar.
        // Si el motor de voz se atasca, igual hay alarma audible.
        handler.postDelayed({ if (!stopped) startAlarmSoundAndVibration() }, 500)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (stopped || status != TextToSpeech.SUCCESS) return
        tts?.language = Locale("es", "CR")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            tts?.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { runCatching { player?.setVolume(0.18f, 0.18f) } }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread { runCatching { player?.setVolume(1f, 1f) } }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { runCatching { player?.setVolume(1f, 1f) } }
            }
        })
        val userName = getSharedPreferences("steve_profile", MODE_PRIVATE)
            .getString("user_name", "")
            ?.trim()
            .orEmpty()
        val spokenMessage = if (userName.isNotBlank()) {
            "$userName, atención. $text"
        } else {
            "STEVE Daily te recuerda. $text"
        }
        tts?.speak(
            spokenMessage,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "steve_alarm_message"
        )
    }

    @Synchronized
    private fun startAlarmSoundAndVibration() {
        if (alarmStarted || stopped || isFinishing) return
        alarmStarted = true

        forceAlarmVolume()

        try {
            val alarmAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            player = MediaPlayer.create(this, R.raw.steve_alarm, alarmAttributes, 0)?.apply {
                isLooping = true
                setVolume(1f, 1f)
                start()
            }
        } catch (_: Exception) {
            player = null
        }

        val pattern = longArrayOf(0, 550, 350, 550, 700)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                .defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(pattern, 0)
        }
    }


    private fun forceAlarmVolume() {
        runCatching {
            val manager = audioManager ?: (getSystemService(AUDIO_SERVICE) as AudioManager).also {
                audioManager = it
            }
            if (!alarmVolumeForced) {
                previousAlarmVolume = manager.getStreamVolume(AudioManager.STREAM_ALARM)
                alarmVolumeForced = true
            }
            val max = manager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (max > 0) {
                manager.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
            }
        }
    }

    private fun restoreAlarmVolume() {
        if (!alarmVolumeForced) return
        runCatching {
            val manager = audioManager ?: (getSystemService(AUDIO_SERVICE) as AudioManager)
            val max = manager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            previousAlarmVolume?.let { previous ->
                manager.setStreamVolume(AudioManager.STREAM_ALARM, previous.coerceIn(0, max), 0)
            }
        }
        previousAlarmVolume = null
        alarmVolumeForced = false
        audioManager = null
    }

    private fun postponeAndClose(minutes: Int) {
        if (stopped) return
        val ok = AlarmHelper.snooze(this, taskId, text, minutes)
        if (!ok) {
            android.widget.Toast.makeText(this,
                "No se pudo posponer. Revisa permiso de Alarmas y recordatorios.",
                android.widget.Toast.LENGTH_LONG).show()
            return
        }
        android.widget.Toast.makeText(this,
            "Aviso pospuesto $minutes minutos", android.widget.Toast.LENGTH_LONG).show()
        stopAndClose()
    }

    private fun stopAndClose() {
        stopped = true
        alarmStarted = false
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { tts?.stop() }
        stopVibration()
        restoreAlarmVolume()
        releaseWakeLock()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .cancel(AlarmForegroundService.NOTIFICATION_ID)
        stopService(Intent(this, AlarmForegroundService::class.java))
        finishAndRemoveTask()
    }

    private fun stopVibration() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching { (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.cancel() }
        } else {
            @Suppress("DEPRECATION")
            runCatching { (getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel() }
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            wakeLock?.let { if (it.isHeld) it.release() }
        }
        wakeLock = null
    }

    override fun onDestroy() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        stopVibration()
        restoreAlarmVolume()
        releaseWakeLock()
        super.onDestroy()
    }
}
