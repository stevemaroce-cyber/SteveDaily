package com.stevedaily.app

data class Task(
    val id: Long,
    var title: String,
    var date: String,
    var time: String,
    var repeat: String,
    var note: String,
    var repeatDays: String = "",
    var monthlyDay: Int = 0,
    var priority: String = "Verde",
    var groupId: Long = id
)
