package com.stevedaily.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager

class AlarmReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra("taskId", -1L)
        val isSnooze = intent.action == AlarmHelper.ACTION_SNOOZE
        if (isSnooze) AlarmHelper.clearSnooze(context, taskId)
        val task = TaskStore.find(context, taskId) ?: return
        val today = java.time.LocalDate.now().toString()
        val alarmsDisabled = AlarmPause.isDisabled(context)
        val skippedToday = context.getSharedPreferences("steve_skipped", Context.MODE_PRIVATE)
            .getBoolean("${today}_$taskId", false)
        val completedToday = context.getSharedPreferences("daily_completion", Context.MODE_PRIVATE)
            .getBoolean("${today}_$taskId", false)

        if (alarmsDisabled) return
        // Es imprescindible rearmar mañana ANTES de omitir una alarma de hoy.
        if (!isSnooze && task.repeat != "Nunca") AlarmHelper.schedule(context, task)
        if (skippedToday || completedToday) return

        // Respaldo v1.16: fuerza un despertar breve antes de arrancar el servicio.
        // timeout evita que el teléfono quede despierto si algo falla.
        runCatching {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                "STEVE_Daily:BackupAlarmWake"
            )
            wakeLock.acquire(60_000L)
        }

        // Diagnostico: distingue actividad vencida de alarma realmente recibida.
        context.getSharedPreferences("steve_alarm_diag", Context.MODE_PRIVATE).edit()
            .putLong("last_receiver_received_ms", System.currentTimeMillis())
            .putString("last_receiver_task", task.title)
            .apply()

        val serviceIntent = Intent(context, AlarmForegroundService::class.java).apply {
            putExtra("taskId", taskId)
            putExtra("text", intent.getStringExtra("text"))
            putExtra("activityAlreadyVisible", false)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }

    }
}
