# STEVE Daily Lab 0.4 — recuperar repeticiones y varios horarios

**Proyecto fuente Android para pruebas.** Este archivo ZIP **NO ES UNA APK**: hay que compilarlo con GitHub Actions y comprobar las alarmas en un teléfono antes de usarlo como agenda principal.

## Funciones recuperadas y conservadas

- Repetición **una vez**, **todos los días**, **semanal** (marcar varios días), **mensual** (día del mes) y **anual** (cumpleaños/aniversarios).
- **Hasta 8 horarios** dentro de una misma actividad; cada uno tiene su alarma y su estado **Realizado** independiente.
- Mantiene tarjetas separadas, colores y botones grandes, editar o borrar con confirmación.
- Mantiene alarmas con voz TTS y botones **Posponer 5, 30 o 60 minutos** de las versiones anteriores.
- Mantiene **Guardar respaldo** / **Recuperar respaldo**: archivos JSON compatibles con Lab 0.2 y Lab 0.3. La importación agrega actividades y omite duplicados.
- **Una vez** admite varios horarios durante el día seleccionado. **Semanal** permite marcar más de un día. Las fechas de un cumpleaños se repiten anualmente. Si se marca como realizado un horario recurrente, ese horario no sonará otra vez *hoy*, pero se programa para la siguiente ocurrencia. No afecta las otras horas de la misma actividad.

## Detalles y limitaciones

- Los meses que no tengan el día elegido (ej. 31 de febrero) se saltan. El 29 de febrero anual solo se programa en años bisiestos.
- Versión independiente (`com.stevedaily.lab.v04`), vacía al instalar: **no elimina ni cambia** las anteriores. Para recuperar actividades, exporta desde la Lab 0.2/0.3 e importa en la Lab 0.4.
- No puede copiar automáticamente actividades de la Steve Daily original sin una exportación compatible. No desinstales ninguna versión sin respaldar antes.
- El software aún no ha sido compilado ni probado en un Android real como 0.4 en este entorno. Es imprescindible comprobar cada modalidad de recurrencia, reprogramación, voz, permisos y pantalla apagada.
- Los respaldos contienen nombres de actividades en texto claro: consérvalos en un lugar privado.

## Compilar desde el Honor sin computadora

1. Sube `STEVE_Daily_Lab_v04_Fuente_Android.zip` a la raíz del repositorio `stevemaroce-cyber/SteveDaily` usando GitHub en Chrome.
2. Edita `.github/workflows/build-lab.yml`, reemplazando **únicamente** la línea `run: unzip ... -d lab` por (respetando ocho espacios al inicio):

```yaml
        run: unzip -q STEVE_Daily_Lab_v04_Fuente_Android.zip -d lab
```

3. Guarda con **Commit changes**. Verifica en **Actions** que la nueva compilación termine en verde.
4. Descarga el artefacto `STEVE-Daily-Lab-APK` del **último trabajo**, extrae el ZIP y abre `app-debug.apk` en el Honor.
5. Autoriza Alarmas y recordatorios, notificaciones y, cuando corresponda, avisos de pantalla completa. Prueba avisos con pantalla apagada antes de confiar en ellos.

No cambies el identificador del paquete para reemplazar la app anterior sin preservar sus datos. Las APK de depuración pueden estar firmadas con claves distintas entre compilaciones.
