import com.stevedaily.app.ToBuyCalculations

fun main() {
    val a = ToBuyCalculations
    val prices = listOf(
        ToBuyCalculations.PaidPrice("Arroz", "Super A", 1050.0, "2026-10-12", 1L),
        ToBuyCalculations.PaidPrice("Arroz", "Super A", 1125.0, "2026-11-12", 2L),
        ToBuyCalculations.PaidPrice("Arroz", "Super B", 1200.0, "2026-11-14", 3L),
        ToBuyCalculations.PaidPrice("Café", "Super A", 4500.0, "2026-11-13", 4L),
        ToBuyCalculations.PaidPrice("Arroz", "Super A", 0.0, "2026-11-15", 5L)
    )
    check(a.lastPaidPrice(prices, " ARROZ ", "Super A") == 1125.0)
    check(a.lastPaidPrice(prices, "arroz", "Super B") == 1200.0)
    check(a.lastPaidPrice(prices, "arroz", "") == 1200.0)
    check(a.lastPaidPrice(prices, "Producto inexistente", "Super A") == null)
    check(a.monthOf("2026-11-14") == "2026-11")
    check(a.monthOf("fecha sin registrar") == "")
    check(a.lineTotal(3.0, 1125.0) == 3375.0)
    check(prices.count { a.monthOf(it.boughtAt) == "2026-11" } == 4)
    println("8 comprobaciones de reglas To Buy superadas")
}
