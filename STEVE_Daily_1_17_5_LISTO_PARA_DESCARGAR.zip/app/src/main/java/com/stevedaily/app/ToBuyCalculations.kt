package com.stevedaily.app

import java.time.YearMonth
import java.util.Locale

/** Reglas independientes de Android; facilitan pruebas repetibles de To Buy. */
object ToBuyCalculations {
    data class PaidPrice(
        val product: String,
        val place: String,
        val unitPrice: Double,
        val boughtAt: String,
        val purchaseId: Long
    )

    fun monthOf(date: String): String {
        if (date.length < 7) return ""
        return runCatching { YearMonth.parse(date.take(7)).toString() }.getOrDefault("")
    }

    fun lineTotal(quantity: Double, unitPrice: Double): Double = quantity * unitPrice

    fun lastPaidPrice(history: List<PaidPrice>, product: String, place: String): Double? {
        val name = product.trim().lowercase(Locale.ROOT)
        if (name.isBlank()) return null
        val sameProduct = history.filter {
            it.product.trim().lowercase(Locale.ROOT) == name && it.unitPrice > 0.0
        }
        val store = place.trim().lowercase(Locale.ROOT)
        val matchedStore = sameProduct.filter { it.place.trim().lowercase(Locale.ROOT) == store }
        val records = if (store.isNotBlank() && matchedStore.isNotEmpty()) matchedStore else sameProduct
        return records.maxWithOrNull(compareBy<PaidPrice> { it.boughtAt }
            .thenBy { it.purchaseId })?.unitPrice
    }
}
