package com.stevedaily.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import android.view.Gravity
import android.view.View
import android.widget.*
import java.math.BigDecimal
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private var tasks = mutableListOf<Task>()
    private var tab = 0 // 0 Hoy, 1 Semana, 2 Mes, 3 Año, 4 Próximas, 5 Una vez

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        if (!AlarmHelper.hasExactAlarmPermission(this)) {
            Toast.makeText(this, "Activa el permiso de Alarmas y recordatorios para STEVE Daily.", Toast.LENGTH_LONG).show()
            AlarmHelper.requestExactAlarmPermission(this)
        }
        draw()
    }

    override fun onResume() {
        super.onResume()
        if (AlarmHelper.hasExactAlarmPermission(this) && !AlarmPause.isDisabled(this)) AlarmHelper.rescheduleAll(this)
        draw() // refresca el aviso de ajustes al volver de la configuración de Android
    }

    private fun draw() {
        tasks = TaskStore.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 20)
            setBackgroundColor(Color.WHITE)
        }

        val hour = LocalTime.now().hour
        val greeting = when {
            hour < 12 -> "Buenos días"
            hour < 18 -> "Buenas tardes"
            else -> "Buenas noches"
        }
        val dateText = LocalDate.now().format(
            DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", Locale("es", "CR"))
        ).replaceFirstChar { it.uppercase() }

        root.addView(TextView(this).apply {
            text = "S"
            textSize = 30f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(20, 82, 160))
        })
        root.addView(TextView(this).apply {
            text = "STEVE DAILY • v1.17.5 LAB"
            textSize = 22f
            gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })
        root.addView(TextView(this).apply {
            text = "$greeting${userGreeting()}  •  $dateText\nTu día, bajo control"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 2, 0, 9)
        })

        val next = nextTaskText()
        root.addView(TextView(this).apply {
            text = next
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(235, 243, 255))
            setPadding(14, 10, 14, 10)
        })
        root.addView(Space(this).apply { minimumHeight = 7 })

        if (!AlarmSetup.allOk(this)) root.addView(TextView(this).apply {
            text = "⚠ Faltan ajustes para que la alarma suene con la pantalla apagada • TOCA AQUÍ"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(150, 20, 20))
            setBackgroundColor(Color.rgb(255, 228, 224))
            setPadding(12, 10, 12, 10)
            setOnClickListener { showAlarmSetup() }
        })
        val paused = AlarmPause.isDisabled(this)
        if (paused) root.addView(TextView(this).apply {
            text = "🔴 ALARMAS DESHABILITADAS • toca MÁS para habilitar"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.rgb(150, 70, 0))
            setBackgroundColor(Color.rgb(255, 245, 224))
            setPadding(10, 8, 10, 8)
        })

        // Menú principal compacto: deja visibles las dos listas de uso frecuente
        // y mueve opciones menos frecuentes a una lista bajo MÁS.
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val compactButtonParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        quick.addView(Button(this).apply {
            text = "✓ TO DO"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showTodo() }
        }, compactButtonParams)
        quick.addView(Button(this).apply {
            text = "🛒 TO BUY"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showToBuy() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        quick.addView(Button(this).apply {
            text = "☰ MÁS"
            textSize = 14f
            minHeight = 48
            setTextColor(Color.BLACK)
            setOnClickListener { showMoreMenu() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(quick)

        root.addView(Button(this).apply {
            text = "+ NUEVA ACTIVIDAD"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 50
            setOnClickListener { showEditor(null) }
        })

        val onceOpen = tasks.count { it.repeat == "Nunca" && !TaskStore.isOnceDone(this, it.id) }
        // Pestañas desplazables: los botones conservan tamaño cómodo en Motorola.
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 10, 0, 6)
        }
        val tabWidth = (resources.displayMetrics.density * 108).toInt()
        listOf(0 to "HOY", 1 to "SEMANA", 2 to "MES", 3 to "AÑO",
            4 to "PRÓXIMAS", 5 to "UNA VEZ ($onceOpen)").forEach { (index, label) ->
            val selected = tab == index
            tabs.addView(Button(this).apply {
                text = label
                textSize = 13f
                minHeight = (resources.displayMetrics.density * 54).toInt()
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(if (selected) Color.WHITE else Color.BLACK)
                setBackgroundColor(if (selected) Color.rgb(20, 82, 160) else Color.rgb(225, 230, 238))
                setOnClickListener { if (this@MainActivity.tab != index) { this@MainActivity.tab = index; this@MainActivity.draw() } }
            }, LinearLayout.LayoutParams(tabWidth, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                setMargins(2, 0, 2, 0)
            })
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabs)
        })

        if (tab == 0) root.addView(todayStatusSummary())
        if (tab in 0..3) root.addView(statusLegend())
        if (tab == 5) root.addView(onceSummary())

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderList()
    }

    private fun nextTaskText(): String {
        val today = LocalDate.now()
        val now = LocalTime.now()
        val next = tasks
            .filter { taskOccursOn(it, today) }
            .filter { !isCompletedToday(it.id) && !isSkippedToday(it.id) }
            .mapNotNull { t -> runCatching { LocalTime.parse(t.time) }.getOrNull()?.let { tm -> t to tm } }
            .filter { (_, tm) -> tm.isAfter(now) }
            .minByOrNull { it.second }
        return if (next == null) "✓ No hay otra actividad pendiente hoy"
        else "PRÓXIMA  •  ${next.second}\n${next.first.title}"
    }

    private fun priorityColor(priority: String): Int = when (priority) {
        "Rojo" -> Color.rgb(255, 225, 225)
        "Amarillo" -> Color.rgb(255, 247, 204)
        else -> Color.rgb(224, 245, 228)
    }

    private fun priorityIcon(priority: String): String = when (priority) {
        "Rojo" -> "🔴"
        "Amarillo" -> "🟡"
        else -> "🟢"
    }

    private fun taskOccursOn(task: Task, date: LocalDate = LocalDate.now()): Boolean {
        val baseDate = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return false
        if (date.isBefore(baseDate)) return false
        return when (task.repeat) {
            "Nunca" -> date == baseDate
            "Diaria" -> true
            "Semanal" -> {
                val selected = task.repeatDays.split(',').mapNotNull {
                    runCatching { DayOfWeek.valueOf(it) }.getOrNull()
                }.toSet().ifEmpty { setOf(baseDate.dayOfWeek) }
                date.dayOfWeek in selected
            }
            "Anual" -> date.monthValue == baseDate.monthValue &&
                date.dayOfMonth == baseDate.dayOfMonth.coerceAtMost(YearMonth.from(date).lengthOfMonth())
            "Mensual" -> {
                val wanted = if (task.monthlyDay in 1..31) task.monthlyDay else baseDate.dayOfMonth
                date.dayOfMonth == wanted.coerceAtMost(YearMonth.from(date).lengthOfMonth())
            }
            else -> false
        }
    }

    private fun statusFor(task: Task): String {
        if (isSkippedToday(task.id)) return "OMITIDA"
        if (isCompletedToday(task.id)) return "REALIZADA"
        if (task.repeat == "Nunca") {
            // Una sola vez: si su fecha/hora ya pasó y no se marcó, queda ATRASADA hasta hacerla.
            val date = runCatching { LocalDate.parse(task.date) }.getOrNull() ?: return "PENDIENTE"
            val at = runCatching { LocalTime.parse(task.time) }.getOrNull() ?: return "PENDIENTE"
            return when {
                java.time.LocalDateTime.of(date, at).isBefore(java.time.LocalDateTime.now()) -> "ATRASADA"
                date == LocalDate.now() -> "PENDIENTE"
                else -> "PROGRAMADA"
            }
        }
        if (!taskOccursOn(task)) return "PROGRAMADA"
        val time = runCatching { LocalTime.parse(task.time) }.getOrNull() ?: return "PENDIENTE"
        return if (time.isBefore(LocalTime.now())) "ATRASADA" else "PENDIENTE"
    }

    private fun statusColor(status: String): Int = when (status) {
        "REALIZADA" -> Color.rgb(220, 246, 226)
        "ATRASADA" -> Color.rgb(255, 229, 224)
        "PENDIENTE" -> Color.rgb(226, 239, 255)
        "OMITIDA" -> Color.rgb(238, 238, 238)
        else -> Color.rgb(245, 245, 245)
    }

    private fun statusTextColor(status: String): Int = when (status) {
        "REALIZADA" -> Color.rgb(20, 105, 50)
        "ATRASADA" -> Color.rgb(165, 35, 25)
        "PENDIENTE" -> Color.rgb(20, 72, 140)
        "OMITIDA" -> Color.rgb(90, 90, 90)
        else -> Color.DKGRAY
    }

    private fun statusLabel(status: String): String = when (status) {
        "REALIZADA" -> "✓ REALIZADA"
        "ATRASADA" -> "⚠ ATRASADA"
        "PENDIENTE" -> "• PENDIENTE"
        "OMITIDA" -> "⏭ OMITIDA HOY"
        else -> "○ PROGRAMADA"
    }

    private fun todayStatusSummary(): TextView {
        val todays = tasks.filter { taskOccursOn(it) }
        val done = todays.count { isCompletedToday(it.id) && !isSkippedToday(it.id) }
        val skipped = todays.count { isSkippedToday(it.id) }
        val overdue = todays.count { !isCompletedToday(it.id) && !isSkippedToday(it.id) && statusFor(it) == "ATRASADA" }
        val pending = (todays.size - done - skipped - overdue).coerceAtLeast(0)
        return TextView(this).apply {
            text = if (todays.isEmpty()) {
                "HOY  •  Sin actividades programadas"
            } else {
                "HOY  •  $done realizadas  •  $pending pendientes  •  $overdue atrasadas" +
                        if (skipped > 0) "  •  $skipped omitidas" else ""
            }
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(238, 242, 247))
            setPadding(12, 9, 12, 9)
        }
    }

    private fun statusLegend(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, 6, 0, 12)
        val items = listOf(
            "✓ Hecho" to "REALIZADA",
            "• Falta" to "PENDIENTE",
            "⚠ Pasó" to "ATRASADA"
        )
        items.forEach { (label, status) ->
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(statusTextColor(status))
                setBackgroundColor(statusColor(status))
                setPadding(6, 8, 6, 8)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(2, 0, 2, 0)
            })
        }
    }

    private fun completionPrefs() = getSharedPreferences("daily_completion", MODE_PRIVATE)
    private fun skipPrefs() = getSharedPreferences("steve_skipped", MODE_PRIVATE)

    private fun completionKey(taskId: Long): String = "${LocalDate.now()}_$taskId"
    private fun skipKey(taskId: Long): String = "${LocalDate.now()}_$taskId"

    private fun isSkippedToday(taskId: Long): Boolean =
        skipPrefs().getBoolean(skipKey(taskId), false)

    private fun setSkippedToday(taskId: Long, skipped: Boolean) {
        skipPrefs().edit().putBoolean(skipKey(taskId), skipped).apply()
    }

    private fun isOnce(taskId: Long): Boolean = tasks.any { it.id == taskId && it.repeat == "Nunca" }

    // Una sola vez: el ✓ es permanente. Las repetitivas siguen con ✓ diario.
    private fun isCompletedToday(taskId: Long): Boolean =
        if (isOnce(taskId)) TaskStore.isOnceDone(this, taskId)
        else completionPrefs().getBoolean(completionKey(taskId), false)

    private fun setCompletedToday(taskId: Long, completed: Boolean) {
        if (isOnce(taskId)) TaskStore.setOnceDone(this, taskId, completed)
        else completionPrefs().edit().putBoolean(completionKey(taskId), completed).apply()
    }

    /** Marca/desmarca una actividad de una sola vez; si se hizo, cancela su alarma pendiente. */
    private fun toggleOnce(task: Task, done: Boolean) {
        TaskStore.setOnceDone(this, task.id, done)
        if (done) AlarmHelper.cancel(this, task.id) else AlarmHelper.schedule(this, task)
    }

    private fun renderList() {
        list.removeAllViews()
        if (tab == 4) {
            renderUpcomingList()
            return
        }
        if (tab == 5) {
            renderOnceList()
            return
        }
        val visibleTasks = when (tab) {
            0 -> tasks.filter { taskOccursOn(it, LocalDate.now()) }
            1 -> tasks.filter { it.repeat == "Semanal" }
            2 -> tasks.filter { it.repeat == "Mensual" }
            3 -> tasks.filter { it.repeat == "Anual" }
            else -> tasks
        }
        if (visibleTasks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (tasks.isEmpty())
                    "Todavía no hay actividades.\nPulsa NUEVA ACTIVIDAD para comenzar."
                else "No hay actividades en esta pestaña."
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
                setPadding(4, 34, 4, 0)
            })
            return
        }

        val grouped = visibleTasks
            .groupBy { it.groupId }
            .values
            .sortedWith(compareBy<List<Task>> { group -> group.minOf { it.date } }
                .thenBy { group -> group.minOf { it.time } })

        grouped.forEach { rawGroup ->
            val group = rawGroup.sortedBy { it.time }
            val first = group.first()
            val detail = when (first.repeat) {
                "Semanal" -> "Semanal: ${prettyDays(first.repeatDays, first.date)}"
                "Mensual" -> "Mensual: día ${if (first.monthlyDay > 0) first.monthlyDay else runCatching { LocalDate.parse(first.date).dayOfMonth }.getOrDefault(1)}"
                "Anual" -> "Anual: cumpleaños / aniversario"
                else -> first.repeat
            }
            val completedCount = group.count { isCompletedToday(it.id) && !isSkippedToday(it.id) }
            val skippedCount = group.count { isSkippedToday(it.id) }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(priorityColor(first.priority))
            }

            val header = TextView(this).apply {
                text = "${priorityIcon(first.priority)}  ${first.title}   •   $completedCount/${group.size} ✓" +
                        (if (skippedCount > 0) "   •   $skippedCount omitida(s)" else "") +
                        "\n${first.date}  •  $detail" +
                        (if (first.note.isNotBlank()) "\n${first.note}" else "")
                textSize = 19f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.BLACK)
                setPadding(8, 10, 8, 12)
                setOnClickListener { showEditor(first) }
            }
            card.addView(header)

            group.forEach { task ->
                val status = statusFor(task)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(4, 4, 4, 4)
                    setBackgroundColor(statusColor(status))
                }
                val done = CheckBox(this).apply {
                    isChecked = isCompletedToday(task.id)
                    isEnabled = !isSkippedToday(task.id)
                    text = if (isSkippedToday(task.id)) "–" else if (isChecked) "✓" else ""
                    textSize = 22f
                    setTextColor(if (isSkippedToday(task.id)) Color.GRAY else Color.rgb(0, 110, 55))
                    minWidth = 68
                    minHeight = 58
                    setPadding(6, 0, 8, 0)
                }
                val timeText = TextView(this).apply {
                    text = "${task.time}   ${statusLabel(status)}"
                    textSize = 19f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(statusTextColor(status))
                    setPadding(10, 12, 10, 12)
                    setOnClickListener { done.isChecked = !done.isChecked }
                }
                done.setOnCheckedChangeListener { _, checked ->
                    if (task.repeat == "Nunca") toggleOnce(task, checked) else setCompletedToday(task.id, checked)
                    draw()
                }
                row.addView(done, LinearLayout.LayoutParams(72, LinearLayout.LayoutParams.WRAP_CONTENT))
                row.addView(timeText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                card.addView(row)
                card.addView(Space(this).apply { minimumHeight = 5 })
            }

            list.addView(card)
            list.addView(Space(this).apply { minimumHeight = 14 })
        }
    }

    /** Próximas: incluye también los compromisos únicos atrasados y no realizados. */
    private fun renderUpcomingList() {
        val now = java.time.LocalDateTime.now()
        data class Entry(val task: Task, val time: java.time.LocalDateTime, val overdue: Boolean)
        val entries = tasks.filter { it.repeat != "Nunca" || !TaskStore.isOnceDone(this, it.id) }
            .mapNotNull { task ->
                if (task.repeat == "Nunca") {
                    val date = runCatching { LocalDate.parse(task.date) }.getOrNull()
                    val time = runCatching { LocalTime.parse(task.time) }.getOrNull()
                    if (date == null || time == null) null
                    else java.time.LocalDateTime.of(date, time).let { Entry(task, it, it.isBefore(now)) }
                } else {
                    val after = if (isCompletedToday(task.id) || isSkippedToday(task.id))
                        now.toLocalDate().atTime(23, 59, 59) else now
                    AlarmHelper.upcoming(task, after)?.let { Entry(task, it, false) }
                }
            }.sortedWith(compareBy<Entry> { !it.overdue }.thenBy { it.time }.thenBy { it.task.id })
        val overdue = entries.count { it.overdue }
        list.addView(TextView(this).apply {
            text = "PRÓXIMAS • ${entries.size} actividades" +
                (if (overdue > 0) " • $overdue atrasadas" else "") +
                "\nFechas visibles y horarios ordenados; toca una actividad para editarla."
            textSize = 17f
            setTextColor(Color.BLACK)
            setPadding(12, 12, 12, 12)
        })
        if (entries.isEmpty()) list.addView(TextView(this).apply {
            text = "No hay actividades futuras ni pendientes atrasadas."
            textSize = 18f
            setTextColor(Color.DKGRAY)
        })
        val format = DateTimeFormatter.ofPattern("EEE d MMM yyyy • HH:mm", Locale("es", "CR"))
        entries.forEach { entry ->
            list.addView(TextView(this).apply {
                text = (if (entry.overdue) "⚠ ATRASADA  •  " else "") + entry.task.title +
                    "\n${entry.time.format(format)}\n${entry.task.repeat}" +
                    (if (entry.task.note.isBlank()) "" else "\n${entry.task.note}")
                textSize = 19f
                setTextColor(Color.BLACK)
                setBackgroundColor(if (entry.overdue) Color.rgb(255, 225, 225) else priorityColor(entry.task.priority))
                setPadding(16, 18, 16, 18)
                setOnClickListener { showEditor(entry.task) }
            })
            list.addView(Space(this).apply { minimumHeight = 10 })
        }
    }

    private fun onceSummary(): TextView {
        val once = tasks.filter { it.repeat == "Nunca" }
        val done = once.count { TaskStore.isOnceDone(this, it.id) }
        val overdue = once.count { statusFor(it) == "ATRASADA" }
        val pending = (once.size - done - overdue).coerceAtLeast(0)
        return TextView(this).apply {
            text = if (once.isEmpty()) "UNA VEZ  •  Sin actividades de una sola vez"
            else "UNA VEZ  •  $pending por hacer  •  $overdue atrasadas  •  $done hechas"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.rgb(238, 242, 247))
            setPadding(12, 9, 12, 9)
        }
    }

    /** Pestaña UNA VEZ: lista de cosas por hacer que no se repiten (repetición "Nunca"). */
    private fun renderOnceList() {
        val once = tasks.filter { it.repeat == "Nunca" }
        if (once.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No hay actividades de una sola vez.\nPulse NUEVA ACTIVIDAD y deje la repetición en «Nunca»."
                textSize = 18f
                gravity = Gravity.CENTER
                setTextColor(Color.DKGRAY)
                setPadding(4, 34, 4, 0)
            })
            return
        }
        val sorted = once.sortedWith(compareBy<Task>({ it.date }, { it.time }))
        val overdue = sorted.filter { statusFor(it) == "ATRASADA" }
        val doneList = sorted.filter { TaskStore.isOnceDone(this, it.id) }.reversed()
        val upcoming = sorted.filter { statusFor(it) != "ATRASADA" && !TaskStore.isOnceDone(this, it.id) }

        fun section(title: String, items: List<Task>) {
            if (items.isEmpty()) return
            list.addView(TextView(this).apply {
                text = title
                textSize = 17f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(Color.BLACK)
                setPadding(4, 14, 0, 6)
            })
            items.forEach { task ->
                list.addView(onceRow(task))
                list.addView(Space(this).apply { minimumHeight = 8 })
            }
        }
        section("⚠ ATRASADAS", overdue)
        section("• POR HACER", upcoming)
        section("✓ HECHAS", doneList)

        if (doneList.isNotEmpty()) {
            list.addView(Button(this).apply {
                text = "🧹 LIMPIAR HECHAS (${doneList.size})"
                textSize = 16f
                minHeight = 56
                setTextColor(Color.BLACK)
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle("Limpiar hechas")
                        .setMessage("¿Quitar de la lista las ${doneList.size} actividades ya hechas?")
                        .setPositiveButton("QUITAR") { _, _ ->
                            val ids = doneList.map { it.id }.toSet()
                            doneList.forEach {
                                AlarmHelper.cancel(this@MainActivity, it.id)
                                TaskStore.setOnceDone(this@MainActivity, it.id, false)
                            }
                            tasks.removeAll { it.id in ids }
                            TaskStore.save(this@MainActivity, tasks)
                            this@MainActivity.draw()
                        }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                }
            })
            list.addView(Space(this).apply { minimumHeight = 20 })
        }
    }

    private fun onceRow(task: Task): View {
        val done = TaskStore.isOnceDone(this, task.id)
        val status = statusFor(task)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(statusColor(status))
        }
        val check = CheckBox(this).apply {
            isChecked = done
            minWidth = 68
            minHeight = 64
            setPadding(6, 0, 8, 0)
        }
        check.setOnCheckedChangeListener { _, checked ->
            toggleOnce(task, checked)
            draw()
        }
        val today = LocalDate.now()
        val date = runCatching { LocalDate.parse(task.date) }.getOrNull()
        val dayText = if (date == null) task.date else when (date) {
            today -> "HOY"
            today.plusDays(1) -> "MAÑANA"
            else -> date.format(DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale("es", "CR")))
        }
        val info = TextView(this).apply {
            text = "${priorityIcon(task.priority)} ${task.title}\n📅 $dayText  •  ⏰ ${task.time}  •  ${statusLabel(status)}" +
                    (if (task.note.isNotBlank()) "\n${task.note}" else "")
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(statusTextColor(status))
            setPadding(10, 10, 10, 10)
            if (done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            setOnClickListener { showEditor(task) }
        }
        row.addView(check, LinearLayout.LayoutParams(72, LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(info, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    /** Revisa los ajustes de Android necesarios para que la alarma suene con pantalla apagada. */
    private fun showAlarmSetup() {
        val exact = AlarmHelper.hasExactAlarmPermission(this)
        val notif = AlarmSetup.notificationsOk(this)
        val full = AlarmSetup.fullScreenOk(this)
        val battery = AlarmSetup.batteryOk(this)
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        val options = arrayOf(
            "${mark(exact)} Alarmas y recordatorios exactos",
            "${mark(notif)} Notificaciones",
            "${mark(full)} Mostrar alarma a pantalla completa",
            "${mark(battery)} Batería sin restricción",
            "🧪 Probar alarma en 1 minuto"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("🔧 Toca cada ❌ para activarlo")
            .setItems(options) { _, which ->
                fun already() = Toast.makeText(this, "Ya está activo ✅", Toast.LENGTH_SHORT).show()
                when (which) {
                    0 -> if (exact) already() else AlarmHelper.requestExactAlarmPermission(this)
                    1 -> if (notif) already() else AlarmSetup.openNotifications(this)
                    2 -> if (full) already() else AlarmSetup.openFullScreen(this)
                    3 -> if (battery) already() else AlarmSetup.openBattery(this)
                    4 -> {
                        if (AlarmHelper.scheduleTest(this, 1)) {
                            Toast.makeText(this,
                                "Prueba lista. Apaga la pantalla y espera 1 minuto: debe sonar.",
                                Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "No se pudo programar la prueba. Revisa el primer ajuste.",
                                Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNegativeButton("CERRAR", null)
            .show()
    }

    private fun prettyDays(raw: String, date: String): String {
        val map = linkedMapOf(
            DayOfWeek.MONDAY to "Lun", DayOfWeek.TUESDAY to "Mar", DayOfWeek.WEDNESDAY to "Mié",
            DayOfWeek.THURSDAY to "Jue", DayOfWeek.FRIDAY to "Vie", DayOfWeek.SATURDAY to "Sáb",
            DayOfWeek.SUNDAY to "Dom"
        )
        val selected = raw.split(',').mapNotNull { runCatching { DayOfWeek.valueOf(it) }.getOrNull() }.toSet()
        val actual = if (selected.isEmpty()) setOf(runCatching { LocalDate.parse(date).dayOfWeek }.getOrDefault(DayOfWeek.MONDAY)) else selected
        return map.filterKeys { it in actual }.values.joinToString(", ")
    }

    private fun editText(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.BLACK)
        setHintTextColor(Color.DKGRAY)
        setBackgroundColor(Color.WHITE)
        textSize = 19f
        setPadding(12, 18, 12, 18)
    }

    private fun showMoreMenu() {
        val disabled = AlarmPause.isDisabled(this)
        val options = arrayOf(
            if (disabled) "▶ Habilitar alarmas" else "⏸ Deshabilitar alarmas",
            "💰 Finanzas",
            "👤 Mi nombre / alias",
            "🔧 Ajustes de la alarma / probar",
            "💾 Exportar respaldo",
            "📂 Importar respaldo"
        )
        android.app.AlertDialog.Builder(this)
            .setTitle("☰ Más opciones")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        if (disabled) {
                            AlarmPause.setDisabled(this, false)
                            AlarmHelper.rescheduleAll(this)
                            AlarmHelper.restoreSnoozes(this)
                            Toast.makeText(
                                this,
                                "Alarmas habilitadas. Se programaron solo los próximos avisos.",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            AlarmPause.setDisabled(this, true)
                            TaskStore.load(this).forEach { AlarmHelper.cancel(this, it.id) }
                            Toast.makeText(
                                this,
                                "Alarmas deshabilitadas hasta que vuelvas a pulsar HABILITAR.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        draw()
                    }
                    1 -> showFinances()
                    2 -> showProfile()
                    3 -> showAlarmSetup()
                    4 -> exportBackup()
                    5 -> importBackup()
                }
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private val REQUEST_EXPORT_BACKUP = 8011
    private val REQUEST_IMPORT_BACKUP = 8012

    private fun exportBackup() {
        val intent = android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(android.content.Intent.EXTRA_TITLE,
                "STEVE_Daily_Respaldo_${LocalDate.now()}.json")
        }
        startActivityForResult(intent, REQUEST_EXPORT_BACKUP)
    }

    private fun importBackup() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Restaurar datos")
            .setMessage("La importación sustituye los datos de ESTA aplicación LAB. " +
                "Antes conviene exportar un respaldo. No modifica la otra app STEVE Daily instalada.")
            .setPositiveButton("ELEGIR RESPALDO") { _, _ ->
                val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(android.content.Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, REQUEST_IMPORT_BACKUP)
            }
            .setNegativeButton("CANCELAR", null).show()
    }

    @Deprecated("Android Activity result API; no AndroidX dependency in this project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data ?: return
        if (requestCode == REQUEST_EXPORT_BACKUP) {
            val ok = runCatching {
                contentResolver.openOutputStream(uri, "w")!!.use {
                    it.write(BackupManager.export(this).toByteArray(Charsets.UTF_8))
                }
            }.isSuccess
            Toast.makeText(this, if (ok) "Respaldo guardado." else "No se pudo guardar el respaldo.",
                Toast.LENGTH_LONG).show()
        } else if (requestCode == REQUEST_IMPORT_BACKUP) {
            val ok = runCatching {
                val contents = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                BackupManager.import(this, contents)
            }.getOrDefault(false)
            if (ok) {
                AlarmHelper.rescheduleAll(this)
                AlarmHelper.restoreSnoozes(this)
                draw()
            }
            Toast.makeText(this, if (ok) "Respaldo restaurado." else "Respaldo inválido o no compatible.",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun listPrefs() = getSharedPreferences("steve_lists", MODE_PRIVATE)
    private fun loadArray(key: String): JSONArray = runCatching { JSONArray(listPrefs().getString(key, "[]")) }.getOrDefault(JSONArray())
    private fun saveArray(key: String, arr: JSONArray) = listPrefs().edit().putString(key, arr.toString()).apply()


    private fun profilePrefs() = getSharedPreferences("steve_profile", MODE_PRIVATE)

    private fun userName(): String = profilePrefs().getString("user_name", "")?.trim().orEmpty()

    private fun userGreeting(): String {
        val name = userName()
        return if (name.isBlank()) "" else ", $name"
    }

    private fun showProfile() {
        val input = editText("Tu nombre o alias", userName())
        android.app.AlertDialog.Builder(this)
            .setTitle("👤 Personalizar STEVE Daily")
            .setMessage("Este nombre se mostrará únicamente en tu dispositivo.")
            .setView(input)
            .setPositiveButton("GUARDAR") { _, _ ->
                profilePrefs().edit().putString("user_name", input.text.toString().trim()).apply()
                draw()
            }
            .setNeutralButton("BORRAR") { _, _ ->
                profilePrefs().edit().remove("user_name").apply()
                draw()
            }
            .setNegativeButton("CANCELAR", null)
            .show()
    }

    private fun financePrefs() = getSharedPreferences("steve_finances", MODE_PRIVATE)
    private fun loadFinanceArray(): JSONArray = runCatching {
        JSONArray(financePrefs().getString("movements", "[]"))
    }.getOrDefault(JSONArray())
    private fun saveFinanceArray(arr: JSONArray) = financePrefs().edit().putString("movements", arr.toString()).apply()

    private fun showFinances() {
        val arr = loadFinanceArray()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,12,20,12) }
        val concept = editText("Concepto", "")
        val amount = editText("Monto", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Entrada", "Salida"))
        }
        val note = editText("Nota opcional", "")
        box.addView(concept); box.addView(amount); box.addView(type); box.addView(note)
        val add = Button(this).apply { text = "＋ REGISTRAR MOVIMIENTO" }
        box.addView(add)
        val totals = TextView(this).apply { textSize = 18f; setTextColor(Color.BLACK); setPadding(4,14,4,12); setTypeface(typeface, Typeface.BOLD) }
        box.addView(totals)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)

        fun render() {
            items.removeAllViews()
            var income = 0.0
            var expense = 0.0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val value = o.optDouble("amount", 0.0)
                val movementType = o.optString("type", "Entrada")
                if (movementType == "Salida") expense += value else income += value
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8,8,8,8) }
                val info = TextView(this).apply {
                    val sign = if (movementType == "Salida") "−" else "+"
                    val extra = o.optString("note", "").takeIf { it.isNotBlank() }?.let { "\n$it" } ?: ""
                    text = "${o.optString("date")}  •  $movementType\n${o.optString("concept")}   $sign ₡${"%.0f".format(value)}$extra"
                    textSize = 17f
                    setTextColor(Color.BLACK)
                }
                val del = Button(this).apply {
                    text = "ELIMINAR"
                    setOnClickListener { arr.remove(i); saveFinanceArray(arr); render() }
                }
                row.addView(info); row.addView(del); items.addView(row)
            }
            totals.text = "Entradas: ₡${"%.0f".format(income)}   •   Salidas: ₡${"%.0f".format(expense)}\nSaldo: ₡${"%.0f".format(income - expense)}"
        }

        add.setOnClickListener {
            val c = concept.text.toString().trim()
            val a = amount.text.toString().toDoubleOrNull()
            if (c.isBlank() || a == null || a <= 0.0) {
                Toast.makeText(this, "Escribe un concepto y un monto válido.", Toast.LENGTH_LONG).show()
            } else {
                arr.put(JSONObject()
                    .put("date", LocalDate.now().toString())
                    .put("type", type.selectedItem.toString())
                    .put("concept", c)
                    .put("amount", a)
                    .put("note", note.text.toString().trim()))
                saveFinanceArray(arr)
                concept.setText(""); amount.setText(""); note.setText("")
                render()
            }
        }
        render()
        android.app.AlertDialog.Builder(this)
            .setTitle("💰 Finanzas")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("CERRAR", null)
            .show()
    }

    private fun showTodo() {
        val arr = loadArray("todo")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,12,20,12) }
        val input = editText("Nueva tarea", "")
        box.addView(input)
        val add = Button(this).apply { text = "＋ AGREGAR" }
        box.addView(add)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)
        fun render() {
            items.removeAllViews()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val cb = CheckBox(this).apply { text = o.optString("text"); textSize = 18f; isChecked = o.optBoolean("done") }
                cb.setOnCheckedChangeListener { _, v -> o.put("done",v); saveArray("todo",arr) }
                val del = Button(this).apply { text = "✕"; setOnClickListener { arr.remove(i); saveArray("todo",arr); render() } }
                row.addView(cb, LinearLayout.LayoutParams(0,-2,1f)); row.addView(del)
                items.addView(row)
            }
        }
        add.setOnClickListener { val t=input.text.toString().trim(); if(t.isNotEmpty()){ arr.put(JSONObject().put("text",t).put("done",false)); saveArray("todo",arr); input.setText(""); render() } }
        render()
        android.app.AlertDialog.Builder(this).setTitle("✓ TO DO").setView(ScrollView(this).apply{addView(box)}).setPositiveButton("CERRAR",null).show()
    }

    /**
     * To Buy LAB 1.17.5
     * Preserva los datos anteriores en steve_lists/tobuy. Cada compra terminada tiene
     * su propia entrada en tobuy_history para que repetir un producto no borre el historial.
     */
    private fun showToBuy() {
        val arr = loadArray("tobuy")
        val history = loadArray("tobuy_history")
        var selectedMonth = YearMonth.now()
        var selectedView = 0  // 0 Pendientes, 1 Comprados, 2 Historial
        var allHistory = false

        fun money(v: Double): String = "₡${"%.0f".format(Locale("es", "CR"), v)}"
        fun numberText(v: Double): String = BigDecimal.valueOf(v).stripTrailingZeros().toPlainString()
        fun placeOf(o: JSONObject): String = o.optString("place", "").trim().ifBlank { "Sin lugar definido" }
        fun normalized(text: String) = text.trim().lowercase(Locale.ROOT)
        fun safeMonth(date: String): String = ToBuyCalculations.monthOf(date)
        fun monthOf(o: JSONObject): String = safeMonth(o.optString("boughtAt", ""))
        fun newId(): Long = System.currentTimeMillis() * 1000L + arr.length().toLong() + history.length().toLong()
        fun save() {
            // Ambas listas en una sola transacción, para no guardar una compra sin historial.
            val ok = listPrefs().edit().putString("tobuy", arr.toString())
                .putString("tobuy_history", history.toString()).commit()
            if (!ok) Toast.makeText(this, "No se pudieron guardar las compras.", Toast.LENGTH_LONG).show()
        }
        fun findHistoryIndex(purchaseId: Long): Int {
            for (i in 0 until history.length()) if (history.getJSONObject(i).optLong("id") == purchaseId) return i
            return -1
        }
        fun updateHistory(o: JSONObject) {
            val pid = o.optLong("purchaseId", 0L)
            if (pid == 0L) return
            val entry = if (findHistoryIndex(pid) >= 0) history.getJSONObject(findHistoryIndex(pid))
                else JSONObject().also { history.put(it) }
            entry.put("id", pid).put("sourceId", o.optLong("id"))
                .put("name", o.optString("name")).put("qty", o.optDouble("qty", 1.0))
                .put("ref", o.optDouble("ref", 0.0)).put("real", o.optDouble("real", 0.0))
                .put("place", o.optString("place", "")).put("boughtAt", o.optString("boughtAt", ""))
        }
        fun latestPaid(name: String, place: String = ""): Double? {
            val purchases = (0 until history.length()).map { history.getJSONObject(it) }.map {
                ToBuyCalculations.PaidPrice(it.optString("name"), it.optString("place", ""),
                    it.optDouble("real", 0.0), it.optString("boughtAt", ""), it.optLong("id"))
            }
            return ToBuyCalculations.lastPaidPrice(purchases, name, place)
        }

        // Migración aditiva: no borra ni reemplaza entradas anteriores.
        var migrated = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (!o.has("id")) { o.put("id", System.currentTimeMillis() + i); migrated = true }
            if (!o.has("place")) { o.put("place", ""); migrated = true }
            if (!o.has("qty")) { o.put("qty", 1.0); migrated = true }
            if (!o.has("plannedMonth")) {
                // Las compras antiguas sin mes de planificación quedan visibles en el mes actual.
                o.put("plannedMonth", YearMonth.now().toString()); migrated = true
            }
            if (o.optBoolean("bought")) {
                var pid = o.optLong("purchaseId", 0L)
                if (pid == 0L) {
                    pid = o.optLong("id")
                    if ((0 until history.length()).any { history.getJSONObject(it).optLong("id") == pid }) {
                        pid = System.currentTimeMillis() * 1000L + i
                    }
                    o.put("purchaseId", pid); migrated = true
                }
                if (findHistoryIndex(pid) < 0) { updateHistory(o); migrated = true }
            }
        }
        if (migrated) save()

        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 10, 18, 14) }
        val rowTabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnPending = Button(this).apply { text = "PENDIENTES"; textSize = 12f }
        val btnBought = Button(this).apply { text = "COMPRADOS"; textSize = 12f }
        val btnHistory = Button(this).apply { text = "HISTORIAL"; textSize = 12f }
        for (b in listOf(btnPending, btnBought, btnHistory)) rowTabs.addView(b,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        box.addView(rowTabs)

        val monthRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val previousMonth = Button(this).apply { text = "◀"; contentDescription = "Mes anterior" }
        val monthLabel = TextView(this).apply {
            textSize = 17f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD)
        }
        val nextMonth = Button(this).apply { text = "▶"; contentDescription = "Mes siguiente" }
        monthRow.addView(previousMonth, LinearLayout.LayoutParams(58, -2))
        monthRow.addView(monthLabel, LinearLayout.LayoutParams(0, -2, 1f))
        monthRow.addView(nextMonth, LinearLayout.LayoutParams(58, -2))
        box.addView(monthRow)
        val allHistoryButton = Button(this).apply { text = "VER TODO EL HISTORIAL" }
        box.addView(allHistoryButton)

        val inputArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val name = editText("Producto", "")
        val qty = editText("Cantidad", "1").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val ref = editText("Precio referencia por unidad", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val real = editText("Precio real por unidad (opcional)", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL }
        val place = editText("Dónde comprar / establecimiento", "")
        for (v in listOf(name, qty, ref, real, place)) inputArea.addView(v)
        val priceHint = TextView(this).apply { textSize = 13f; setTextColor(Color.GRAY); setPadding(6, 2, 6, 8) }
        inputArea.addView(priceHint)
        val add = Button(this).apply { text = "＋ AGREGAR AL MES" }
        inputArea.addView(add)
        box.addView(inputArea)
        val summary = TextView(this).apply {
            textSize = 17f; setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD); setPadding(8, 12, 8, 12)
        }
        box.addView(summary)
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(items)
        lateinit var render: () -> Unit

        fun indexFor(id: Long): Int {
            for (i in 0 until arr.length()) if (arr.getJSONObject(i).optLong("id") == id) return i
            return -1
        }
        fun removeProduct(o: JSONObject) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar producto")
                .setMessage("¿Eliminar ${o.optString("name")}? El historial de compras ya realizadas se conservará.")
                .setPositiveButton("ELIMINAR") { _, _ ->
                    val index = indexFor(o.optLong("id"))
                    if (index >= 0) arr.remove(index)
                    save(); render.invoke()
                }
                .setNegativeButton("CANCELAR", null).show()
        }
        fun buyAgain(o: JSONObject) {
            val lastPaid = latestPaid(o.optString("name"), o.optString("place"))
                ?: o.optDouble("real", 0.0).takeIf { it > 0.0 }
                ?: o.optDouble("ref", 0.0)
            arr.put(JSONObject().put("id", newId()).put("name", o.optString("name"))
                .put("qty", o.optDouble("qty", 1.0)).put("ref", lastPaid).put("real", 0.0)
                .put("place", o.optString("place", "")).put("plannedMonth", selectedMonth.toString())
                .put("bought", false))
            save(); selectedView = 0; render.invoke()
            Toast.makeText(this, "Producto añadido a Pendientes; la compra anterior queda guardada.", Toast.LENGTH_LONG).show()
        }
        fun editPurchase(o: JSONObject) {
            val wasBought = o.optBoolean("bought")
            val oldBoughtAt = o.optString("boughtAt", "")
            val editBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 10, 20, 8) }
            val eName = editText("Producto", o.optString("name"))
            val eQty = editText("Cantidad", numberText(o.optDouble("qty", 1.0))).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val eRef = editText("Precio referencia por unidad", o.optDouble("ref", 0.0)
                .takeIf { it > 0.0 }?.let { numberText(it) } ?: "").apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val eReal = editText("Precio real por unidad", o.optDouble("real", 0.0)
                .takeIf { it > 0.0 }?.let { numberText(it) } ?: "").apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            }
            val ePlace = editText("Establecimiento", o.optString("place", ""))
            val eMonth = editText("Mes planificado (AAAA-MM)",
                o.optString("plannedMonth", selectedMonth.toString()))
            for (v in listOf(eName, eQty, eRef, eReal, ePlace)) editBox.addView(v)
            if (!wasBought) editBox.addView(eMonth)
            android.app.AlertDialog.Builder(this)
                .setTitle(if (wasBought) "Editar compra realizada" else "Editar compra pendiente")
                .setView(ScrollView(this).apply { addView(editBox) })
                .setPositiveButton("GUARDAR") { _, _ ->
                    val n = eName.text.toString().trim()
                    val q = eQty.text.toString().toDoubleOrNull()
                    val r = eRef.text.toString().toDoubleOrNull() ?: 0.0
                    val paid = eReal.text.toString().toDoubleOrNull() ?: 0.0
                    val validMonth = wasBought || runCatching { YearMonth.parse(eMonth.text.toString().trim()) }.isSuccess
                    if (n.isBlank() || q == null || q <= 0.0 || r < 0.0 || paid < 0.0 || !validMonth) {
                        Toast.makeText(this, "Revisa nombre, cantidad y precios.", Toast.LENGTH_LONG).show()
                    } else {
                        o.put("name", n).put("qty", q).put("ref", r).put("real", paid)
                            .put("place", ePlace.text.toString().trim()).put("bought", wasBought)
                        if (wasBought) {
                            o.put("boughtAt", oldBoughtAt)
                            updateHistory(o) // Corregir el importe no crea otra compra.
                        } else {
                            o.put("plannedMonth", eMonth.text.toString().trim())
                        }
                        save(); render.invoke()
                    }
                }.setNegativeButton("CANCELAR", null).show()
        }
        fun markBought(o: JSONObject, checked: Boolean) {
            val old = o.optBoolean("bought")
            if (checked == old) return
            if (checked) {
                o.put("bought", true).put("boughtAt", LocalDate.now().toString())
                    .put("purchaseId", newId())
                updateHistory(o); save(); render.invoke()
            } else {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Corregir una compra")
                    .setMessage("¿Devolverla a Pendientes? Se quitará únicamente ESTA compra del historial para corregir el marcado.")
                    .setPositiveButton("SÍ, CORREGIR") { _, _ ->
                        val index = findHistoryIndex(o.optLong("purchaseId"))
                        if (index >= 0) history.remove(index)
                        o.put("bought", false).remove("boughtAt").remove("purchaseId")
                        save(); render.invoke()
                    }.setNegativeButton("CANCELAR") { _, _ -> render.invoke() }.show()
            }
        }
        fun addProductRow(o: JSONObject, historic: Boolean = false) {
            val q = o.optDouble("qty", 1.0)
            val r = o.optDouble("ref", 0.0)
            val paid = o.optDouble("real", 0.0)
            val bought = historic || o.optBoolean("bought")
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(9, 9, 9, 9)
                setBackgroundColor(if (bought) Color.rgb(231, 246, 231) else Color.rgb(239, 245, 255)) }
            val text = "${o.optString("name")} × ${numberText(q)}\n" +
                "Referencia: ${money(r)}   •   Pagado: ${money(paid)}\n" +
                "Total ${if (bought) "real" else "estimado"}: ${money(q * (if (bought) paid else r))}" +
                if (bought) "\nFecha: ${o.optString("boughtAt", "").ifBlank { "sin registrar" }}" else ""
            if (historic) {
                row.addView(TextView(this).apply { this.text = text; textSize = 17f; setTextColor(Color.BLACK) })
                row.addView(Button(this).apply { this.text = "COMPRAR NUEVAMENTE"; setOnClickListener { buyAgain(o) } })
            } else {
                row.addView(CheckBox(this).apply {
                    isChecked = bought; this.text = text; textSize = 16f; setTextColor(Color.BLACK)
                    setOnCheckedChangeListener { _, checked -> markBought(o, checked) }
                })
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(Button(this).apply { this.text = "EDITAR"; setOnClickListener { editPurchase(o) } },
                    LinearLayout.LayoutParams(0, -2, 1f))
                actions.addView(Button(this).apply {
                    this.text = if (bought) "OTRA VEZ" else "ELIMINAR"
                    setOnClickListener { if (bought) buyAgain(o) else removeProduct(o) }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                if (bought) actions.addView(Button(this).apply {
                    this.text = "ELIMINAR"
                    setOnClickListener { removeProduct(o) }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(actions)
            }
            items.addView(row)
            items.addView(Space(this).apply { minimumHeight = 6 })
        }
        fun groupedSection(title: String, records: List<JSONObject>, paid: Boolean, historic: Boolean = false) {
            items.addView(TextView(this).apply { text = "$title (${records.size})"; textSize = 19f
                setTypeface(typeface, Typeface.BOLD); setTextColor(Color.rgb(20, 65, 130)); setPadding(5, 16, 5, 7) })
            if (records.isEmpty()) {
                items.addView(TextView(this).apply { text = "No hay productos para este mes."; textSize = 16f; setTextColor(Color.DKGRAY) })
                return
            }
            records.groupBy { placeOf(it) }.toSortedMap(String.CASE_INSENSITIVE_ORDER).forEach { (store, purchases) ->
                val amount = purchases.sumOf { ToBuyCalculations.lineTotal(it.optDouble("qty", 1.0), it.optDouble(if (paid) "real" else "ref", 0.0)) }
                items.addView(TextView(this).apply {
                    text = "📍 $store  •  ${money(amount)}"; textSize = 17f
                    setTypeface(typeface, Typeface.BOLD); setTextColor(Color.BLACK); setPadding(6, 10, 6, 4)
                })
                purchases.sortedBy { normalized(it.optString("name")) }.forEach { addProductRow(it, historic) }
            }
        }
        render = {
            items.removeAllViews()
            val month = selectedMonth.toString()
            monthLabel.text = selectedMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("es", "CR")))
                .replaceFirstChar { it.uppercase() }
            inputArea.visibility = if (selectedView == 0) View.VISIBLE else View.GONE
            allHistoryButton.visibility = if (selectedView == 2) View.VISIBLE else View.GONE
            allHistoryButton.text = if (allHistory) "VER SOLO $month" else "VER TODO EL HISTORIAL"
            for ((index, b) in listOf(btnPending, btnBought, btnHistory).withIndex()) {
                b.setTextColor(if (selectedView == index) Color.WHITE else Color.BLACK)
                b.setBackgroundColor(if (selectedView == index) Color.rgb(20, 82, 160) else Color.rgb(223, 230, 240))
            }
            val all = (0 until arr.length()).map { arr.getJSONObject(it) }
            val hist = (0 until history.length()).map { history.getJSONObject(it) }
            val pending = all.filter { !it.optBoolean("bought") && it.optString("plannedMonth") == month }
            val bought = all.filter { it.optBoolean("bought") && monthOf(it) == month }
            val monthHistory = hist.filter { monthOf(it) == month }
            val pendingSum = pending.sumOf { ToBuyCalculations.lineTotal(it.optDouble("qty", 1.0), it.optDouble("ref", 0.0)) }
            val boughtSum = monthHistory.sumOf { ToBuyCalculations.lineTotal(it.optDouble("qty", 1.0), it.optDouble("real", 0.0)) }
            summary.text = "Pendiente estimado: ${money(pendingSum)}\nGastado en $month: ${money(boughtSum)}"
            when (selectedView) {
                0 -> groupedSection("PENDIENTES DEL MES", pending, false)
                1 -> {
                    groupedSection("COMPRADOS DEL MES", bought, true)
                    val undated = all.filter { it.optBoolean("bought") && monthOf(it).isBlank() }
                    if (undated.isNotEmpty()) groupedSection("COMPRAS ANTIGUAS SIN FECHA", undated, true)
                }
                else -> {
                    if (allHistory) {
                        val byMonth = hist.groupBy { monthOf(it).ifBlank { "Sin fecha" } }
                        byMonth.keys.sortedDescending().forEach { ym ->
                            val entries = byMonth.getValue(ym)
                            groupedSection("HISTORIAL • $ym", entries, true, true)
                        }
                        if (hist.isEmpty()) groupedSection("HISTORIAL", emptyList(), true, true)
                    } else groupedSection("HISTORIAL • $month", monthHistory, true, true)
                }
            }
        }
        fun refreshHint() {
            val last = latestPaid(name.text.toString(), place.text.toString())
            priceHint.text = if (last != null) "Último precio pagado: ${money(last)} por unidad (referencia sugerida)"
                else "El último precio pagado aparecerá como referencia tenue."
            ref.hint = if (last != null) "Referencia ${money(last)}" else "Precio referencia por unidad"
        }
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = refreshHint()
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        name.addTextChangedListener(watcher)
        place.addTextChangedListener(watcher)
        ref.setHintTextColor(Color.LTGRAY)
        refreshHint()
        btnPending.setOnClickListener { selectedView = 0; render.invoke() }
        btnBought.setOnClickListener { selectedView = 1; render.invoke() }
        btnHistory.setOnClickListener { selectedView = 2; render.invoke() }
        previousMonth.setOnClickListener { selectedMonth = selectedMonth.minusMonths(1); render.invoke() }
        nextMonth.setOnClickListener { selectedMonth = selectedMonth.plusMonths(1); render.invoke() }
        allHistoryButton.setOnClickListener { allHistory = !allHistory; render.invoke() }
        add.setOnClickListener {
            val n = name.text.toString().trim()
            val q = qty.text.toString().toDoubleOrNull()
            val inputRef = ref.text.toString().toDoubleOrNull()
            val paid = real.text.toString().toDoubleOrNull() ?: 0.0
            if (n.isBlank() || q == null || q <= 0.0 || (inputRef != null && inputRef < 0.0) || paid < 0.0) {
                Toast.makeText(this, "Escribe un producto y cantidades/precios válidos.", Toast.LENGTH_LONG).show()
            } else {
                val reference = inputRef ?: latestPaid(n, place.text.toString()) ?: 0.0
                arr.put(JSONObject().put("id", newId()).put("name", n).put("qty", q)
                    .put("ref", reference).put("real", paid).put("place", place.text.toString().trim())
                    .put("plannedMonth", selectedMonth.toString()).put("bought", false))
                save()
                name.setText(""); qty.setText("1"); ref.setText(""); real.setText(""); place.setText("")
                render.invoke()
            }
        }
        render.invoke()
        android.app.AlertDialog.Builder(this)
            .setTitle("🛒 TO BUY • v1.17.5")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("CERRAR", null)
            .show()
    }

    private fun showEditor(existing: Task?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 10)
            setBackgroundColor(Color.WHITE)
        }
        val title = editText("¿Qué debo recordar?", existing?.title ?: "")
        var selectedDate = if (existing == null) LocalDate.now() else
            runCatching { LocalDate.parse(existing.date) }.getOrDefault(LocalDate.now())
        val dateButton = Button(this).apply {
            text = "📅 Fecha: $selectedDate"
            textSize = 18f
            setTextColor(Color.BLACK)
        }
        dateButton.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                selectedDate = LocalDate.of(y, m + 1, d)
                dateButton.text = "📅 Fecha: $selectedDate"
            }, selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth).show()
        }

        val defaultTime = existing?.time ?: LocalTime.now().plusMinutes(2).withSecond(0).withNano(0).toString().substring(0, 5)
        val existingGroup = if (existing == null) emptyList() else tasks.filter { it.groupId == existing.groupId }.sortedBy { it.time }
        val selectedTimes = if (existingGroup.isNotEmpty()) existingGroup.map { it.time }.distinct().sorted().toMutableList() else mutableListOf(defaultTime)
        val timesLabel = TextView(this).apply {
            text = "Horarios de esta actividad"
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
            setPadding(4, 18, 4, 6)
        }
        val timesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        fun chooseTime(initial: String, onChosen: (String) -> Unit) {
            val parsed = runCatching { LocalTime.parse(initial) }.getOrDefault(LocalTime.now())
            TimePickerDialog(this, { _, hourOfDay, minute ->
                onChosen(String.format(Locale.US, "%02d:%02d", hourOfDay, minute))
            }, parsed.hour, parsed.minute, true).show()
        }

        fun renderTimes() {
            timesBox.removeAllViews()
            selectedTimes.forEachIndexed { index, value ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 4, 0, 4)
                }
                val timeButton = Button(this).apply {
                    text = "⏰  $value"
                    textSize = 19f
                    setTextColor(Color.BLACK)
                    minHeight = 60
                    setOnClickListener {
                        chooseTime(selectedTimes[index]) { chosen ->
                            selectedTimes[index] = chosen
                            renderTimes()
                        }
                    }
                }
                row.addView(timeButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                if (selectedTimes.size > 1) {
                    row.addView(Button(this).apply {
                        text = "✕"
                        textSize = 20f
                        contentDescription = "Eliminar horario $value"
                        minWidth = 64
                        minHeight = 60
                        setOnClickListener {
                            selectedTimes.removeAt(index)
                            renderTimes()
                        }
                    })
                }
                timesBox.addView(row)
            }
        }
        renderTimes()

        val addTimeButton = Button(this).apply {
            text = "＋ AGREGAR OTRO HORARIO"
            textSize = 18f
            setTextColor(Color.BLACK)
            minHeight = 60
            setOnClickListener {
                val initial = selectedTimes.lastOrNull() ?: defaultTime
                chooseTime(initial) { chosen ->
                    if (chosen !in selectedTimes) {
                        selectedTimes.add(chosen)
                        selectedTimes.sort()
                        renderTimes()
                    } else {
                        Toast.makeText(this@MainActivity, "Ese horario ya está agregado.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        val timeHint = TextView(this).apply {
            text = "Cada horario tendrá su propia alarma y su propio ✓ diario."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 10)
        }

        val options = arrayOf("Nunca", "Diaria", "Semanal", "Mensual", "Anual")
        val repeat = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
            existing?.let { setSelection(options.indexOf(it.repeat).coerceAtLeast(0)) }
        }

        val priorityLabel = TextView(this).apply {
            text = "Prioridad"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(4, 16, 4, 4)
        }
        val priorities = arrayOf("Verde", "Amarillo", "Rojo")
        val priority = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, priorities)
            setSelection(priorities.indexOf(existing?.priority ?: "Verde").coerceAtLeast(0))
        }

        val weeklyLabel = TextView(this).apply {
            text = "Días de la semana"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(4, 18, 4, 4)
        }
        val daysBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val dayInfo = listOf(
            DayOfWeek.MONDAY to "Lunes", DayOfWeek.TUESDAY to "Martes", DayOfWeek.WEDNESDAY to "Miércoles",
            DayOfWeek.THURSDAY to "Jueves", DayOfWeek.FRIDAY to "Viernes", DayOfWeek.SATURDAY to "Sábado",
            DayOfWeek.SUNDAY to "Domingo"
        )
        val existingDays = existing?.repeatDays?.split(',')?.toSet() ?: emptySet()
        val checks = dayInfo.map { (day, label) ->
            CheckBox(this).apply {
                text = label
                textSize = 18f
                setTextColor(Color.BLACK)
                isChecked = day.name in existingDays || (existingDays.isEmpty() && existing?.repeat == "Semanal" &&
                        runCatching { LocalDate.parse(existing.date).dayOfWeek }.getOrNull() == day)
                tag = day.name
                daysBox.addView(this)
            }
        }
        val dayShortcuts = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        dayShortcuts.addView(Button(this).apply {
            text = "LUN–VIE"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener {
                checks.forEachIndexed { index, check -> check.isChecked = index < 5 }
            }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dayShortcuts.addView(Button(this).apply {
            text = "TODOS"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener { checks.forEach { it.isChecked = true } }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dayShortcuts.addView(Button(this).apply {
            text = "LIMPIAR"
            textSize = 16f
            setTextColor(Color.BLACK)
            minHeight = 56
            setOnClickListener { checks.forEach { it.isChecked = false } }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        daysBox.addView(dayShortcuts)
        val monthlyHint = TextView(this).apply {
            text = "📅 En Mensual, el día elegido en el calendario será el día de repetición."
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(4, 14, 4, 10)
        }

        val annualHint = TextView(this).apply {
            text = "🎂 En Anual, se repetirá cada año en el mes y día que elijas en el calendario."
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(4, 12, 4, 10)
        }

        fun updateRepeatUi(position: Int) {
            val weekly = options[position] == "Semanal"
            val monthly = options[position] == "Mensual"
            weeklyLabel.visibility = if (weekly) View.VISIBLE else View.GONE
            daysBox.visibility = if (weekly) View.VISIBLE else View.GONE
            monthlyHint.visibility = if (monthly) View.VISIBLE else View.GONE
            annualHint.visibility = if (options[position] == "Anual") View.VISIBLE else View.GONE
        }
        repeat.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = updateRepeatUi(position)
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val note = editText("Notas opcionales", existing?.note ?: "")
        box.addView(title); box.addView(dateButton); box.addView(timesLabel); box.addView(timesBox); box.addView(addTimeButton); box.addView(timeHint)
        box.addView(repeat); box.addView(priorityLabel); box.addView(priority)
        box.addView(weeklyLabel); box.addView(daysBox); box.addView(monthlyHint); box.addView(annualHint); box.addView(note)
        updateRepeatUi(repeat.selectedItemPosition)

        val builder = android.app.AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Nueva actividad" else "Editar actividad")
            .setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("GUARDAR Y ACTIVAR") { _, _ ->
                val repeatType = repeat.selectedItem.toString()
                val selectedDays = checks.filter { it.isChecked }.joinToString(",") { it.tag.toString() }
                val cleanTitle = title.text.toString().trim()
                if (cleanTitle.isBlank()) {
                    Toast.makeText(this, "Escribe el mensaje de la alarma.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                if (repeatType == "Semanal" && selectedDays.isBlank()) {
                    Toast.makeText(this, "Marca al menos un día para la repetición semanal.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                val validTimes = selectedTimes.distinct().sorted().filter { runCatching { LocalTime.parse(it) }.isSuccess }
                if (validTimes.isEmpty()) {
                    Toast.makeText(this, "Escribe una hora válida, por ejemplo 06:30.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                // Para actividades de una sola vez, impedir guardar una fecha/hora ya pasada.
                if (repeatType == "Nunca") {
                    val now = java.time.LocalDateTime.now()
                    val hasFutureTime = validTimes.any { alarmTime ->
                        runCatching { java.time.LocalDateTime.of(selectedDate, LocalTime.parse(alarmTime)).isAfter(now) }.getOrDefault(false)
                    }
                    if (!hasFutureTime) {
                        Toast.makeText(this, "La fecha y hora ya pasaron. Elige hoy con una hora futura u otra fecha.", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                }

                if (existing != null) {
                    val oldGroup = tasks.filter { it.groupId == existing.groupId }
                    oldGroup.forEach { AlarmHelper.cancel(this, it.id) }
                    tasks.removeAll { it.groupId == existing.groupId }

                    val oldIds = oldGroup.sortedBy { it.time }.map { it.id }
                    val groupId = existing.groupId
                    validTimes.forEachIndexed { index, alarmTime ->
                        val taskId = oldIds.getOrNull(index) ?: (System.currentTimeMillis() + index)
                        val updated = Task(
                            taskId, cleanTitle, selectedDate.toString(), alarmTime, repeatType,
                            note.text.toString().trim(),
                            if (repeatType == "Semanal") selectedDays else "",
                            if (repeatType == "Mensual") selectedDate.dayOfMonth else 0,
                            priority.selectedItem.toString(),
                            groupId
                        )
                        tasks.add(updated)
                        TaskStore.setOnceDone(this, taskId, false) // al reprogramar, vuelve a "por hacer"
                        AlarmHelper.schedule(this, updated)
                    }
                    TaskStore.save(this, tasks)
                } else {
                    val baseId = System.currentTimeMillis()
                    validTimes.forEachIndexed { index, alarmTime ->
                        val task = Task(
                            baseId + index, cleanTitle, selectedDate.toString(), alarmTime, repeatType,
                            note.text.toString().trim(),
                            if (repeatType == "Semanal") selectedDays else "",
                            if (repeatType == "Mensual") selectedDate.dayOfMonth else 0,
                            priority.selectedItem.toString(),
                            baseId
                        )
                        tasks.add(task)
                        AlarmHelper.schedule(this, task)
                    }
                    TaskStore.save(this, tasks)
                }
                Toast.makeText(
                    this,
                    if (AlarmPause.isDisabled(this))
                        "${validTimes.size} actividad(es) guardada(s). Las alarmas siguen deshabilitadas."
                    else "${validTimes.size} alarma(s) activada(s)",
                    Toast.LENGTH_LONG
                ).show()
                draw()
            }
            .setNegativeButton("CANCELAR", null)

        if (existing != null) builder.setNeutralButton("🗑 ELIMINAR") { _, _ ->
            showDeleteOptions(existing)
        }
        builder.show()
    }

    private fun showDeleteOptions(existing: Task) {
        val group = tasks.filter { it.groupId == existing.groupId }
        val recurring = group.any { it.repeat != "Nunca" }

        fun deleteForever() {
            group.forEach { task ->
                AlarmHelper.cancel(this, task.id)
                setSkippedToday(task.id, false)
                setCompletedToday(task.id, false)
            }
            tasks.removeAll { it.groupId == existing.groupId }
            TaskStore.save(this, tasks)
            Toast.makeText(this, "Actividad eliminada.", Toast.LENGTH_LONG).show()
            draw()
        }

        if (recurring) {
            android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar actividad recurrente")
                .setMessage("Puedes omitir solamente las ocurrencias de hoy o eliminar toda la actividad y sus horarios futuros.")
                .setPositiveButton("ELIMINAR TODA") { _, _ ->
                    android.app.AlertDialog.Builder(this)
                        .setTitle("Confirmar eliminación")
                        .setMessage("¿Eliminar definitivamente ${existing.title} y toda su serie futura?")
                        .setPositiveButton("SÍ, ELIMINAR") { _, _ -> deleteForever() }
                        .setNegativeButton("CANCELAR", null)
                        .show()
                }
                .setNeutralButton("OMITIR SOLO HOY") { _, _ ->
                    group.forEach { setSkippedToday(it.id, true) }
                    Toast.makeText(this, "Actividad omitida solo por hoy. Mañana seguirá programada.", Toast.LENGTH_LONG).show()
                    draw()
                }
                .setNegativeButton("CANCELAR", null)
                .show()
        } else {
            android.app.AlertDialog.Builder(this)
                .setTitle("Eliminar actividad")
                .setMessage("¿Eliminar definitivamente ${existing.title}?")
                .setPositiveButton("ELIMINAR") { _, _ -> deleteForever() }
                .setNegativeButton("CANCELAR", null)
                .show()
        }
    }
}
