package com.stevedaily.app

import android.content.Context
import org.json.JSONObject
import java.time.Instant

/** Portable JSON backups for future STEVE Daily versions (no root or computer needed). */
object BackupManager {
    const val SCHEMA = "STEVE_DAILY_BACKUP_1"
    private val names = listOf(
        "steve_daily", "steve_lists", "steve_finances", "steve_profile",
        "daily_completion", "steve_skipped", "steve_once_done", "steve_snooze", "steve_pause"
    )

    fun export(context: Context): String {
        val prefs = JSONObject()
        names.forEach { name ->
            val data = JSONObject()
            context.getSharedPreferences(name, Context.MODE_PRIVATE).all.forEach { (k, v) ->
                when (v) {
                    is String, is Int, is Long, is Float, is Double, is Boolean -> data.put(k, v)
                    else -> Unit
                }
            }
            prefs.put(name, data)
        }
        return JSONObject()
            .put("schema", SCHEMA)
            .put("createdAt", Instant.now().toString())
            .put("originPackage", context.packageName)
            .put("prefs", prefs)
            .toString(2)
    }

    /** Returns false on an unsupported file rather than altering stored user data. */
    fun import(context: Context, content: String): Boolean {
        val root = runCatching { JSONObject(content) }.getOrNull() ?: return false
        if (root.optString("schema") != SCHEMA) return false
        val prefs = root.optJSONObject("prefs") ?: return false
        // Validate the essential collections before overwriting anything.
        val steve = prefs.optJSONObject("steve_daily") ?: return false
        val lists = prefs.optJSONObject("steve_lists") ?: return false
        val tasksRaw = steve.optString("tasks_json", "[]")
        val toBuyRaw = lists.optString("tobuy", "[]")
        if (runCatching { org.json.JSONArray(tasksRaw); org.json.JSONArray(toBuyRaw) }.isFailure) return false
        // Data from this exact backup format is restored by original preference name.
        names.forEach { name ->
            val objectForName = prefs.optJSONObject(name) ?: return@forEach
            val edit = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            objectForName.keys().forEach { key ->
                when (val v = objectForName.get(key)) {
                    is String -> edit.putString(key, v)
                    is Boolean -> edit.putBoolean(key, v)
                    is Int -> edit.putInt(key, v)
                    is Long -> edit.putLong(key, v)
                    is Float -> edit.putFloat(key, v)
                    is Double -> edit.putFloat(key, v.toFloat())
                    else -> Unit
                }
            }
            if (!edit.commit()) return false
        }
        val paused = prefs.optJSONObject("steve_pause")?.optBoolean("disabled", false)
        if (paused != null) AlarmPause.setDisabled(context, paused)
        return true
    }
}
