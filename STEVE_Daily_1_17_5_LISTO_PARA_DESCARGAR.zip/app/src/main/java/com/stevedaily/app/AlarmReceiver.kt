package com.stevedaily.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra("taskId", -1L)
        val isSnooze = intent.action == AlarmHelper.ACTION_SNOOZE
        val isTest = intent.action == AlarmHelper.ACTION_TEST
        if (isSnooze) AlarmHelper.clearSnooze(context, taskId)

        val task = if (isTest) null else TaskStore.find(context, taskId)
        val fallbackText = intent.getStringExtra("text")
        // v1.17: si por algún motivo no se puede leer la agenda, es mejor sonar con el texto
        // que viene en la propia alarma que quedarse en silencio.
        if (!isTest && task == null && fallbackText.isNullOrBlank()) return

        val today = java.time.LocalDate.now().toString()
        val alarmsDisabled = AlarmPause.isDisabled(context)
        val skippedToday = context.getSharedPreferences("steve_skipped", Context.MODE_PRIVATE)
            .getBoolean("${today}_$taskId", false)
        val completedToday = context.getSharedPreferences("daily_completion", Context.MODE_PRIVATE)
            .getBoolean("${today}_$taskId", false)
        // v1.17: una actividad de una sola vez ya marcada como hecha no debe sonar.
        val onceDone = task?.repeat == "Nunca" && TaskStore.isOnceDone(context, taskId)

        if (alarmsDisabled && !isTest) return
        // Es imprescindible rearmar mañana ANTES de omitir una alarma de hoy.
        if (!isSnooze && !isTest && task != null && task.repeat != "Nunca") AlarmHelper.schedule(context, task)
        if (skippedToday || completedToday || onceDone) return

        // El servicio mantiene su propio wake lock. Evita dejar despierta la pantalla
        // durante un minuto cuando el usuario está en otra aplicación.

        // Diagnostico: distingue actividad vencida de alarma realmente recibida.
        context.getSharedPreferences("steve_alarm_diag", Context.MODE_PRIVATE).edit()
            .putLong("last_receiver_received_ms", System.currentTimeMillis())
            .putString("last_receiver_task", task?.title ?: fallbackText)
            .apply()

        val serviceIntent = Intent(context, AlarmForegroundService::class.java).apply {
            putExtra("taskId", taskId)
            putExtra("text", fallbackText)
            putExtra("activityAlreadyVisible", false)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }.onFailure { error ->
            context.getSharedPreferences("steve_alarm_diag", Context.MODE_PRIVATE).edit()
                .putLong("last_service_error_ms", System.currentTimeMillis())
                .putString("last_service_error", error.javaClass.simpleName + ": " + error.message)
                .apply()
        }
    }
}
