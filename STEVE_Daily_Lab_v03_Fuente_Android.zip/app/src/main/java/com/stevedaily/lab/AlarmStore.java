package com.stevedaily.lab;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.Date;

public final class AlarmStore {
    private static final String PREF = "steve_daily_lab_tasks_v1";
    private static final String KEY = "alarms";
    private static final String BACKUP_FORMAT = "steve-daily-lab-activities";
    private static final int BACKUP_VERSION = 1;
    private AlarmStore() {}

    private static String today() {
        return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
    }

    public static boolean isCompleted(JSONObject item) {
        if (item == null) return false;
        if (item.optBoolean("daily"))
            return today().equals(item.optString("lastDoneDay", ""));
        return item.optBoolean("done", false);
    }

    public static synchronized JSONObject makeBackup(Context c) throws JSONException {
        JSONObject result = new JSONObject();
        result.put("format", BACKUP_FORMAT);
        result.put("version", BACKUP_VERSION);
        result.put("createdAt", System.currentTimeMillis());
        result.put("activities", all(c));
        return result;
    }

    public static int validateBackup(JSONObject backup) throws JSONException {
        if (!BACKUP_FORMAT.equals(backup.optString("format")) || backup.optInt("version", -1) != BACKUP_VERSION)
            throw new JSONException("El archivo no corresponde a STEVE Daily Lab.");
        JSONArray items = backup.optJSONArray("activities");
        if (items == null || items.length() > 5000)
            throw new JSONException("La lista es inválida o demasiado larga.");
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) throw new JSONException("Actividad inválida: " + (i + 1));
            String name = item.optString("name", "").trim();
            if (name.isEmpty() || name.length() > 200 || !(item.opt("when") instanceof Number) ||
                    item.optLong("when") < 946684800000L || item.optLong("when") > 4102444800000L ||
                    !(item.opt("daily") instanceof Boolean) || !(item.opt("done") instanceof Boolean))
                throw new JSONException("Datos inválidos en la actividad " + (i + 1));
            String lastDoneDay = item.optString("lastDoneDay", "");
            if (!lastDoneDay.isEmpty() && !lastDoneDay.matches("[0-9]{8}"))
                throw new JSONException("Fecha de realización inválida.");
        }
        return items.length();
    }

    // Sin sobrescribir actividades; compatible con respaldos anteriores de Lab 0.2.
    public static synchronized int importBackup(Context c, JSONObject backup) throws JSONException {
        validateBackup(backup);
        JSONArray imported = backup.getJSONArray("activities");
        JSONArray current = all(c);
        Set<String> known = new HashSet<>();
        SharedPreferences prefs = c.getSharedPreferences(PREF, 0);
        int next = prefs.getInt("nextId", 1000);
        for (int i = 0; i < current.length(); i++) {
            JSONObject old = current.optJSONObject(i);
            if (old == null) continue;
            next = Math.max(next, old.optInt("id", 1000));
            known.add(backupKey(old));
        }
        JSONArray combined = new JSONArray();
        for (int i = 0; i < current.length(); i++) combined.put(current.optJSONObject(i));
        JSONArray newlyAdded = new JSONArray();
        for (int i = 0; i < imported.length(); i++) {
            JSONObject source = imported.getJSONObject(i);
            String key = backupKey(source);
            if (known.contains(key)) continue;
            if (next > 200000000) throw new JSONException("Demasiadas actividades");
            JSONObject item = new JSONObject();
            item.put("id", ++next);
            item.put("name", source.getString("name").trim());
            item.put("when", source.getLong("when"));
            boolean daily = source.getBoolean("daily");
            item.put("daily", daily);
            // Una actividad diaria completada en Lab 0.2 no debe quedar cancelada para siempre.
            item.put("done", daily ? false : source.getBoolean("done"));
            if (daily) {
                String last = source.optString("lastDoneDay", "");
                if (last.isEmpty() && source.getBoolean("done")) last = today();
                item.put("lastDoneDay", last);
            }
            combined.put(item);
            newlyAdded.put(item);
            known.add(key);
        }
        if (newlyAdded.length() == 0) return 0;
        boolean saved = prefs.edit().putString(KEY, combined.toString())
                .putInt("nextId", next).commit();
        if (!saved) throw new JSONException("Android no pudo guardar los datos");
        for (int i = 0; i < newlyAdded.length(); i++)
            schedule(c, newlyAdded.optJSONObject(i), false, 0L);
        return newlyAdded.length();
    }

    private static String backupKey(JSONObject item) {
        return item.optString("name", "").trim().toLowerCase(Locale.ROOT) + "\u0000"
                + item.optLong("when") + "\u0000" + item.optBoolean("daily");
    }

    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply();
    }

    public static synchronized int add(Context c, String name, long when, boolean daily) {
        SharedPreferences prefs = c.getSharedPreferences(PREF, 0);
        int id = prefs.getInt("nextId", 1000) + 1;
        prefs.edit().putInt("nextId", id).apply();
        JSONArray list = all(c);
        JSONObject item = new JSONObject();
        try {
            item.put("id", id);
            item.put("name", name);
            item.put("when", when);
            item.put("daily", daily);
            item.put("done", false);
            item.put("lastDoneDay", "");
            list.put(item);
            save(c, list);
            schedule(c, item, false, 0L);
        } catch (JSONException e) { return -1; }
        return id;
    }

    public static synchronized boolean update(Context c, int id, String name, long when, boolean daily) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null && item.optInt("id") == id) {
                try {
                    cancel(c, id, false);
                    cancel(c, id, true);
                    dismissNotification(c, id);
                    item.put("name", name);
                    item.put("when", when);
                    item.put("daily", daily);
                    item.put("done", false);
                    item.put("lastDoneDay", "");
                    save(c, list);
                    schedule(c, item, false, 0L);
                    return true;
                } catch (JSONException ignored) { return false; }
            }
        }
        return false;
    }

    public static synchronized boolean delete(Context c, int id) {
        JSONArray list = all(c);
        JSONArray remaining = new JSONArray();
        boolean found = false;
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item == null) continue;
            if (item.optInt("id") == id) found = true;
            else remaining.put(item);
        }
        if (found) {
            cancel(c, id, false);
            cancel(c, id, true);
            dismissNotification(c, id);
            save(c, remaining);
        }
        return found;
    }

    public static synchronized void markDone(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null && item.optInt("id") == id) {
                try {
                    if (item.optBoolean("daily")) {
                        item.put("done", false);
                        item.put("lastDoneDay", today());
                    } else item.put("done", true);
                } catch (JSONException ignored) {}
                cancel(c, id, false);
                cancel(c, id, true);
                dismissNotification(c, id);
                save(c, list);
                if (item.optBoolean("daily")) schedule(c, item, false, 0L);
                return;
            }
        }
    }

    public static synchronized void markPending(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null && item.optInt("id") == id) {
                try { item.put("done", false); item.put("lastDoneDay", ""); }
                catch (JSONException ignored) {}
                cancel(c, id, false);
                cancel(c, id, true);
                save(c, list);
                schedule(c, item, false, 0L);
                return;
            }
        }
    }

    public static JSONObject get(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null && item.optInt("id") == id) return item;
        }
        return null;
    }

    private static void dismissNotification(Context c, int id) {
        NotificationManager manager = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.cancel(id);
    }

    private static PendingIntent alarmIntent(Context c, int id, boolean snooze) {
        Intent intent = new Intent(c, AlarmReceiver.class)
                .putExtra("id", id).putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, id * 2 + (snooze ? 1 : 0), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancel(Context c, int id, boolean snooze) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr != null) mgr.cancel(alarmIntent(c, id, snooze));
    }

    public static boolean canExact(Context c) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return mgr != null && (Build.VERSION.SDK_INT < 31 || mgr.canScheduleExactAlarms());
    }

    public static long nextTime(JSONObject item) {
        long trigger = item.optLong("when");
        if (!item.optBoolean("daily")) return trigger;
        Calendar next = Calendar.getInstance();
        Calendar original = Calendar.getInstance();
        original.setTimeInMillis(trigger);
        next.set(Calendar.HOUR_OF_DAY, original.get(Calendar.HOUR_OF_DAY));
        next.set(Calendar.MINUTE, original.get(Calendar.MINUTE));
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        if (isCompleted(item) || next.getTimeInMillis() <= System.currentTimeMillis() + 1000)
            next.add(Calendar.DAY_OF_YEAR, 1);
        return next.getTimeInMillis();
    }

    public static void schedule(Context c, JSONObject item, boolean snooze, long delayMillis) {
        if (item == null || (item.optBoolean("done") && !item.optBoolean("daily"))) return;
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr == null) return;
        int id = item.optInt("id");
        long trigger;
        if (snooze) {
            if (isCompleted(item)) return;
            trigger = System.currentTimeMillis() + delayMillis;
        } else {
            trigger = nextTime(item);
            if (trigger <= System.currentTimeMillis() && !item.optBoolean("daily")) return;
        }
        PendingIntent pi = alarmIntent(c, id, snooze);
        if (canExact(c)) {
            PendingIntent show = PendingIntent.getActivity(c, id, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            mgr.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, show), pi);
        } else mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
    }

    public static void reprogram(Context c) {
        JSONArray items = all(c);
        for (int i = 0; i < items.length(); i++) schedule(c, items.optJSONObject(i), false, 0);
    }
}
