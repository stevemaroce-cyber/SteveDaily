package com.stevedaily.lab;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 401;
    private static final int RESTORE_BACKUP = 402;
    private static final int MAX_BACKUP_BYTES = 1024 * 1024;
    private static final int BLUE = Color.rgb(17, 91, 178);
    private static final int GREEN = Color.rgb(31, 111, 57);
    private static final int RED = Color.rgb(174, 29, 39);
    private static final int DARK = Color.rgb(26, 33, 43);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AlarmReceiver.makeChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
    }

    @Override protected void onResume() { super.onResume(); display(); }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable rounded(int background, int border) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(background);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), border);
        return bg;
    }

    private TextView text(String content, int size, int color, boolean bold) {
        TextView label = new TextView(this);
        label.setText(content);
        label.setTextSize(size);
        label.setTextColor(color);
        if (bold) label.setTypeface(null, Typeface.BOLD);
        return label;
    }

    private Button button(String label, int background) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(16);
        b.setTypeface(null, Typeface.BOLD);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(background, background));
        b.setMinHeight(dp(58));
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        return b;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addFullButton(LinearLayout parent, Button button, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(58));
        p.setMargins(0, dp(top), 0, dp(bottom));
        parent.addView(button, p);
    }

    private void section(LinearLayout root, String title) {
        TextView heading = text(title, 23, DARK, true);
        heading.setPadding(0, dp(18), 0, dp(8));
        root.addView(heading);
    }

    private void display() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(16), dp(18), dp(34));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        setContentView(scroll);

        TextView heading = text("STEVE Daily Lab 0.3", 28, DARK, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        TextView description = text("Pruebas de agenda · sin modificar tus otras aplicaciones", 15, DARK, false);
        description.setGravity(Gravity.CENTER);
        description.setPadding(0, dp(8), 0, dp(17));
        root.addView(description);

        if (!AlarmStore.canExact(this)) {
            root.addView(text("Autoriza 'Alarmas y recordatorios' para horarios exactos.", 16, RED, true));
            Button permission = button("ACTIVAR ALARMAS EXACTAS", BLUE);
            addFullButton(root, permission, 12, 12);
            permission.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 31)
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
            });
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                root.addView(text("Activa pantalla completa para ver las alarmas con el teléfono bloqueado.", 15, RED, true));
                Button full = button("PERMITIR PANTALLA COMPLETA", BLUE);
                addFullButton(root, full, 10, 10);
                full.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()))));
            }
        }

        Button create = button("+ NUEVA ACTIVIDAD", BLUE);
        addFullButton(root, create, 4, 14);
        create.setOnClickListener(v -> showEditor(null));
        section(root, "Actividades guardadas");

        JSONArray list = AlarmStore.all(this);
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item != null) items.add(item);
        }
        items.sort(Comparator.comparing(AlarmStore::isCompleted)
                .thenComparingLong(AlarmStore::nextTime));
        if (items.isEmpty()) {
            TextView empty = text("Todavía no hay actividades. Presiona + NUEVA ACTIVIDAD para crear una.", 17, DARK, false);
            empty.setPadding(dp(6), dp(18), dp(6), dp(20));
            root.addView(empty);
        }
        for (JSONObject item : items) addActivity(root, item);

        section(root, "Copias de seguridad");
        TextView info = text("Guarda tus actividades en un archivo y recupéralas si cambias de versión o de teléfono.", 16, DARK, false);
        info.setPadding(0, dp(2), 0, dp(8));
        root.addView(info);
        Button export = button("GUARDAR RESPALDO", BLUE);
        addFullButton(root, export, 9, 8);
        export.setOnClickListener(v -> chooseExport());
        Button restore = button("RECUPERAR RESPALDO", GREEN);
        addFullButton(root, restore, 8, 12);
        restore.setOnClickListener(v -> chooseImport());
        TextView note = text("Los respaldos son archivos JSON privados. Para trasladar actividades desde Lab 0.2, exporta allí y luego recupera el archivo aquí.", 14, DARK, false);
        note.setPadding(0, dp(6), 0, dp(10));
        root.addView(note);
        root.addView(text("Activa notificaciones y permite funcionar en segundo plano. Prueba las alarmas con la pantalla apagada antes de depender de ellas.", 14, DARK, false));
    }

    private void addActivity(LinearLayout root, JSONObject item) {
        final int id = item.optInt("id", -1);
        final String name = item.optString("name", "Actividad");
        final boolean completed = AlarmStore.isCompleted(item);
        final boolean daily = item.optBoolean("daily");

        LinearLayout card = column();
        card.setPadding(dp(15), dp(15), dp(15), dp(15));
        int background = completed ? Color.rgb(237, 250, 241) : Color.rgb(255, 245, 245);
        int border = completed ? Color.rgb(160, 205, 173) : Color.rgb(239, 190, 190);
        card.setBackground(rounded(background, border));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.setMargins(0, dp(9), 0, dp(13));
        root.addView(card, cardParams);

        TextView title = text(name, 21, DARK, true);
        title.setPadding(0, 0, 0, dp(7));
        card.addView(title);
        String timing = daily
                ? "Todos los días · " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date(item.optLong("when")))
                : DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(item.optLong("when")));
        TextView time = text(timing, 16, DARK, false);
        card.addView(time);
        String status = completed ? (daily ? "REALIZADO HOY" : "REALIZADO") : "PENDIENTE";
        TextView statusView = text(status, 16, completed ? GREEN : RED, true);
        statusView.setPadding(0, dp(7), 0, dp(12));
        card.addView(statusView);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        Button edit = button("EDITAR", BLUE);
        LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, dp(60), 1);
        left.setMargins(0, 0, dp(7), 0);
        actions.addView(edit, left);
        edit.setOnClickListener(v -> showEditor(AlarmStore.get(this, id)));
        Button done = button(completed ? "DESMARCAR" : "REALIZADO", GREEN);
        LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, dp(60), 1);
        right.setMargins(dp(7), 0, 0, 0);
        actions.addView(done, right);
        done.setOnClickListener(v -> {
            if (completed) AlarmStore.markPending(this, id);
            else AlarmStore.markDone(this, id);
            display();
        });

        Button delete = button("BORRAR ACTIVIDAD", RED);
        addFullButton(card, delete, 15, 0);
        delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Confirmar borrado")
                .setMessage("¿Borrar '" + name + "'? Esta acción no se puede deshacer. Puedes guardar un respaldo antes.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("BORRAR", (dialog, which) -> {
                    AlarmStore.delete(this, id);
                    Toast.makeText(this, "Actividad borrada", Toast.LENGTH_SHORT).show();
                    display();
                }).show());
    }

    private void showEditor(JSONObject existing) {
        final boolean editing = existing != null;
        final int id = editing ? existing.optInt("id") : -1;
        final Calendar selection = Calendar.getInstance();
        if (editing) selection.setTimeInMillis(existing.optLong("when", System.currentTimeMillis()));
        else selection.add(Calendar.MINUTE, 10);
        selection.set(Calendar.SECOND, 0);
        selection.set(Calendar.MILLISECOND, 0);

        LinearLayout form = column();
        form.setPadding(dp(20), dp(8), dp(20), dp(4));
        form.addView(text("Nombre de la actividad", 16, DARK, true));
        EditText nameField = new EditText(this);
        nameField.setText(editing ? existing.optString("name") : "");
        nameField.setTextSize(19);
        nameField.setSingleLine(false);
        nameField.setMaxLines(2);
        nameField.setHint("Ejemplo: comida a las mascotas");
        form.addView(nameField);
        CheckBox daily = new CheckBox(this);
        daily.setText("Repetir todos los días");
        daily.setTextSize(17);
        daily.setTextColor(DARK);
        daily.setChecked(editing && existing.optBoolean("daily"));
        daily.setPadding(0, dp(10), 0, dp(10));
        form.addView(daily);
        TextView picked = text("", 17, DARK, true);
        picked.setPadding(0, dp(8), 0, dp(8));
        form.addView(picked);
        Button date = button("CAMBIAR FECHA", BLUE);
        addFullButton(form, date, 6, 8);
        Button time = button("CAMBIAR HORA", BLUE);
        addFullButton(form, time, 6, 8);
        Runnable refresh = () -> {
            String label = daily.isChecked()
                    ? "Hora diaria: " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(selection.getTime())
                    : "Fecha y hora: " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(selection.getTime());
            picked.setText(label);
            date.setVisibility(daily.isChecked() ? View.GONE : View.VISIBLE);
        };
        refresh.run();
        daily.setOnCheckedChangeListener((buttonView, checked) -> refresh.run());
        date.setOnClickListener(v -> new DatePickerDialog(this, (picker, year, month, day) -> {
            selection.set(Calendar.YEAR, year);
            selection.set(Calendar.MONTH, month);
            selection.set(Calendar.DAY_OF_MONTH, day);
            refresh.run();
        }, selection.get(Calendar.YEAR), selection.get(Calendar.MONTH), selection.get(Calendar.DAY_OF_MONTH)).show());
        time.setOnClickListener(v -> new TimePickerDialog(this, (picker, hour, minute) -> {
            selection.set(Calendar.HOUR_OF_DAY, hour);
            selection.set(Calendar.MINUTE, minute);
            refresh.run();
        }, selection.get(Calendar.HOUR_OF_DAY), selection.get(Calendar.MINUTE), false).show());

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(editing ? "Editar actividad" : "Nueva actividad")
                .setView(form)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("GUARDAR", null)
                .create();
        dialog.setOnShowListener(unused -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String title = nameField.getText().toString().trim();
            if (title.isEmpty() || title.length() > 200) {
                nameField.setError("Escribe un nombre de hasta 200 caracteres");
                return;
            }
            boolean repeat = daily.isChecked();
            if (!repeat && selection.getTimeInMillis() < System.currentTimeMillis() + 5000) {
                Toast.makeText(this, "Elige una fecha y hora futuras", Toast.LENGTH_LONG).show();
                return;
            }
            boolean ok = editing
                    ? AlarmStore.update(this, id, title, selection.getTimeInMillis(), repeat)
                    : AlarmStore.add(this, title, selection.getTimeInMillis(), repeat) > 0;
            if (!ok) { Toast.makeText(this, "No se pudo guardar. Inténtalo otra vez", Toast.LENGTH_LONG).show(); return; }
            dialog.dismiss();
            Toast.makeText(this, editing ? "Actividad actualizada" : "Actividad guardada", Toast.LENGTH_SHORT).show();
            display();
        }));
        dialog.show();
    }

    private void chooseExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "STEVE_Daily_Respaldo_" + stamp + ".json");
        try { startActivityForResult(intent, CREATE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para guardar el archivo."); }
    }

    private void chooseImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try { startActivityForResult(intent, RESTORE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para abrir archivos."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == CREATE_BACKUP) {
            try {
                JSONObject backup = AlarmStore.makeBackup(this);
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                    if (stream == null) throw new Exception("No se pudo abrir el archivo de destino");
                    byte[] bytes = backup.toString(2).getBytes(StandardCharsets.UTF_8);
                    stream.write(bytes);
                    stream.flush();
                }
                message("Respaldo guardado: " + AlarmStore.all(this).length() + " actividades");
            } catch (Exception e) {
                showError("No se pudo guardar el respaldo: " + e.getMessage());
            }
        } else if (requestCode == RESTORE_BACKUP) {
            try {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    if (stream == null) throw new Exception("No se pudo leer el archivo");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = stream.read(buffer)) != -1) {
                        if (bytes.size() + count > MAX_BACKUP_BYTES)
                            throw new Exception("El archivo es demasiado grande (máximo 1 MB)");
                        bytes.write(buffer, 0, count);
                    }
                }
                JSONObject backup = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                int total = AlarmStore.validateBackup(backup);
                new AlertDialog.Builder(this)
                        .setTitle("Confirmar importación")
                        .setMessage("El archivo contiene " + total + " actividades. Se agregarán solo las que no existan; ninguna actividad actual se borrará. ¿Importar ahora?")
                        .setPositiveButton("IMPORTAR", (dialog, which) -> {
                            try {
                                int imported = AlarmStore.importBackup(this, backup);
                                new AlertDialog.Builder(this)
                                        .setTitle("Respaldo recuperado")
                                        .setMessage("Actividades nuevas: " + imported + "\nDuplicadas omitidas: " + (total - imported))
                                        .setPositiveButton("ENTENDIDO", null)
                                        .show();
                                display();
                            } catch (Exception e) { showError("No se pudo importar: " + e.getMessage()); }
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
            } catch (Exception e) {
                showError("El archivo no es un respaldo válido: " + e.getMessage());
            }
        }
    }

    private void showError(String description) {
        new AlertDialog.Builder(this).setTitle("Aviso del respaldo")
                .setMessage(description).setPositiveButton("ENTENDIDO", null).show();
    }
    private void message(String description) {
        Toast.makeText(this, description, Toast.LENGTH_LONG).show();
    }
}
