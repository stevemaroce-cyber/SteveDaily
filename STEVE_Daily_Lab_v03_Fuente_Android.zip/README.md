# STEVE Daily Lab 0.3 · editar, borrar y mejorar la pantalla

**Código fuente para Android.** Aún debe compilarse en GitHub y probarse antes de instalarse o de depender de él como agenda principal.

## Novedades

- Tarjetas separadas para cada actividad, fondo claro y letras grandes.
- **EDITAR** en azul: permite cambiar nombre, fecha, hora y repetición diaria. Tras guardar reprograma las alarmas.
- **REALIZADO** en verde: marca una actividad como completada.
- **DESMARCAR**: permite revertir un realizado accidental.
- **BORRAR ACTIVIDAD** en rojo: solicita confirmación y cancela avisos pendientes.
- Los avisos diarios marcados como realizados **se reprograman para el próximo día**, sin perder la recurrencia.
- Conserva alarma hablada, pantalla de aviso, posponer 5/30/60 minutos.
- Conserva respaldo JSON e importación no destructiva de actividades. **Compatible con respaldos de Lab 0.2**.

## Instalación independiente

- Identificador: `com.stevedaily.lab.v03`.
- Se instala **al lado** de la Lab 0.2 y de STEVE Daily original, sin modificarlas.
- Comienza vacía. Para trasladar actividades de Lab 0.2, crea allí un respaldo JSON y recupéralo desde Lab 0.3.
- No se pueden recuperar automáticamente las actividades de STEVE Daily original sin un formato de exportación compatible.
- No actives el mismo aviso a la misma hora en varias apps durante las pruebas: sonarán duplicados.

La APK compilada mediante GitHub Actions estará firmada para pruebas (depuración). Esta firma puede cambiar entre ejecuciones; no se garantiza la instalación de nuevas compilaciones encima de una previa. **Guarda un respaldo antes de desinstalar o cambiar de versión.**

## Compilar desde el Honor, usando el repositorio existente

1. Sube `STEVE_Daily_Lab_v03_Fuente_Android.zip` a la raíz del repositorio `stevemaroce-cyber/SteveDaily`.
2. Edita `.github/workflows/build-lab.yml`, sustituyendo únicamente la línea que comienza por `run: unzip` por:

   `run: unzip -q STEVE_Daily_Lab_v03_Fuente_Android.zip -d lab`

3. Guarda con **Commit changes**. GitHub Actions compilará la nueva APK.
4. Abre el último trabajo **Compilar STEVE Daily Lab**; si se completa en verde, descarga el artefacto `STEVE-Daily-Lab-APK` (ZIP). Dentro está `app-debug.apk`.
5. Instálala con el gestor de archivos. Comprueba primero el sonido y el posponer con pantalla apagada.

## Limitaciones actuales

- Repitición diaria y avisos únicos; repeticiones semanales, mensuales y anuales aún no están incorporadas.
- No se ha probado en un dispositivo en este entorno. Compilar sin errores no garantiza fiabilidad de alarmas en segundo plano.
- El respaldo JSON contiene los nombres de actividades sin cifrar; mantenlo en un lugar privado.
