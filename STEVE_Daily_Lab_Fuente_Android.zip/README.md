# STEVE Daily Lab · Android (independiente)

Proyecto nativo Android Java creado **desde cero**, con identificador separado `com.stevedaily.lab`.
No sustituye ni altera la instalación antigua del Honor 400. No importa automáticamente sus actividades.

## Primer alcance
- Actividades de una sola vez o repetidas cada día
- Notificaciones de alarma y pantalla de aviso, con botones grandes
- Posponer 5, 30 o 60 minutos
- Marcar realizado
- Datos guardados localmente y reprogramación después de reiniciar
- Voz TTS en español cuando abre la pantalla de aviso (el sistema puede impedir la apertura automática; la notificación sonora sigue siendo el respaldo)

## Construcción sin PC
Al subir **los archivos y carpetas** de este proyecto a un repositorio de GitHub con Actions habilitado,
el archivo `.github/workflows/build-apk.yml` ejecuta Gradle en GitHub y crea un artefacto ZIP llamado `STEVE-Daily-Lab-APK` con `app-debug.apk`.
La APK de depuración está destinada únicamente a pruebas y no a distribución de producción.

## Limitaciones importantes
- Este paquete contiene **código fuente, NO una APK lista para instalar**. La compilación todavía no se ha ejecutado/verificado.
- Antes de usar, se deben conceder permisos de notificaciones y alarmas exactas; en Android reciente, permiso de pantalla completa cuando esté disponible.
- El modo silencio, No molestar, restricciones del fabricante y el volumen de alarmas afectan la salida. La app no puede garantizar sonido en cualquier configuración.
- En esta primera versión no hay importación de actividades, controles mensuales/anuales, listas de compras ni sincronización.
- Al marcar realizado una tarea repetitiva se desactiva su repetición. La opción de completar una sola ocurrencia es una mejora posterior.

## Notas para GitHub
El workflow debe estar en `.github/workflows/` (minúsculas); el archivo antiguo `.github/Workflows/Android.yml` del repositorio no compila APK.
