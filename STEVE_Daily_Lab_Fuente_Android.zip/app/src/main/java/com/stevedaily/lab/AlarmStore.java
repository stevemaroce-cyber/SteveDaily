package com.stevedaily.lab;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public final class AlarmStore {
    private static final String PREF = "steve_daily_lab_tasks_v1";
    private static final String KEY = "alarms";
    private AlarmStore() {}

    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply();
    }

    public static synchronized int add(Context c, String name, long when, boolean daily) {
        int id = c.getSharedPreferences(PREF, 0).getInt("nextId", 1000) + 1;
        c.getSharedPreferences(PREF, 0).edit().putInt("nextId", id).apply();
        JSONArray list = all(c);
        JSONObject item = new JSONObject();
        try {
            item.put("id", id);
            item.put("name", name);
            item.put("when", when);
            item.put("daily", daily);
            item.put("done", false);
            list.put(item);
            save(c, list);
            schedule(c, item, false, 0L);
        } catch (Exception ignored) {}
        return id;
    }

    public static synchronized void markDone(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optInt("id") == id) {
                try { o.put("done", true); } catch (Exception ignored) {}
                cancel(c, id, false);
                cancel(c, id, true);
                break;
            }
        }
        save(c, list);
    }

    public static JSONObject get(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optInt("id") == id) return o;
        }
        return null;
    }

    private static PendingIntent alarmIntent(Context c, int id, boolean snooze) {
        Intent intent = new Intent(c, AlarmReceiver.class)
                .putExtra("id", id).putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, id * 2 + (snooze ? 1 : 0), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancel(Context c, int id, boolean snooze) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr != null) mgr.cancel(alarmIntent(c, id, snooze));
    }

    public static boolean canExact(Context c) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return mgr != null && (Build.VERSION.SDK_INT < 31 || mgr.canScheduleExactAlarms());
    }

    public static void schedule(Context c, JSONObject item, boolean snooze, long delayMillis) {
        if (item == null || item.optBoolean("done")) return;
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr == null) return;
        int id = item.optInt("id");
        long trigger;
        if (snooze) trigger = System.currentTimeMillis() + delayMillis;
        else {
            trigger = item.optLong("when");
            if (item.optBoolean("daily")) {
                Calendar next = Calendar.getInstance();
                Calendar original = Calendar.getInstance();
                original.setTimeInMillis(trigger);
                next.set(Calendar.HOUR_OF_DAY, original.get(Calendar.HOUR_OF_DAY));
                next.set(Calendar.MINUTE, original.get(Calendar.MINUTE));
                next.set(Calendar.SECOND, 0);
                next.set(Calendar.MILLISECOND, 0);
                if (next.getTimeInMillis() <= System.currentTimeMillis() + 1000) next.add(Calendar.DAY_OF_YEAR, 1);
                trigger = next.getTimeInMillis();
            } else if (trigger <= System.currentTimeMillis()) return;
        }
        PendingIntent pi = alarmIntent(c, id, snooze);
        if (canExact(c)) {
            PendingIntent show = PendingIntent.getActivity(c, id, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            mgr.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, show), pi);
        } else {
            // Respaldo inexacto: Android puede retrasarlo mientras el equipo duerme.
            mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void reprogram(Context c) {
        JSONArray items = all(c);
        for (int i = 0; i < items.length(); i++) schedule(c, items.optJSONObject(i), false, 0);
    }
}
