package com.stevedaily.lab;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AlarmReceiver.makeChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }
    @Override protected void onResume() { super.onResume(); display(); }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setMinHeight(92);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 9, 0, 9);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String label, int size) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(Color.BLACK);
        v.setPadding(0, 12, 0, 12);
        return v;
    }

    private void display() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(24, 28, 24, 40);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = text("STEVE Daily Lab", 29);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        root.addView(text("Aplicación independiente de pruebas. Tus alarmas actuales del Honor no se modifican.", 16));
        if (!AlarmStore.canExact(this)) {
            root.addView(text("ATENCIÓN: activa el permiso 'Alarmas y recordatorios' para avisos exactos.", 17));
            Button permission = button("ACTIVAR ALARMAS EXACTAS");
            root.addView(permission);
            permission.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 31)
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
            });
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                root.addView(text("Para aparecer encima de la pantalla bloqueada, autoriza avisos de pantalla completa.", 16));
                Button full = button("PERMITIR PANTALLA COMPLETA");
                root.addView(full);
                full.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()))));
            }
        }
        root.addView(text("Nueva actividad", 23));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setTextSize(19);
        name.setHint("Ejemplo: dar comida a las mascotas");
        root.addView(name);
        CheckBox daily = new CheckBox(this);
        daily.setText("Repetir todos los días");
        daily.setTextSize(18);
        daily.setTextColor(Color.BLACK);
        root.addView(daily);
        Button chooseTime = button("ELEGIR HORA Y GUARDAR");
        root.addView(chooseTime);
        chooseTime.setOnClickListener(v -> {
            String title = name.getText().toString().trim();
            if (title.isEmpty()) { Toast.makeText(this, "Escribe el nombre de la actividad", Toast.LENGTH_LONG).show(); return; }
            Calendar now = Calendar.getInstance();
            new TimePickerDialog(this, (picker, hour, minute) -> {
                Calendar when = Calendar.getInstance();
                when.set(Calendar.HOUR_OF_DAY, hour);
                when.set(Calendar.MINUTE, minute);
                when.set(Calendar.SECOND, 0);
                when.set(Calendar.MILLISECOND, 0);
                if (when.getTimeInMillis() <= System.currentTimeMillis() + 5000) when.add(Calendar.DAY_OF_YEAR, 1);
                AlarmStore.add(this, title, when.getTimeInMillis(), daily.isChecked());
                Toast.makeText(this, "Actividad guardada", Toast.LENGTH_LONG).show();
                display();
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
        });
        root.addView(text("Actividades guardadas", 23));
        JSONArray list = AlarmStore.all(this);
        if (list.length() == 0) root.addView(text("Todavía no hay actividades.", 17));
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item == null) continue;
            int id = item.optInt("id");
            String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                            .format(new Date(item.optLong("when")));
            String description = item.optString("name") + "\n" + when +
                    (item.optBoolean("daily") ? " · Cada día" : " · Una vez") +
                    (item.optBoolean("done") ? " · REALIZADO" : " · Pendiente");
            root.addView(text(description, 18));
            if (!item.optBoolean("done")) {
                Button done = button("MARCAR REALIZADO");
                root.addView(done);
                done.setOnClickListener(v -> { AlarmStore.markDone(this, id); display(); });
            }
        }
        root.addView(text("Importante: activa las notificaciones y permite la ejecución en segundo plano. Los avisos dependen de los permisos y ajustes del teléfono.", 15));
    }
}
