package com.stevedaily.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/**
 * v1.17: revisa y ayuda a activar los ajustes de Android que hacen falta para que la
 * alarma suene con la pantalla apagada, bloqueada o con la app cerrada.
 */
object AlarmSetup {
    fun notificationsOk(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun fullScreenOk(context: Context): Boolean =
        Build.VERSION.SDK_INT < 34 ||
            context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    fun batteryOk(context: Context): Boolean =
        runCatching {
            context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(context.packageName)
        }.getOrDefault(true)

    fun allOk(context: Context): Boolean =
        AlarmHelper.hasExactAlarmPermission(context) && notificationsOk(context) &&
            fullScreenOk(context) && batteryOk(context)

    private fun appUri(context: Context): Uri = Uri.parse("package:${context.packageName}")

    private fun openSafely(activity: Activity, primary: Intent) {
        try {
            activity.startActivity(primary)
        } catch (_: Exception) {
            // Si la pantalla específica no existe en este teléfono, abre la ficha general de la app.
            runCatching {
                activity.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, appUri(activity)))
            }
        }
    }

    fun openNotifications(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 33) {
            activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        // Si Android ya no vuelve a preguntar, el usuario puede activarlas aquí.
        if (!notificationsOk(activity)) {
            openSafely(activity, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, activity.packageName))
        }
    }

    fun openFullScreen(activity: Activity) {
        if (Build.VERSION.SDK_INT >= 34) {
            openSafely(activity, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, appUri(activity)))
        }
    }

    fun openBattery(activity: Activity) {
        openSafely(activity, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, appUri(activity)))
    }
}
