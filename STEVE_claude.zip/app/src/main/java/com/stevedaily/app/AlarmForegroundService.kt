package com.stevedaily.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Motorola LAB: the alarm receiver starts this audible foreground-service backup.
 * If Android displays AlarmActivity, the activity takes over speaking/playing and
 * this service deliberately releases its backup audio to avoid doubled voices.
 */
class AlarmForegroundService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var backupPlayer: MediaPlayer? = null
    private var backupVoice: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var generation = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val taskId = intent?.getLongExtra("taskId", -1L) ?: -1L
        val task = TaskStore.find(this, taskId)
        val alarmText = task?.title ?: intent?.getStringExtra("text") ?: "Recordatorio de STEVE Daily"
        val activityVisible = intent?.getBooleanExtra("activityAlreadyVisible", false) ?: false

        // Guardar evidencia de que Android SI entregó la alarma al servicio.
        getSharedPreferences("steve_alarm_diag", MODE_PRIVATE).edit()
            .putLong("last_service_received_ms", System.currentTimeMillis())
            .putString("last_service_task", alarmText)
            .apply()

        try {
            if (wakeLock?.isHeld != true) {
                val power = getSystemService(POWER_SERVICE) as PowerManager
                wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "STEVE_Daily:MotorolaAlarmAudio").apply { acquire(60_000L) }
            }
        } catch (_: RuntimeException) { }

        val alarmIntent = Intent(this, AlarmActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("taskId", taskId)
            putExtra("text", alarmText)
        }
        val pendingIntent = PendingIntent.getActivity(this, taskId.hashCode(), alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("STEVE Daily - recordatorio")
            .setContentText(alarmText)
            .setContentIntent(pendingIntent)
            .setFullScreenIntent(pendingIntent, true)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
        generation++
        handler.removeCallbacksAndMessages(null)
        if (activityVisible) {
            stopBackupAudio()
            return START_NOT_STICKY
        }
        startBackupAudio(alarmText, generation)
        handler.postDelayed({
            // v1.17: si nadie atendió la alarma, deja un aviso permanente en las notificaciones.
            postMissedNotification(alarmText, taskId)
            stopSelf(startId)
        }, 45_000L)
        try {
            startActivity(alarmIntent)
        } catch (_: Exception) { /* Full-screen notification plus audio remain as backup. */ }
        return START_NOT_STICKY
    }

    private fun startBackupAudio(text: String, thisGeneration: Int) {
        stopBackupAudio()
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            backupPlayer = MediaPlayer.create(this, R.raw.steve_alarm, attributes, 0)?.apply {
                isLooping = true
                start()
            }
        } catch (_: Exception) { }
        try {
            backupVoice = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS && thisGeneration == generation) {
                    backupVoice?.apply {
                        language = Locale("es", "CR")
                        setAudioAttributes(AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        speak("STEVE Daily te recuerda. $text", TextToSpeech.QUEUE_FLUSH,
                            null, "motorola-backup")
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun stopBackupAudio() {
        try { backupPlayer?.stop() } catch (_: Exception) { }
        try { backupPlayer?.release() } catch (_: Exception) { }
        backupPlayer = null
        try { backupVoice?.stop(); backupVoice?.shutdown() } catch (_: Exception) { }
        backupVoice = null
    }

    private fun postMissedNotification(text: String, taskId: Long) {
        runCatching {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(MISSED_CHANNEL_ID,
                "Alarmas sin atender - STEVE Daily", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(this, 0x4D49,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val notification = Notification.Builder(this, MISSED_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("⚠ Alarma sin atender")
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            manager.notify(NOTIFICATION_MISSED_BASE + (Math.abs(taskId.hashCode()) % 1000), notification)
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Alarmas STEVE Daily - MOTOROLA LAB",
            NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Avisos sonoros de las actividades programadas"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            enableVibration(true)
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        generation++
        handler.removeCallbacksAndMessages(null)
        stopBackupAudio()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "steve_alarm_motorola_lab_v1"
        const val NOTIFICATION_ID = 1201
        const val MISSED_CHANNEL_ID = "steve_alarm_missed_v1"
        const val NOTIFICATION_MISSED_BASE = 2000
    }
}
