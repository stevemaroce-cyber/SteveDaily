package com.stevedaily.lab;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.Calendar;

public final class AlarmStore {
    private static final String PREF = "steve_daily_lab_tasks_v1";
    private static final String KEY = "alarms";
    private static final String BACKUP_FORMAT = "steve-daily-lab-activities";
    private static final int BACKUP_VERSION = 1;
    private AlarmStore() {}

    public static synchronized JSONObject makeBackup(Context c) throws JSONException {
        JSONObject result = new JSONObject();
        result.put("format", BACKUP_FORMAT);
        result.put("version", BACKUP_VERSION);
        result.put("createdAt", System.currentTimeMillis());
        result.put("activities", all(c));
        return result;
    }

    public static int validateBackup(JSONObject backup) throws JSONException {
        if (!BACKUP_FORMAT.equals(backup.optString("format")) || backup.optInt("version", -1) != BACKUP_VERSION)
            throw new JSONException("El formato del archivo no corresponde a esta versión de STEVE Daily Lab.");
        JSONArray items = backup.optJSONArray("activities");
        if (items == null || items.length() > 5000)
            throw new JSONException("La lista de actividades es inválida o demasiado larga.");
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) throw new JSONException("Actividad inválida en la posición " + (i + 1));
            String name = item.optString("name", "").trim();
            if (name.isEmpty() || name.length() > 200 || !(item.opt("when") instanceof Number) ||
                    item.optLong("when") < 946684800000L || item.optLong("when") > 4102444800000L ||
                    !(item.opt("daily") instanceof Boolean) || !(item.opt("done") instanceof Boolean))
                throw new JSONException("Datos inválidos en la actividad " + (i + 1));
        }
        return items.length();
    }

    // Importar sin reemplazar ni modificar las actividades existentes.
    public static synchronized int importBackup(Context c, JSONObject backup) throws JSONException {
        validateBackup(backup);
        JSONArray imported = backup.getJSONArray("activities");
        JSONArray current = all(c);
        Set<String> known = new HashSet<>();
        SharedPreferences prefs = c.getSharedPreferences(PREF, 0);
        int next = prefs.getInt("nextId", 1000);
        for (int i = 0; i < current.length(); i++) {
            JSONObject old = current.optJSONObject(i);
            if (old == null) continue;
            next = Math.max(next, old.optInt("id", 1000));
            known.add(backupKey(old));
        }
        JSONArray combined = new JSONArray();
        for (int i = 0; i < current.length(); i++) combined.put(current.optJSONObject(i));
        JSONArray newlyAdded = new JSONArray();
        for (int i = 0; i < imported.length(); i++) {
            JSONObject source = imported.getJSONObject(i);
            String key = backupKey(source);
            if (known.contains(key)) continue;
            if (next > Integer.MAX_VALUE / 10 - 2) throw new JSONException("Demasiadas actividades para asignar identificadores");
            JSONObject item = new JSONObject();
            item.put("id", ++next);
            item.put("name", source.getString("name").trim());
            item.put("when", source.getLong("when"));
            item.put("daily", source.getBoolean("daily"));
            item.put("done", source.getBoolean("done"));
            combined.put(item);
            newlyAdded.put(item);
            known.add(key);
        }
        if (newlyAdded.length() == 0) return 0;
        boolean saved = prefs.edit().putString(KEY, combined.toString())
                .putInt("nextId", next).commit();
        if (!saved) throw new JSONException("Android no pudo guardar los datos");
        for (int i = 0; i < newlyAdded.length(); i++)
            schedule(c, newlyAdded.optJSONObject(i), false, 0L);
        return newlyAdded.length();
    }

    private static String backupKey(JSONObject item) {
        return item.optString("name", "").trim().toLowerCase(Locale.ROOT) + "\u0000"
                + item.optLong("when") + "\u0000" + item.optBoolean("daily");
    }


    public static synchronized JSONArray all(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray a) {
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply();
    }

    public static synchronized int add(Context c, String name, long when, boolean daily) {
        int id = c.getSharedPreferences(PREF, 0).getInt("nextId", 1000) + 1;
        c.getSharedPreferences(PREF, 0).edit().putInt("nextId", id).apply();
        JSONArray list = all(c);
        JSONObject item = new JSONObject();
        try {
            item.put("id", id);
            item.put("name", name);
            item.put("when", when);
            item.put("daily", daily);
            item.put("done", false);
            list.put(item);
            save(c, list);
            schedule(c, item, false, 0L);
        } catch (Exception ignored) {}
        return id;
    }

    public static synchronized void markDone(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optInt("id") == id) {
                try { o.put("done", true); } catch (Exception ignored) {}
                cancel(c, id, false);
                cancel(c, id, true);
                break;
            }
        }
        save(c, list);
    }

    public static JSONObject get(Context c, int id) {
        JSONArray list = all(c);
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o != null && o.optInt("id") == id) return o;
        }
        return null;
    }

    private static PendingIntent alarmIntent(Context c, int id, boolean snooze) {
        Intent intent = new Intent(c, AlarmReceiver.class)
                .putExtra("id", id).putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, id * 2 + (snooze ? 1 : 0), intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void cancel(Context c, int id, boolean snooze) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr != null) mgr.cancel(alarmIntent(c, id, snooze));
    }

    public static boolean canExact(Context c) {
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return mgr != null && (Build.VERSION.SDK_INT < 31 || mgr.canScheduleExactAlarms());
    }

    public static void schedule(Context c, JSONObject item, boolean snooze, long delayMillis) {
        if (item == null || item.optBoolean("done")) return;
        AlarmManager mgr = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (mgr == null) return;
        int id = item.optInt("id");
        long trigger;
        if (snooze) trigger = System.currentTimeMillis() + delayMillis;
        else {
            trigger = item.optLong("when");
            if (item.optBoolean("daily")) {
                Calendar next = Calendar.getInstance();
                Calendar original = Calendar.getInstance();
                original.setTimeInMillis(trigger);
                next.set(Calendar.HOUR_OF_DAY, original.get(Calendar.HOUR_OF_DAY));
                next.set(Calendar.MINUTE, original.get(Calendar.MINUTE));
                next.set(Calendar.SECOND, 0);
                next.set(Calendar.MILLISECOND, 0);
                if (next.getTimeInMillis() <= System.currentTimeMillis() + 1000) next.add(Calendar.DAY_OF_YEAR, 1);
                trigger = next.getTimeInMillis();
            } else if (trigger <= System.currentTimeMillis()) return;
        }
        PendingIntent pi = alarmIntent(c, id, snooze);
        if (canExact(c)) {
            PendingIntent show = PendingIntent.getActivity(c, id, new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            mgr.setAlarmClock(new AlarmManager.AlarmClockInfo(trigger, show), pi);
        } else {
            // Respaldo inexacto: Android puede retrasarlo mientras el equipo duerme.
            mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void reprogram(Context c) {
        JSONArray items = all(c);
        for (int i = 0; i < items.length(); i++) schedule(c, items.optJSONObject(i), false, 0);
    }
}
