package com.stevedaily.lab;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.content.ActivityNotFoundException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Locale;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends Activity {
    private static final int CREATE_BACKUP = 401;
    private static final int RESTORE_BACKUP = 402;
    private static final int MAX_BACKUP_BYTES = 1024 * 1024;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        AlarmReceiver.makeChannel(this);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        }
    }
    @Override protected void onResume() { super.onResume(); display(); }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setMinHeight(92);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 9, 0, 9);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String label, int size) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(Color.BLACK);
        v.setPadding(0, 12, 0, 12);
        return v;
    }

    private void display() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(24, 28, 24, 40);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);
        setContentView(scroll);
        TextView heading = text("STEVE Daily Lab 0.2", 29);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        root.addView(text("Prueba con respaldo y recuperación. Las demás versiones de STEVE Daily permanecen intactas.", 16));
        if (!AlarmStore.canExact(this)) {
            root.addView(text("ATENCIÓN: activa el permiso 'Alarmas y recordatorios' para avisos exactos.", 17));
            Button permission = button("ACTIVAR ALARMAS EXACTAS");
            root.addView(permission);
            permission.setOnClickListener(v -> {
                if (Build.VERSION.SDK_INT >= 31)
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
            });
        }
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null && !nm.canUseFullScreenIntent()) {
                root.addView(text("Para aparecer encima de la pantalla bloqueada, autoriza avisos de pantalla completa.", 16));
                Button full = button("PERMITIR PANTALLA COMPLETA");
                root.addView(full);
                full.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                        Uri.parse("package:" + getPackageName()))));
            }
        }
        root.addView(text("Respaldo de actividades", 23));
        root.addView(text("Puedes guardar tus actividades en un archivo JSON y recuperarlas. La importación agrega actividades y evita duplicados; no elimina las que ya tengas.", 16));
        Button export = button("GUARDAR RESPALDO");
        root.addView(export);
        export.setOnClickListener(v -> chooseExport());
        Button restore = button("RECUPERAR RESPALDO");
        root.addView(restore);
        restore.setOnClickListener(v -> chooseImport());
        root.addView(text("Importante: este respaldo corresponde a STEVE Daily Lab. La aplicación original del Honor utiliza un formato diferente.", 15));
        root.addView(text("Nueva actividad", 23));
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setTextSize(19);
        name.setHint("Ejemplo: dar comida a las mascotas");
        root.addView(name);
        CheckBox daily = new CheckBox(this);
        daily.setText("Repetir todos los días");
        daily.setTextSize(18);
        daily.setTextColor(Color.BLACK);
        root.addView(daily);
        Button chooseTime = button("ELEGIR HORA Y GUARDAR");
        root.addView(chooseTime);
        chooseTime.setOnClickListener(v -> {
            String title = name.getText().toString().trim();
            if (title.isEmpty()) { Toast.makeText(this, "Escribe el nombre de la actividad", Toast.LENGTH_LONG).show(); return; }
            Calendar now = Calendar.getInstance();
            new TimePickerDialog(this, (picker, hour, minute) -> {
                Calendar when = Calendar.getInstance();
                when.set(Calendar.HOUR_OF_DAY, hour);
                when.set(Calendar.MINUTE, minute);
                when.set(Calendar.SECOND, 0);
                when.set(Calendar.MILLISECOND, 0);
                if (when.getTimeInMillis() <= System.currentTimeMillis() + 5000) when.add(Calendar.DAY_OF_YEAR, 1);
                AlarmStore.add(this, title, when.getTimeInMillis(), daily.isChecked());
                Toast.makeText(this, "Actividad guardada", Toast.LENGTH_LONG).show();
                display();
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show();
        });
        root.addView(text("Actividades guardadas", 23));
        JSONArray list = AlarmStore.all(this);
        if (list.length() == 0) root.addView(text("Todavía no hay actividades.", 17));
        for (int i = 0; i < list.length(); i++) {
            JSONObject item = list.optJSONObject(i);
            if (item == null) continue;
            int id = item.optInt("id");
            String when = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                            .format(new Date(item.optLong("when")));
            String description = item.optString("name") + "\n" + when +
                    (item.optBoolean("daily") ? " · Cada día" : " · Una vez") +
                    (item.optBoolean("done") ? " · REALIZADO" : " · Pendiente");
            root.addView(text(description, 18));
            if (!item.optBoolean("done")) {
                Button done = button("MARCAR REALIZADO");
                root.addView(done);
                done.setOnClickListener(v -> { AlarmStore.markDone(this, id); display(); });
            }
        }
        root.addView(text("Importante: activa las notificaciones y permite la ejecución en segundo plano. Los avisos dependen de los permisos y ajustes del teléfono.", 15));
    }

    private void chooseExport() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "STEVE_Daily_Respaldo_" + stamp + ".json");
        try { startActivityForResult(intent, CREATE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para guardar el archivo."); }
    }

    private void chooseImport() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try { startActivityForResult(intent, RESTORE_BACKUP); }
        catch (ActivityNotFoundException e) { message("No se encontró una aplicación para abrir archivos."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == CREATE_BACKUP) {
            try {
                JSONObject backup = AlarmStore.makeBackup(this);
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                    if (stream == null) throw new Exception("No se pudo abrir el archivo de destino");
                    byte[] bytes = backup.toString(2).getBytes(StandardCharsets.UTF_8);
                    stream.write(bytes);
                    stream.flush();
                }
                message("Respaldo guardado: " + AlarmStore.all(this).length() + " actividades");
            } catch (Exception e) {
                showError("No se pudo guardar el respaldo: " + e.getMessage());
            }
        } else if (requestCode == RESTORE_BACKUP) {
            try {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    if (stream == null) throw new Exception("No se pudo leer el archivo");
                    byte[] buffer = new byte[8192];
                    int count;
                    while ((count = stream.read(buffer)) != -1) {
                        if (bytes.size() + count > MAX_BACKUP_BYTES)
                            throw new Exception("El archivo es demasiado grande (máximo 1 MB)");
                        bytes.write(buffer, 0, count);
                    }
                }
                JSONObject backup = new JSONObject(new String(bytes.toByteArray(), StandardCharsets.UTF_8));
                int total = AlarmStore.validateBackup(backup);
                new AlertDialog.Builder(this)
                        .setTitle("Confirmar importación")
                        .setMessage("El archivo contiene " + total + " actividades. Se agregarán solo las que no existan; ninguna actividad actual se borrará. ¿Importar ahora?")
                        .setPositiveButton("IMPORTAR", (dialog, which) -> {
                            try {
                                int imported = AlarmStore.importBackup(this, backup);
                                new AlertDialog.Builder(this)
                                        .setTitle("Respaldo recuperado")
                                        .setMessage("Actividades nuevas: " + imported + "\nDuplicadas omitidas: " + (total - imported))
                                        .setPositiveButton("ENTENDIDO", null)
                                        .show();
                                display();
                            } catch (Exception e) { showError("No se pudo importar: " + e.getMessage()); }
                        })
                        .setNegativeButton("CANCELAR", null)
                        .show();
            } catch (Exception e) {
                showError("El archivo no es un respaldo válido: " + e.getMessage());
            }
        }
    }

    private void showError(String description) {
        new AlertDialog.Builder(this).setTitle("Aviso del respaldo")
                .setMessage(description).setPositiveButton("ENTENDIDO", null).show();
    }
    private void message(String description) {
        Toast.makeText(this, description, Toast.LENGTH_LONG).show();
    }
}
