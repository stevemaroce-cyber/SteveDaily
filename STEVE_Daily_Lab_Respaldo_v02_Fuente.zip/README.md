# STEVE Daily Lab Respaldo · Android (versión 0.2 de pruebas)

Este proyecto es una **aplicación independiente** con identificador `com.stevedaily.lab.backup`.
**No modifica ni reemplaza** STEVE Daily original ni la STEVE Daily Lab 0.1 ya instalada.

## Cambios frente a Lab 0.1
- Botón **GUARDAR RESPALDO**: elige dónde almacenar un archivo `.json` con todas las actividades, incluidas las realizadas.
- Botón **RECUPERAR RESPALDO**: selecciona un respaldo, revisa el número de actividades y confirma la importación.
- Importación **no destructiva**: no borra ni sustituye las actividades previas y evita importar duplicados exactos.
- Funciona localmente sin señal de Internet: utiliza el selector de archivos de Android.
- Conserva las alarmas habladas y la opción de posponer 5, 30 o 60 minutos de Lab.

## Importante
- La app **ya guarda internamente** las actividades. Exportar crea una copia externa para conservar o trasladar.
- Los respaldos de esta versión son compatibles con la familia *STEVE Daily Lab Respaldo*, **no** son una exportación automática de la STEVE Daily original del Honor; la app antigua no expone exportación.
- Instalar esta versión con identificador nuevo significa que inicia **sin** las actividades que tengas en Lab 0.1. Así no se corrompen ni se pierden las pruebas existentes.
- Guarda tus copias en un lugar privado. Los archivos JSON contienen los nombres de tus actividades y no están cifrados.
- La APK compilada en GitHub Actions usa firma de **depuración**. Si futuras compilaciones cambian de firma, Android no permitirá actualizar encima. Antes de desinstalar esta Lab 0.2, **exporta** una copia para poder recuperarla en una instalación limpia.
- El botón Realizado aún desactiva de forma permanente una actividad diaria; se corregirá en otro cambio.
- Android puede retrasar alarmas si no se conceden permisos adecuados. La compilación correcta no garantiza por sí sola una alarma confiable.

## Compilación sin computadora
1. Cargar al repositorio el archivo `STEVE_Daily_Lab_Respaldo_v02_Fuente.zip`.
2. Crear en el mismo repositorio `.github/workflows/build-respaldo.yml` usando el archivo suministrado por separado.
3. Verificar que el trabajo `Compilar STEVE Daily Lab Respaldo v02` termine en verde y descargar el artefacto ZIP que contiene `app-debug.apk`.

El código fuente todavía debe compilarse y probarse antes de convertirse en una APK instalable.
